package ru.mrgeng.digit.epu.security;

public interface ScreenRegistry {
    // Корневые элементы
    String MENU = "menu"; // Меню
    String GRAFANA = "grafana"; // Мониторинг

    // application-mp: основные экраны
    String APPLICATION_MP = "application-mp"; // ЕПУ СТМ РГК
    String DGEPU_RGC_DEVICE_TREE_SCREEN = "dgepu_RgcDeviceTreeScreen"; // СТМ УИРГ
    String MP_RGC_DEVICE_MAP_SCREEN = "mp_RgcDeviceMapScreen"; // Объекты на карте
    String MP_CORR_DEVICE_DATA_BROWSE = "mp_CorrDeviceDataBrowse.browse"; // Данные по УИРГ
    String MP_CHRO_DEVICE_DATA_BROWSE = "mp_ChroDeviceDataBrowse.browse"; // Данные по хроматографам
    String MP_METER_DEVICE_DATA_BROWSE = "mp_MeterDeviceDataBrowse.browse"; // Данные по счетчикам
    String MP_CORR_DEVICE_CURRENT_DATA = "mp_CorrDeviceCurrentData"; // Текущие данные УИРГ
    String MP_CHRO_DEVICE_CURRENT_DATA = "mp_ChroDeviceCurrentData"; // Текущие данные хроматографов
    String MP_METER_DEVICE_CURRENT_DATA = "mp_MeterDeviceCurrentData"; // Текущие показания счетчиков
    String PROS_STM_OBJ_BROWSE = "pros_StmObj.browse"; // Системы телеметрии
    String PROS_UIRG_BROWSE = "pros_Uirg.browse"; // Узлы измерений расхода газа
    String RGC_EVENTS = "rgcEvents"; // Журнал событий
    String PROS_DEVICE_EVENT_BROWSE = "pros_DeviceEvent.browse"; // Журнал событий
    String DGEPU_USER_SECURITY_LOG = "dgepu_UserSecurityLog"; // Журнал действий пользователя
    //дополнительно
    String MP_DEVICE_BROWSE = "mp_Device.browse";
    String MP_DEVICE_EDIT = "mp_Device.edit";
    String PROS_DEVICE_EVENT_SCREEN = "pros_DeviceEventScreen";
    String PROS_STM_OBJ_EDIT = "pros_StmObj.edit";
    String PROS_UIRG_EDIT = "pros_Uirg.edit";

    // application-mp - rgk_qualityPassport: Качество газа
    String RGK_QUALITY_PASSPORT = "rgk_qualityPassport"; // Качество газа
    String MP_GAS_QUALITY_PASSPORT_BROWSE = "mp_GasQualityPassport.browse"; // Паспорта качества газа
    String MP_GAS_QUALITY_PROTOCOL_BROWSE = "mp_GasQualityProtocol.browse"; // Протоколы записи ФХП
    //дополнительно
    String MP_GAS_QUALITY_PASSPORT_EDIT = "mp_GasQualityPassport.edit";
    String MP_GAS_QUALITY_PROTOCOL_EDIT = "mp_GasQualityProtocol.edit";

    // application-mp - application-mp-config: Конфигурация
    String APPLICATION_MP_CONFIG = "application-mp-config"; //Конфигурирование
    String MP_RGK_DEVICE_BROWSE = "mp_RgkDevice.browse"; // Устройства
    String MP_DEVICE_PROTO_MODEL_BROWSE = "mp_DeviceProtoModel.browse"; // Драйверы устройств
    String MP_DEVICE_SERVICE_BROWSE = "mp_DeviceService.browse"; // Сервисы взаимодействия с устройством
    String MP_DEVICE_MP_THRESHOLD_BROWSE = "mp_DeviceMpThreshold.browse"; // Пороги предупреждений/тревог
    String MP_DEVICE_MP_IGNORE_BROWSE = "mp_DeviceMpIgnore.browse"; // Игнорирование тревог/предупреждений
    String RGC_PLACE = "rgc-place"; // Площадки
    String MP_PLACE_BROWSE = "mp_Place.browse"; // Площадки
    String MP_MEAS_POINT_BROWSE = "mp_MeasPoint.browse"; // Места измерения
    String SERVER_LOG = "serverLog"; // Журналы работы (из администрирования)
    String MP_DEFAULT_DEVICE_SETTINGS_BROWSE = "mp_DefaultDeviceSettings.browse"; // Настройки устройства по умолчанию
    String DGCORE_TAG_BROWSE = "dgcore_Tag.browse"; // Теги
    //дополнительно
    String MP_DEVICE_PROTO_MODEL_EDIT = "mp_DeviceProtoModel.edit";
    String MP_DEVICE_SERVICE_EDIT = "mp_DeviceService.edit";
    String MP_DEVICE_MP_THRESHOLD_EDIT = "mp_DeviceMpThreshold.edit";
    String MP_DEVICE_MP_IGNORE_EDIT = "mp_DeviceMpIgnore.edit";
    String MP_PLACE_EDIT = "mp_Place.edit";
    String MP_MEAS_POINT_EDIT = "mp_MeasPoint.edit";
    String MP_DEFAULT_DEVICE_SETTINGS_EDIT = "mp_DefaultDeviceSettings.edit";
    String DGCORE_TAG_CREATE = "dgcore_Tag.create";
    String DGCORE_TAG_EDIT = "dgcore_Tag.edit";

    // application-mp - application-mp-dict: Справочники
    String APPLICATION_MP_DICT = "application-mp-dict"; // Справочники
    String MP_DEVICE_GROUP_BROWSE = "mp_DeviceGroup.browse"; // Группы устройств
    String MP_DEVICE_TYPE_BROWSE = "mp_DeviceType.browse"; // Типы устройств
    String MP_DEVICE_MODEL_BROWSE = "mp_DeviceModel.browse"; // Модели устройств
    String MP_STANDARD_SIZE_BROWSE = "mp_StandardSize.browse"; // Типоразмеры устройств
    String MP_DEVICE_STATUS_BROWSE = "mp_DeviceStatus.browse"; // Статусы устройств
    String MP_DEVICE_PARAM_TYPE_BROWSE = "mp_DeviceParamType.browse"; // Типы параметров
    String MP_PARAM_TYPE_BROWSE = "mp_ParamType.browse"; // Типы приведенных параметров
    String MP_PARAM_GROUP_BROWSE = "mp_ParamGroup.browse"; // Группы приведенных параметров
    String MP_PARAM_BROWSE = "mp_Param.browse"; // Приведенные параметры
    String MP_PARAM_UNIT_BROWSE = "mp_ParamUnit.browse"; // Единицы измерения
    String MP_PARAM_UNIT_TYPE_BROWSE = "mp_ParamUnitType.browse"; // Типы измеряемых параметров
    String MP_DEVICE_MEAS_POINT_BROWSE = "mp_DeviceMeasPoint.browse"; // Места измерения моделей устройств
    String MP_PARAM_UNIT_METRIC_PREFIX_BROWSE = "mp_ParamUnitMetricPrefix.browse"; // Приставки СИ
    String MP_TRANSFORM_FUNC_BROWSE = "mp_TransformFunc.browse"; // Преобразования
    String MP_DEVICE_PROTO_BROWSE = "mp_DeviceProto.browse"; // Протоколы взаимодействия с устройствами
    String MP_TECH_SUPPORT_BROWSE = "mp_TechSupport.browse"; // Тех. сопровождение
    String MP_TREE_GROUP_BROWSE = "mp_TreeGroup.browse"; // Группы объектов
    String TREE_GROUP_RGK = "tree-group-rgk"; // Группы объектов
    String MP_TREE_OBJ_BROWSE = "mp_TreeObj.browse"; // Объекты
    String TREE_OBJ_RGK = "tree-obj-rgk"; // Объекты
    String MP_TECH_INFO_BROWSE = "mp_TechInfo.browse"; // Техническая информация
    String TREE_INFO_RGK = "tree-info-rgk"; // Техническая информация
    String PROS_TECH_SCHEMA_MODEL_BROWSE = "pros_TechSchemaModel.browse"; // Модели технологических схем
    String TREE_TECHSCMOD_RGK = "tree-techscmod-rgk"; // Модели технологических схем
    String PROS_TECH_SCHEMA_BROWSE = "pros_TechSchema.browse"; // Технологические схемы
    String TREE_TECHSCHEMA_RGK = "tree-techscema-rgk"; // Технологические схемы
    String MP_DEVICE_CHANNEL_BROWSE = "mp_DeviceChannel.browse"; // Провайдер канала
    String PROS_STM_MODEL_BROWSE = "pros_StmModel.browse"; // Модели систем телеметрии
    String PROS_SENSOR_PRESSURE_MODEL_BROWSE = "pros_SensorPressureModel.browse"; // Модели датчиков давления
    String PROS_GAS_METER_MODEL_BROWSE = "pros_GasMeterModel.browse"; // Модели счетчиков газа
    String PROS_CONTROLLER_MODEL_BROWSE = "pros_ControllerModel.browse"; // Модели контроллеров
    String PROS_MODEM_MODEL_BROWSE = "pros_ModemModel.browse"; // Модели модемов
    String DGCORE_ORG_FORMS_BROWSE = "dgcore_OrgForms.browse"; // Организационные формы
    String PROS_GRS_BROWSE = "pros_Grs.browse"; // ГРС
    String MP_GRS_DEVICE_LINK_BROWSE = "mp_GrsDeviceLink.browse"; // Связь ГРС-Устройства
    String DGCORE_DEPARTMENT_BROWSE = "dgcore_Department.browse"; // Подразделения
    String EPURGK_DGCORE_DEPARTMENT_BROWSE = "epurgk_dgcore_Department.browse"; // Подразделения
    String DGCORE_COMPANY_BRANCH_BROWSE = "dgcore_CompanyBranch.browse"; // Филиалы
    String EPURGK_DGCORE_COMPANY_BRANCH_BROWSE = "epurgk_dgcore_CompanyBranch.browse"; // Филиалы
    //дополнительно
    String MP_DEVICE_GROUP_EDIT = "mp_DeviceGroup.edit";
    String MP_DEVICE_TYPE_EDIT = "mp_DeviceType.edit";
    String MP_DEVICE_MODEL_EDIT = "mp_DeviceModel.edit";
    String MP_STANDARD_SIZE_EDIT = "mp_StandardSize.edit";
    String MP_DEVICE_STATUS_EDIT = "mp_DeviceStatus.edit";
    String MP_DEVICE_PARAM_TYPE_EDIT = "mp_DeviceParamType.edit";
    String MP_PARAM_TYPE_EDIT = "mp_ParamType.edit";
    String MP_PARAM_GROUP_EDIT = "mp_ParamGroup.edit";
    String MP_PARAM_EDIT = "mp_Param.edit";
    String MP_PARAM_UNIT_EDIT = "mp_ParamUnit.edit";
    String MP_PARAM_UNIT_TYPE_EDIT = "mp_ParamUnitType.edit";
    String MP_DEVICE_MEAS_POINT_EDIT = "mp_DeviceMeasPoint.edit";
    String MP_PARAM_UNIT_METRIC_PREFIX_EDIT = "mp_ParamUnitMetricPrefix.edit";
    String MP_TRANSFORM_FUNC_EDIT = "mp_TransformFunc.edit";
    String MP_DEVICE_PROTO_EDIT = "mp_DeviceProto.edit";
    String MP_TECH_SUPPORT_EDIT = "mp_TechSupport.edit";
    String MP_TREE_GROUP_EDIT = "mp_TreeGroup.edit";
    String MP_TREE_OBJ_EDIT = "mp_TreeObj.edit";
    String MP_TECH_INFO_EDIT = "mp_TechInfo.edit";
    String PROS_TECH_SCHEMA_MODEL_EDIT = "mp_TechSchemaModel.edit";
    String PROS_TECH_SCHEMA_EDIT = "mp_TechSchema.edit";
    String MP_DEVICE_CHANNEL_EDIT = "mp_DeviceChannel.edit";
    String PROS_STM_MODEL_EDIT = "pros_StmModel.edit";
    String PROS_SENSOR_PRESSURE_MODEL_EDIT = "pros_SensorPressureModel.edit";
    String PROS_GAS_METER_MODEL_EDIT = "pros_GasMeterModel.edit";
    String PROS_CONTROLLER_MODEL_EDIT = "pros_ControllerModel.edit";
    String PROS_MODEM_MODEL_EDIT = "pros_ModemModel.edit";
    String PROS_GRS_EDIT = "pros_Grs.edit";
    String MP_GRS_DEVICE_LINK_EDIT = "mp_GrsDeviceLink.edit";
    String DGCORE_DEPARTMENT_EDIT = "dgcore_Department.edit";
    String DGCORE_COMPANY_BRANCH_EDIT = "dgcore_CompanyBranch.edit";

    // application-mp-gro: основные экраны
    String APPLICATION_MP_GRO = "application-mp-gro"; // ЕПУ СТМ ГРО
    String PROS_DASH_SCREEN = "pros_DashScreen"; // Пульт ГРО
    String MP_PRG_DEVICE_CURRENT_DATA = "mp_PrgDeviceCurrentData"; // Текущие данные по ПРГ
    String MP_SKZ_DEVICE_CURRENT_DATA = "mp_SkzDeviceCurrentData"; // Текущие данные по СКЗ
    String MP_ZA_DEVICE_CURRENT_DATA = "mp_ZaDeviceCurrentData"; // Текущие данные по ЗА
    String MP_AD_DEVICE_CURRENT_DATA = "mp_AdDeviceCurrentData"; // Текущие данные по АД
    String PROS_DISP_SHIFT_BROWSE = "pros_DispShift.browse"; // Сменный журнал
    String PROS_DISP_SHIFT_MESSAGE_BROWSE = "pros_DispShiftMessage.browse"; // Сообщения по смене
    String GRO_EVENTS = "groEvents"; // Журнал событий
    String PROS_DISP_SHIFT_RESPONSIBLE_BROWSE = "pros_DispShiftResponsible.browse"; // Ответственные за смену
    String DGEPU_METER_TREE_SCREEN = "dgepu_MeterTreeScreen"; // Cчетчики
    //дополнительно
    String PROS_DISP_SHIFT_EDIT = "pros_DispShift.edit";
    String PROS_DISP_SHIFT_MESSAGE_EDIT = "mp_DispShiftMessage.edit";
    String PROS_DISP_SHIFT_RESPONSIBLE_EDIT = "pros_DispShiftResponsible.edit";

    // application-mp-gro - epu-stm-gro-config: конфигурация GRO
    String APPLICATION_MP_GRO_CONFIG = "epu-stm-gro-config"; // Конфигурирование
    String GRO_DEVICES = "gro-devices"; // Устройства
    String MP_GRO_DEVICE_BROWSE = "mp_GroDevice.browse"; // Устройства
    String GRO_DEVICE_PROTO_MODEL = "groDeviceProtoModel"; // Драйверы устройств
    String GRO_SERVICES = "gro-services"; // Сервисы взаимодействия
    String PROS_SKZ_OBJ_BROWSE = "pros_SkzObj.browse"; // Станция катодной защиты
    String GRO_THRESHOLDS = "gro-thresholds"; // Пороги
    String GRO_IGNORES = "gro-ignores"; // Игнорирование
    String GRO_PLACE = "gro-place"; // Площадки
    String GRO_MP = "gro-mp"; // Места измерения
    String DGEPU_DATA_BASE_VIEWER = "dgepu_DataBaseViewer"; // Базы данных
    String MP_WIDGET_SETTING_BROWSE = "mp_WidgetSetting.browse"; // Шаблоны виджетов
    //дополнительно
    String PROS_SKZ_OBJ_EDIT = "pros_SkzObj.edit";
    String MP_WIDGET_SETTING_EDIT = "mp_WidgetSetting.edit";

    // application-mp - application-mp-dict-gro: Справочники
    String APPLICATION_MP_DICT_GRO = "application-mp-dict-gro"; // Справочники (2)
    String APPLICATION_MP_GRO_0 = "application-mp-gro-0"; // Группы устройств
    String APPLICATION_MP_GRO_1 = "application-mp-gro-1"; // Типы устройств
    String APPLICATION_MP_GRO_2 = "application-mp-gro-2"; // Модели устройств
    String APPLICATION_MP_GRO_3 = "application-mp-gro-3"; // Статусы устройств
    String APPLICATION_MP_GRO_4 = "application-mp-gro-4"; // Типы параметров
    String APPLICATION_MP_GRO_5 = "application-mp-gro-5"; // Типы приведенных параметров
    String APPLICATION_MP_GRO_6 = "application-mp-gro-6"; // Группы приведенных параметров
    String APPLICATION_MP_GRO_7 = "application-mp-gro-7"; // Приведенные параметры
    String APPLICATION_MP_GRO_8 = "application-mp-gro-8"; // Единицы измерения
    String APPLICATION_MP_GRO_9 = "application-mp-gro-9"; // Типы измеряемых параметров
    String APPLICATION_MP_GRO_10 = "application-mp-gro-10"; // Места измерения моделей устройств
    String APPLICATION_MP_GRO_11 = "application-mp-gro-11"; // Приставки СИ
    String APPLICATION_MP_GRO_12 = "application-mp-gro-12"; // Преобразования
    String GRO_PROTO = "gro-proto"; // Протоколы взаимодействия
    String APPLICATION_MP_GRO_13 = "application-mp-gro-13"; // Тех. сопровождение
    String TREE_GROUP_GRO = "tree-group-gro"; // Группы объектов
    String TREE_OBJ_GRO = "tree-obj-gro"; // Объекты
    String TREE_INFO_GRO = "tree-info-gro"; // Техническая информация
    String TREE_TECHSCMOD_GRO = "tree-techscmod-gro"; // Модели технологических схем
    String TREE_TECHSCHEMA_GRO = "tree-techscema-gro"; // Технологические схемы
    String GRO_CHANNELS = "gro-channels"; // Провайдер канала
    String EPUGRO_DGCORE_DEPARTMENT_BROWSE = "epugro_dgcore_Department.browse"; // Подразделения
    String EPUGRO_DGCORE_COMPANY_BRANCH_BROWSE = "epugro_dgcore_CompanyBranch.browse"; // Филиалы


    // docs: документы
    String DOCS = "docs"; // Документация
    String MP_DOCUMENT_BROWSE = "mp_Document.browse"; // Документация

    // pros_TaskService: Доп. конфигурирование
    String PROS_TASK_SERVICE = "pros_TaskService"; // Доп. конфигурирование

    // reports: отчёты
    String REPORTS = "reports"; // Отчеты
    String REPORT_REPORT_BROWSE = "report$Report.browse"; // Отчеты
    String REPORT_REPORT_GROUP_BROWSE = "report$ReportGroup.browse"; // Группы отчетов
    String REPORT_REPORT_RUN = "report$Report.run"; // Запуск отчета

    String ADMINISTRATION = "administration"; // Администрирование
    // administration: безопасность
    String SEC_USER_BROWSE = "sec$User.browse"; // Пользователи
    String SEC_GROUP_BROWSE = "sec$Group.browse"; // Группы
    String SEC_ROLE_BROWSE = "sec$Role.browse"; // Роли
    String SEC_USER_SESSION_ENTITY_BROWSE = "sec$UserSessionEntity.browse"; // Пользовательские сессии
    String SEC_SESSION_LOG_ENTRY_BROWSE = "sec$SessionLogEntry.browse"; // Журнал сессий

    // administration: система
    String SYS_CATEGORY_BROWSE = "sys$Category.browse"; // Категории
    String SYS_LOCK_INFO_BROWSE = "sys$LockInfo.browse"; // Блокировки
    String SYS_FILE_DESCRIPTOR_BROWSE = "sys$FileDescriptor.browse"; // Файлы
    String SYS_SCHEDULED_TASK_BROWSE = "sys$ScheduledTask.browse"; // Регламентные задания
    String ENTITY_RESTORE = "entityRestore"; // Восстановление сущностей
    String ENTITY_INSPECTOR_BROWSE = "entityInspector.browse"; // Инспектор сущностей
    String APP_PROPERTIES = "appProperties"; // Свойства приложения
    String JMX_CONSOLE = "jmxConsole"; // JMX консоль
    String ENTITY_LOG = "entityLog"; // Журнал сущностей
    String SYS_SENDING_MESSAGE_BROWSE = "sys$SendingMessage.browse"; // Отправляемые сообщения

    // administration - administration-ddca: Вложения
    String APPLICATION_DDCA = "application-ddca"; //Вложения
    String DDCA_ATTACHMENT_ALL_BROWSE = "ddca$AttachmentAll.browse"; // Все Вложения
    String DDCA_ATTACHMENT_CATEGORY_BROWSE = "ddca$AttachmentCategory.browse"; // Категории вложений

    // administration: imap
    String APPLICATION_IMAP_COMPONENT = "imap-component";
    String IMAP_MAIL_BOX_BROWSE = "imap$MailBox.browse"; // Конфигурация
    String IMAP_MESSAGE_BROWSE = "imap$Message.browse"; // Просмотр сообщений

    // administration: инструменты
    String SYS_ACCESS_TOKEN_BROWSE = "sys$AccessToken.browse"; // Управление токенами доступа
    String DGCORE_LINK_DEFINITION_BROWSE = "dgcore_LinkDefinition.browse"; // Типы связей
    String SCREEN_PROFILER = "screenProfiler"; // Профайлер экранов
    String PERFORMANCE_STATISTICS = "performanceStatistics"; // Статистика производительности

    // help: справка и настройки
    String HELP = "help"; // Помощь
    String ABOUT_WINDOW = "aboutWindow"; // О приложении
    String SETTINGS = "settings"; // Настройки
    String PROS_EXT_THEME_SETTINGS_SCREEN = "pros_ExtThemeSettingsScreen"; // Настройки темы
    String DGEPU_CHANGELOG_SCREEN = "dgepu_ChangelogScreen"; // История версий

    // ДОПОЛНИТЕЛЬНЫЕ ЭКРАНЫ (для групп)
    String DGCORE_TAG_ASSIGNMENT = "dgcore_TagAssignment"; // Назначение тегов
    String DGEPU_UNITMEASURECONVERTSCREEN = "dgepu_Unitmeasureconvertscreen"; // Конвертер единиц
    String BACKGROUND_WORK_WINDOW = "backgroundWorkWindow"; // Фоновые задачи
    String LIST_EDITOR_POPUP = "list-editor-popup"; // Редактор списка
    String MP_MAPPING_ADAPTER_DEVICE_MODEL_BROWSE = "mp_MappingAdapterDeviceModel.browse"; // Адаптеры моделей

    // Фильтры и диалоги
    String BULK_EDITOR = "bulkEditor";
    String SAVE_FILTER = "saveFilter";
    String ADD_CONDITION = "addCondition";
    String FILTER_EDITOR = "filterEditor";
    String FILTER_SELECT = "filterSelect";
    String REPORT_INPUT_PARAMETERS = "report$inputParameters";
    String PROS_DAILY_REPORT_SCREEN = "pros_DailyReportScreen";
    String PROS_PGPICKER = "pros_Pgpicker";
    String PASSPORT_KAS_EDIT = "passport-kas-edit";
    String INPUT_DIALOG = "inputDialog";
    String DGEPU_KP_CONFIGURATION_SCREEN = "dgepu_KpConfigurationScreen";
    String MP_DEVICE_POLLING_EDIT = "mp_DevicePolling.edit";
    String DGEPU_FRAGMENT_SCREEN = "dgepu_FragmentScreen";
    String PROS_JOURNAL_MESSAGE_DIALOG = "pros_JournalMessageDialog";

    // Экраны действий с устройствами
    String MP_DEVICE_ACTION_BROWSE = "mp_DeviceAction.browse";
    String MP_DEVICE_ACTION_EDIT = "mp_DeviceAction.edit";
    String POLL_RESULTS_SCREEN = "PollResultsScreen";
    String PROS_COMMON_NOTIFY_EVENT_SCREEN = "pros_CommonNotifyEventScreen";
    String MP_DEVICE_COMMENT_BROWSE = "mp_DeviceComment.browse";
    String MP_DEVICE_COMMENT_EDIT = "mp_DeviceComment.edit";
    String DGEPU_BATCH_OPERATION = "dgepu_BatchOperation";
    String MP_DEVICE_MAINTENANCE_TASK_EDIT = "mp_DeviceMaintenanceTask.edit";

    // Экраны отчётов и дашбордов
    String PROS_CHART_TABLE_SCREEN = "pros_ChartTableScreen";
    String PROS_CHART_DATA = "pros_ChartData";
    String PROS_OBJ_REPORT_BY_PERIOD = "pros_ObjReportByPeriod";
    String REPORT_REPORT_EDIT = "report$Report.edit";
    String REPORT_REPORT_GROUP_EDIT = "report$ReportGroup.edit";
    String REPORT_SHOW_CHART = "report$showChart";
    String REPORT_SHOW_REPORT_TABLE = "report$showReportTable";
    String REPORT_SHOW_PIVOT_TABLE = "report$showPivotTable";

    // Экраны безопасности и мониторинга
    String DGEPU_ENTITY_LOG_BROWSE = "dgepu_EntityLogBrowse";
    String SEC_USER_EDIT = "sec$User.edit";
    String SEC_USER_CHANGE_PASSWORD = "sec$User.changePassword";
    String SEC_USER_RESET_PASSWORDS = "sec$User.resetPasswords";
    String SEC_GROUP_EDIT = "sec$Group.edit";
    String SEC_ROLE_LOOKUP = "sec$Role.lookup";

    // Экраны настроек устройств
    String MP_DEVICE_RECALC_SETTINGS_EDIT = "mp_DeviceRecalcSettings.edit";
    String MP_DRIVER_ERRORS_SCREEN = "mp_DriverErrorsScreen";
}