package ru.mrgeng.digit.epu.security;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Реестр групп экранов для переиспользования в ролях.
 * Решает проблему дублирования длинных списков во нескольких ролях:
 * вместо массива в аннотации используется строковая константа.
 *
 * @see ScreenGroup аннотация для применения в ролях
 * @see ScreenGroupSupportRoleDefinition базовый класс, обрабатывающий группы
 */

public final class ScreenGroupRegistry {
    private ScreenGroupRegistry() {}

    // ========== КЛЮЧИ ГРУПП ==========

    // Общий для всех ролей (меню + история версий) — добавляется автоматически
    public static final String COMMON_ALL = "COMMON_ALL";

    // Общие UI компоненты (about, background, popup, конвертер, теги)
    public static final String COMMON_UI = "COMMON_UI";

    // application-mp: основные экраны мониторинга РГК
    public static final String MP_GROUP = "MP_GROUP";

    // application-mp - application-mp-config: Конфигурация РГК
    public static final String MP_CONFIG_GROUP = "MP_CONFIG_GROUP";

    // application-mp - application-mp-dict: Справочники РГК
    public static final String MP_DICT_GROUP = "MP_DICT_GROUP";

    // application-mp-gro: основные экраны мониторинга ГРО
    public static final String GRO_GROUP = "GRO_GROUP";

    // application-mp-gro - epu-stm-gro-config: Конфигурация ГРО
    public static final String GRO_CONFIG_GROUP = "GRO_CONFIG_GROUP";

    // application-mp-gro - application-mp-dict-gro: Справочники ГРО
    public static final String GRO_DICT_GROUP = "GRO_DICT_GROUP";

    // docs: документы
    public static final String DOCS_GROUP = "DOCS_GROUP";

    // reports: отчёты
    public static final String REPORTS_GROUP = "REPORTS_GROUP";

    // administration: полный доступ
    public static final String ADMIN_GROUP = "ADMIN_GROUP";

    // grafana
    public static final String GRAFANA_GROUP = "GRAFANA_GROUP";

    // основные экраны
    public static final String COMMON_UI_DIALOGS = "COMMON_UI_DIALOGS";

    // экраны действий с устройствами
    public static final String DEVICE_ACTIONS = "DEVICE_ACTIONS";

    // экраны отчётов и дашбордов
    public static final String REPORTS_EXTENDED = "REPORTS_EXTENDED";

    // экраны безопасности и мониторинга
    public static final String ADMIN_SECURITY_EXTENDED = "ADMIN_SECURITY_EXTENDED";

    // экраны настроек устройств
    public static final String DEVICE_SETTINGS = "DEVICE_SETTINGS";

    // Фильтры и диалоги
    private static final Map<String, String[]> GROUPS = new HashMap<>();

    static {

        // ===== Общий массив для всех ролей =====
        GROUPS.put(COMMON_ALL, new String[]{
                ScreenRegistry.MENU,
                ScreenRegistry.HELP,
                ScreenRegistry.SETTINGS,
                ScreenRegistry.PROS_EXT_THEME_SETTINGS_SCREEN,
                ScreenRegistry.DGEPU_CHANGELOG_SCREEN
        });

        // ===== Общие UI компоненты =====
        GROUPS.put(COMMON_UI, new String[]{
                ScreenRegistry.ABOUT_WINDOW,
                ScreenRegistry.BACKGROUND_WORK_WINDOW,
                ScreenRegistry.LIST_EDITOR_POPUP,
                ScreenRegistry.DGEPU_UNITMEASURECONVERTSCREEN,
                ScreenRegistry.DGCORE_TAG_ASSIGNMENT,
                ScreenRegistry.DGCORE_TAG_BROWSE,
                ScreenRegistry.DGCORE_TAG_CREATE,
                ScreenRegistry.DGCORE_TAG_EDIT
        });

        // ===== application-mp: основные экраны =====
        GROUPS.put(MP_GROUP, new String[]{
                ScreenRegistry.APPLICATION_MP,
                ScreenRegistry.DGEPU_RGC_DEVICE_TREE_SCREEN,
                ScreenRegistry.MP_RGC_DEVICE_MAP_SCREEN,
                ScreenRegistry.MP_CORR_DEVICE_DATA_BROWSE,
                ScreenRegistry.MP_CHRO_DEVICE_DATA_BROWSE,
                ScreenRegistry.MP_METER_DEVICE_DATA_BROWSE,
                ScreenRegistry.MP_CORR_DEVICE_CURRENT_DATA,
                ScreenRegistry.MP_CHRO_DEVICE_CURRENT_DATA,
                ScreenRegistry.MP_METER_DEVICE_CURRENT_DATA,
                ScreenRegistry.RGC_EVENTS,
                ScreenRegistry.PROS_DEVICE_EVENT_BROWSE,
                ScreenRegistry.PROS_DEVICE_EVENT_SCREEN,
                ScreenRegistry.PROS_STM_OBJ_BROWSE,
                ScreenRegistry.PROS_UIRG_BROWSE
        });

        // ===== application-mp - application-mp-config =====
        GROUPS.put(MP_CONFIG_GROUP, new String[]{
                ScreenRegistry.MP_DEVICE_BROWSE,
                ScreenRegistry.MP_DEVICE_EDIT,
                ScreenRegistry.MP_DEVICE_PROTO_MODEL_BROWSE,
                ScreenRegistry.MP_DEVICE_PROTO_MODEL_EDIT,
                ScreenRegistry.MP_DEVICE_SERVICE_BROWSE,
                ScreenRegistry.MP_DEVICE_SERVICE_EDIT,
                ScreenRegistry.MP_DEVICE_MP_THRESHOLD_BROWSE,
                ScreenRegistry.MP_DEVICE_MP_THRESHOLD_EDIT,
                ScreenRegistry.MP_DEVICE_MP_IGNORE_BROWSE,
                ScreenRegistry.MP_PLACE_BROWSE,
                ScreenRegistry.MP_PLACE_EDIT,
                ScreenRegistry.MP_MEAS_POINT_BROWSE,
                ScreenRegistry.MP_MEAS_POINT_EDIT,
                ScreenRegistry.MP_DEFAULT_DEVICE_SETTINGS_BROWSE,
                ScreenRegistry.DGCORE_TAG_BROWSE,
                ScreenRegistry.MP_MAPPING_ADAPTER_DEVICE_MODEL_BROWSE
        });

        // ===== application-mp - application-mp-dict =====
        GROUPS.put(MP_DICT_GROUP, new String[]{
                ScreenRegistry.APPLICATION_MP_DICT,
                // Группы и типы устройств
                ScreenRegistry.MP_DEVICE_GROUP_BROWSE, ScreenRegistry.MP_DEVICE_GROUP_EDIT,
                ScreenRegistry.MP_DEVICE_TYPE_BROWSE,
                ScreenRegistry.MP_DEVICE_MODEL_BROWSE, ScreenRegistry.MP_DEVICE_MODEL_EDIT,
                ScreenRegistry.MP_DEVICE_STATUS_EDIT,
                // Параметры
                ScreenRegistry.MP_DEVICE_PARAM_TYPE_BROWSE,
                ScreenRegistry.MP_PARAM_TYPE_BROWSE,
                ScreenRegistry.MP_PARAM_GROUP_BROWSE, ScreenRegistry.MP_PARAM_GROUP_EDIT,
                ScreenRegistry.MP_PARAM_BROWSE, ScreenRegistry.MP_PARAM_EDIT,
                ScreenRegistry.MP_PARAM_UNIT_BROWSE,
                ScreenRegistry.MP_PARAM_UNIT_TYPE_BROWSE, ScreenRegistry.MP_PARAM_UNIT_TYPE_EDIT,
                ScreenRegistry.MP_DEVICE_MEAS_POINT_BROWSE, ScreenRegistry.MP_DEVICE_MEAS_POINT_EDIT,
                ScreenRegistry.MP_PARAM_UNIT_METRIC_PREFIX_BROWSE,
                ScreenRegistry.MP_TRANSFORM_FUNC_BROWSE,
                // Протоколы и поддержка
                ScreenRegistry.MP_DEVICE_PROTO_BROWSE, ScreenRegistry.MP_DEVICE_PROTO_EDIT,
                ScreenRegistry.MP_TECH_SUPPORT_BROWSE, ScreenRegistry.MP_TECH_SUPPORT_EDIT,
                // Дерево объектов РГК
                ScreenRegistry.MP_TREE_GROUP_BROWSE, ScreenRegistry.MP_TREE_GROUP_EDIT,
                ScreenRegistry.MP_TREE_OBJ_BROWSE, ScreenRegistry.MP_TREE_OBJ_EDIT,
                ScreenRegistry.MP_TECH_INFO_BROWSE, ScreenRegistry.MP_TECH_INFO_EDIT,
                // Технологические схемы
                ScreenRegistry.PROS_TECH_SCHEMA_MODEL_BROWSE, ScreenRegistry.PROS_TECH_SCHEMA_MODEL_EDIT,
                ScreenRegistry.PROS_TECH_SCHEMA_BROWSE, ScreenRegistry.PROS_TECH_SCHEMA_EDIT,
                // Каналы
                ScreenRegistry.MP_DEVICE_CHANNEL_BROWSE, ScreenRegistry.MP_DEVICE_CHANNEL_EDIT,
                // Организационные
                ScreenRegistry.DGCORE_DEPARTMENT_EDIT
        });

        // ===== application-mp-gro: основные экраны =====
        GROUPS.put(GRO_GROUP, new String[]{
                ScreenRegistry.APPLICATION_MP_GRO,
                ScreenRegistry.PROS_DASH_SCREEN,
                ScreenRegistry.MP_PRG_DEVICE_CURRENT_DATA,
                ScreenRegistry.MP_SKZ_DEVICE_CURRENT_DATA,
                ScreenRegistry.MP_ZA_DEVICE_CURRENT_DATA,
                ScreenRegistry.MP_AD_DEVICE_CURRENT_DATA,
                ScreenRegistry.PROS_DISP_SHIFT_MESSAGE_BROWSE,
                ScreenRegistry.PROS_DISP_SHIFT_RESPONSIBLE_BROWSE,
                ScreenRegistry.GRO_EVENTS
        });

        // ===== application-mp-gro - epu-stm-gro-config =====
        GROUPS.put(GRO_CONFIG_GROUP, new String[]{
                ScreenRegistry.APPLICATION_MP_GRO_CONFIG,
                ScreenRegistry.GRO_DEVICES,
                ScreenRegistry.MP_GRO_DEVICE_BROWSE,
                ScreenRegistry.GRO_DEVICE_PROTO_MODEL,
                ScreenRegistry.GRO_SERVICES,
                ScreenRegistry.GRO_THRESHOLDS,
                ScreenRegistry.GRO_IGNORES,
                ScreenRegistry.GRO_PLACE,
                ScreenRegistry.GRO_MP,
                ScreenRegistry.MP_WIDGET_SETTING_BROWSE
        });

        // ===== application-mp-gro - application-mp-dict-gro =====
        GROUPS.put(GRO_DICT_GROUP, new String[]{
                ScreenRegistry.APPLICATION_MP_DICT_GRO,
                ScreenRegistry.APPLICATION_MP_GRO_0,
                ScreenRegistry.APPLICATION_MP_GRO_1,
                ScreenRegistry.APPLICATION_MP_GRO_2,
                ScreenRegistry.APPLICATION_MP_GRO_3,
                ScreenRegistry.APPLICATION_MP_GRO_4,
                ScreenRegistry.APPLICATION_MP_GRO_5,
                ScreenRegistry.APPLICATION_MP_GRO_6,
                ScreenRegistry.APPLICATION_MP_GRO_7,
                ScreenRegistry.APPLICATION_MP_GRO_8,
                ScreenRegistry.APPLICATION_MP_GRO_9,
                ScreenRegistry.APPLICATION_MP_GRO_10,
                ScreenRegistry.APPLICATION_MP_GRO_11,
                ScreenRegistry.APPLICATION_MP_GRO_12,
                ScreenRegistry.APPLICATION_MP_GRO_13,
                ScreenRegistry.GRO_PROTO,
                ScreenRegistry.TREE_GROUP_GRO,
                ScreenRegistry.TREE_OBJ_GRO,
                ScreenRegistry.TREE_INFO_GRO,
                ScreenRegistry.TREE_TECHSCHEMA_GRO
        });

        // ===== docs =====
        GROUPS.put(DOCS_GROUP, new String[]{
                ScreenRegistry.DOCS,
                ScreenRegistry.MP_DOCUMENT_BROWSE
        });

        // ===== reports =====
        GROUPS.put(REPORTS_GROUP, new String[]{
                ScreenRegistry.REPORTS,
                ScreenRegistry.REPORT_REPORT_BROWSE,
                ScreenRegistry.REPORT_REPORT_GROUP_BROWSE,
                ScreenRegistry.REPORT_REPORT_RUN
        });

        // ===== administration =====
        GROUPS.put(ADMIN_GROUP, new String[]{
                ScreenRegistry.ADMINISTRATION,
                ScreenRegistry.SEC_USER_BROWSE,
                ScreenRegistry.SEC_GROUP_BROWSE,
                ScreenRegistry.SEC_ROLE_BROWSE,
                ScreenRegistry.SYS_CATEGORY_BROWSE,
                ScreenRegistry.APPLICATION_DDCA,
                ScreenRegistry.DDCA_ATTACHMENT_ALL_BROWSE,
                ScreenRegistry.DDCA_ATTACHMENT_CATEGORY_BROWSE,
                ScreenRegistry.SYS_FILE_DESCRIPTOR_BROWSE,
                ScreenRegistry.SYS_SCHEDULED_TASK_BROWSE,
                ScreenRegistry.ENTITY_RESTORE,
                ScreenRegistry.APP_PROPERTIES,
                ScreenRegistry.ENTITY_LOG,
                ScreenRegistry.SYS_SENDING_MESSAGE_BROWSE,
                ScreenRegistry.SERVER_LOG,
                ScreenRegistry.PERFORMANCE_STATISTICS
        });

        // ===== grafana =====
        GROUPS.put(GRAFANA_GROUP, new String[]{
                ScreenRegistry.GRAFANA
        });

        // ===== Фильтры и диалоги =====
        GROUPS.put(COMMON_UI_DIALOGS, new String[]{
                ScreenRegistry.BULK_EDITOR,
                ScreenRegistry.SAVE_FILTER,
                ScreenRegistry.ADD_CONDITION,
                ScreenRegistry.FILTER_EDITOR,
                ScreenRegistry.FILTER_SELECT,
                ScreenRegistry.REPORT_INPUT_PARAMETERS,
                ScreenRegistry.PROS_DAILY_REPORT_SCREEN,
                ScreenRegistry.PROS_PGPICKER,
                ScreenRegistry.PASSPORT_KAS_EDIT,
                ScreenRegistry.INPUT_DIALOG,
                ScreenRegistry.DGEPU_KP_CONFIGURATION_SCREEN,
                ScreenRegistry.MP_DEVICE_POLLING_EDIT,
                ScreenRegistry.DGEPU_FRAGMENT_SCREEN,
                ScreenRegistry.PROS_JOURNAL_MESSAGE_DIALOG
        });

        // ===== Экраны действий с устройствами =====
        GROUPS.put(DEVICE_ACTIONS, new String[]{
                ScreenRegistry.MP_DEVICE_ACTION_BROWSE, ScreenRegistry.MP_DEVICE_ACTION_EDIT,
                ScreenRegistry.POLL_RESULTS_SCREEN,
                ScreenRegistry.MP_DEVICE_COMMENT_BROWSE,
                ScreenRegistry.DGEPU_BATCH_OPERATION,
        });

        // ===== Экраны отчётов и дашбордов =====
        GROUPS.put(REPORTS_EXTENDED, new String[]{
                ScreenRegistry.PROS_CHART_TABLE_SCREEN,
                ScreenRegistry.PROS_CHART_DATA,
                ScreenRegistry.PROS_OBJ_REPORT_BY_PERIOD,
                ScreenRegistry.REPORT_REPORT_EDIT,
                ScreenRegistry.REPORT_REPORT_GROUP_EDIT ,
                ScreenRegistry.REPORT_SHOW_CHART,
                ScreenRegistry.REPORT_SHOW_REPORT_TABLE,
                ScreenRegistry.REPORT_SHOW_PIVOT_TABLE
        });

        // ===== Экраны безопасности и мониторинга =====
        GROUPS.put(ADMIN_SECURITY_EXTENDED, new String[]{
                ScreenRegistry.DGEPU_ENTITY_LOG_BROWSE,
                ScreenRegistry.SEC_USER_EDIT,
                ScreenRegistry.SEC_USER_CHANGE_PASSWORD,
                ScreenRegistry.SEC_USER_RESET_PASSWORDS,
                ScreenRegistry.SEC_GROUP_EDIT,
                ScreenRegistry.SEC_ROLE_LOOKUP
        });

        // ===== Экраны настроек устройств =====
        GROUPS.put(DEVICE_SETTINGS, new String[]{
                ScreenRegistry.MP_DEVICE_RECALC_SETTINGS_EDIT,
                ScreenRegistry.MP_DEFAULT_DEVICE_SETTINGS_BROWSE,
                ScreenRegistry.MP_DRIVER_ERRORS_SCREEN
        });
    }

    public static String[] getScreens(String groupKey) {
        if (groupKey == null) return new String[0];
        String[] screens = GROUPS.get(groupKey);
        return screens != null ? screens : new String[0];
    }

    public static Set<String> getAllKeys() {
        return Collections.unmodifiableSet(GROUPS.keySet());
    }
}