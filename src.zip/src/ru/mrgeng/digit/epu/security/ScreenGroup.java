package ru.mrgeng.digit.epu.security;

import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(ScreenGroup.List.class)
public @interface ScreenGroup {

    /**
     * Ключ группы экранов из {@link ru.mrgeng.digit.epu.security.ScreenGroupRegistry}.
     */
    String value();

    @Target({ElementType.METHOD})
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
        ScreenGroup[] value();
    }
}
