package ru.mrgeng.digit.epu.gis;

import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.dgcore.GisUtils;

import javax.persistence.AttributeConverter;

/**
 * Конвертор координата <-> Point для хранения точечных объектов в атримбутах Entity
 *
 * В каждом хранилище persistence.xml должен быть свой уникальный конвертор
 */
public class BaseCoordConvertor implements AttributeConverter<Point, String> {

    @Override
    public String convertToDatabaseColumn(Point point) {
        return point != null ? point.getY() + " " +  point.getX(): null;
    }

    @Override
    public Point convertToEntityAttribute(String s) {
        return s != null ? GisUtils.INSTANCE.stringToPoint(s.trim()) : null;
    }
}
