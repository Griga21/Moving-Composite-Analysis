package ru.mrgeng.digit.epu.gis;

import com.haulmont.addon.maps.gis.utils.GeometryUtils;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.postgis.Geometry;
import org.postgis.PGgeometry;
import org.postgresql.util.PGobject;

import javax.persistence.AttributeConverter;
import java.sql.SQLException;

/**
 * Конвертор PostGIS geometry <-> Point для хранения точечных объектов в атрибутах Entity.
 * В каждом хранилище persistence.xml должен быть свой уникальный конвертор
 */
public class BasePostgisPointConvertor implements AttributeConverter<Point, PGobject> {

    private static final String GEOMETRY_TYPE = "geometry";

    final static GeometryFactory gf = GeometryUtils.getGeometryFactory();

    @Override
    public org.postgresql.util.PGobject convertToDatabaseColumn(Point point) {
        return point != null ? new PGgeometry(new org.postgis.Point(point.getX(), point.getY())) : null;
    }

    @Override
    public Point convertToEntityAttribute(org.postgresql.util.PGobject pgObj) {
        if (pgObj != null && pgObj.getType().equals(GEOMETRY_TYPE)) {
            try {
                PGgeometry pg = new PGgeometry(pgObj.getValue());
                if (pg.getGeoType() == Geometry.POINT) {
                    org.postgis.Point p = (org.postgis.Point) pg.getGeometry();
                    return gf.createPoint(new Coordinate(p.x, p.y));
                }
            } catch (SQLException exc) {
                throw new IllegalArgumentException(exc);
            }
        }
        return null;
    }
}
