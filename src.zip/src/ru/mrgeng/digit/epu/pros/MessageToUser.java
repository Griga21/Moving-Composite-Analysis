package ru.mrgeng.digit.epu.pros;


import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.param.SeriousLevel;

import java.io.Serializable;

/**
 * Сообщение, уведомление
 */
public class MessageToUser implements Serializable {
    public String from;
    public SeriousLevel level;
    public String msg;
    public Long id;
    public Device device;
    public boolean isNormalize = false;
    public boolean show = true;
}
