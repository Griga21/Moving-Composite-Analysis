package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum HandBookStatus implements EnumClass<Integer> {
    OPEN(10),
    CLOSED(20);

    private final Integer id;

    HandBookStatus(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static HandBookStatus fromId(Integer id) {
        for (HandBookStatus at : HandBookStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
