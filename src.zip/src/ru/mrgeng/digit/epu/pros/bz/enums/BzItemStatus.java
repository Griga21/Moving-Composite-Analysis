package ru.mrgeng.digit.epu.pros.bz.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum BzItemStatus implements EnumClass<Integer> {
    PROJECTED(10),
    END_BUILDING(20),
    IN_EXPLOITATION(30),
    OUT_EXPLOITATION(40),
    LIQUIDATED(50),
    REBUILDING_PROJECT(60),
    REBUILDING_SMR(70),
    UNKNOWN(80);

    private final Integer id;

    BzItemStatus(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static BzItemStatus fromId(Integer id) {
        for (BzItemStatus at : BzItemStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
