package ru.mrgeng.digit.epu.pros.bz.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum PerformedType implements EnumClass<Integer> {
    UNDER(10),
    ON(20),
    ABOVE(30);

    private final Integer id;

    PerformedType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static PerformedType fromId(Integer id) {
        for (PerformedType at : PerformedType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
