package ru.mrgeng.digit.epu.pros.bz.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ValveType implements EnumClass<Integer> {
    GATE(10),
    VALVE(20),
    CRAN(30),
    OTHER(40);

    private final Integer id;

    ValveType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ValveType fromId(Integer id) {
        for (ValveType at : ValveType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
