package ru.mrgeng.digit.epu.pros.bz.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum GrpType implements EnumClass<Integer> {
    GRP(10),
    GGRP(30),
    GRU(40),
    GRPB(50),
    GRPSH(60),
    SHRP(70);

    private final Integer id;

    GrpType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static GrpType fromId(Integer id) {
        for (GrpType at : GrpType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
