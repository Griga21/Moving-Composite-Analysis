package ru.mrgeng.digit.epu.pros.bz;

import ru.mrgeng.digit.epu.mp.MeasParamsMdObj;
import ru.mrgeng.digit.epu.pros.bz.enums.GrsServiceType;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.UUID;

@Table(name = "DGEPU_GRS")
@Entity(name = "pros_Grs")
public class Grs extends MeasParamsMdObj {
    private static final long serialVersionUID = 4312192487482163523L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LPUTRANSGAZ_ID")
    private LpuTransGaz lpuTransGaz;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GRSTYPE_ID")
    private GrsType grsType;

    @Column(name = "GRS_SERVICE_TYPE")
    private Integer grsServiceType;

    @Column(name = "COMMISSIONING_DATE")
    private LocalDate commissioningDate;

    @Column(name = "FIAS_ADDRESS_STRING")
    private String fiasAddressString;

    @Column(name = "FIAS_ADDRESS_GUID")
    private UUID fiasAddressGuid;

    public GrsServiceType getGrsServiceType() {
        return grsServiceType == null ? null : GrsServiceType.fromId(grsServiceType) ;
    }

    public void setGrsServiceType(GrsServiceType grsServiceType) {
        this.grsServiceType = grsServiceType == null ? null : grsServiceType.getId();
    }

    public LpuTransGaz getLpuTransGaz() {
        return lpuTransGaz;
    }

    public void setLpuTransGaz(LpuTransGaz lpuTransGaz) {
        this.lpuTransGaz = lpuTransGaz;
    }

    public GrsType getGrsType() {
        return grsType;
    }

    public void setGrsType(GrsType grsType) {
        this.grsType = grsType;
    }

    public LocalDate getCommissioningDate() {
        return commissioningDate;
    }

    public void setCommissioningDate(LocalDate commissioningDate) {
        this.commissioningDate = commissioningDate;
    }

    public String getFiasAddressString() {
        return fiasAddressString;
    }

    public void setFiasAddressString(String fiasAddressString) {
        this.fiasAddressString = fiasAddressString;
    }

    public UUID getFiasAddressGuid() {
        return fiasAddressGuid;
    }

    public void setFiasAddressGuid(UUID fiasAddressGuid) {
        this.fiasAddressGuid = fiasAddressGuid;
    }
}
