package ru.mrgeng.digit.epu.pros.bz;

import ru.mrgeng.digit.epu.mp.MeasParamsMdObj;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_TRANS_GAZ")
@Entity(name = "pros_TransGaz")
public class TransGaz extends MeasParamsMdObj {
    private static final long serialVersionUID = -2876790403918719175L;
}
