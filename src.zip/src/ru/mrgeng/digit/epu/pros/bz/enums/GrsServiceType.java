package ru.mrgeng.digit.epu.pros.bz.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum GrsServiceType implements EnumClass<Integer> {
    HOME(10),
    CENTRAL(20),
    WATCH(30);

    private final Integer id;

    GrsServiceType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static GrsServiceType fromId(Integer id) {
        for (GrsServiceType at : GrsServiceType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
