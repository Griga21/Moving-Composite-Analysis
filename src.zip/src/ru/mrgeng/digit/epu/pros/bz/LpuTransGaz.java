package ru.mrgeng.digit.epu.pros.bz;

import ru.mrgeng.digit.epu.mp.MeasParamsMdObj;

import javax.persistence.*;

@Table(name = "DGEPU_LPU_TRANS_GAZ")
@Entity(name = "pros_LpuTransGaz")
public class LpuTransGaz extends MeasParamsMdObj {
    private static final long serialVersionUID = -1769002879681590358L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TRANSGAZ_ID")
    private TransGaz transGaz;

    public TransGaz getTransGaz() {
        return transGaz;
    }

    public void setTransGaz(TransGaz transGaz) {
        this.transGaz = transGaz;
    }
}
