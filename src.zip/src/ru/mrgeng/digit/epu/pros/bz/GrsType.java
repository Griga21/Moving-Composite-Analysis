package ru.mrgeng.digit.epu.pros.bz;

import ru.mrgeng.digit.epu.mp.MeasParamsMdObj;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_GRS_TYPE")
@Entity(name = "pros_GrsType")
public class GrsType extends MeasParamsMdObj {
    private static final long serialVersionUID = -6928458656345893427L;
}
