package ru.mrgeng.digit.epu.pros.bz;

import com.haulmont.addon.maps.gis.Geometry;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.dgcore.entity.Department;
import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.pros.bz.enums.BzItemStatus;
import ru.mrgeng.digit.epu.pros.bz.enums.GrpType;
import ru.mrgeng.digit.epu.pros.ProsPostgisPointConvertor;
import ru.mrgeng.digit.epu.pros.bz.enums.GrpPerformedType;
import ru.mrgeng.digit.epu.pros.BzNameExtensionI;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.UUID;

@Table(name = "DGEPU_GRP")
@Entity(name = "pros_Grp")
@NamePattern("%s|name")
public class Grp extends MdObj implements BzNameExtensionI {
    private static final long serialVersionUID = 1L;

    @Column(name = "STATUS")
    private Integer status;

    @Column(name = "GRP_TYPE")
    private Integer grpType;

    @Column(name = "PERFORMED")
    private Integer grpPerformedType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEPARTMENT_ID")
    private Department department;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "OWNERSHIP_ID")
    private PropertyOwnership ownership;

    @Column(name = "PHONE")
    private String phone;

    @Column(name = "ADDRESS", length = 512)
    private String address;

    @Column(name = "FIAS_ADDRESS_STRING")
    private String fiasAddressString;

    @Column(name = "FIAS_ADDRESS_GUID")
    private UUID fiasAddressGuid;

    @Column(name = "COMMISSIONING_DATE")
    private LocalDate commissioningDate;

    @Column(name = "EXPLOITATION_NUM")
    private String exploitationNum;

    @Column(name = "LIGHTNING_PROTECTION")
    private Boolean lightningProtection;

    @Column(name = "OPERATION_PERIOD")
    private Double operationPeriod;

    @Column(name = "INVENTORY_NUM")
    private String inventoryNum;

    @Column(name = "IN_PRESSURE_FACT")
    private Double inPressureFact;

    @Column(name = "IN_PRESSURE_PROJECT")
    private Double inPressureProject;

    @Column(name = "LOCATION", columnDefinition = "geometry")
    @Geometry
    @MetaProperty(datatype = "coord")
    @Convert(converter = ProsPostgisPointConvertor.class)
    private Point location;

    public GrpPerformedType getGrpPerformedType() {
        return grpPerformedType == null ? null : GrpPerformedType.fromId(grpPerformedType);
    }

    public void setGrpPerformedType(GrpPerformedType grpPerformedType) {
        this.grpPerformedType = grpPerformedType == null ? null : grpPerformedType.getId();
    }

    public GrpType getGrpType() {
        return grpType == null ? null : GrpType.fromId(grpType);
    }

    public void setGrpType(GrpType grpType) {
        this.grpType = grpType == null ? null : grpType.getId();
    }

    public BzItemStatus getStatus() {
        return status == null ? null : BzItemStatus.fromId(status);
    }

    public void setStatus(BzItemStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFiasAddressString() {
        return fiasAddressString;
    }

    public void setFiasAddressString(String fiasAddressString) {
        this.fiasAddressString = fiasAddressString;
    }

    public UUID getFiasAddressGuid() {
        return fiasAddressGuid;
    }

    public void setFiasAddressGuid(UUID fiasAddressGuid) {
        this.fiasAddressGuid = fiasAddressGuid;
    }

    public LocalDate getCommissioningDate() {
        return commissioningDate;
    }

    public void setCommissioningDate(LocalDate commissioningDate) {
        this.commissioningDate = commissioningDate;
    }

    public String getExploitationNum() {
        return exploitationNum;
    }

    public void setExploitationNum(String exploitationNum) {
        this.exploitationNum = exploitationNum;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Boolean getLightningProtection() {
        return lightningProtection;
    }

    public void setLightningProtection(Boolean lightningProtection) {
        this.lightningProtection = lightningProtection;
    }

    public Double getOperationPeriod() {
        return operationPeriod;
    }

    public void setOperationPeriod(Double operationPeriod) {
        this.operationPeriod = operationPeriod;
    }

    public String getInventoryNum() {
        return inventoryNum;
    }

    public void setInventoryNum(String inventoryNum) {
        this.inventoryNum = inventoryNum;
    }

    public Double getInPressureFact() {
        return inPressureFact;
    }

    public void setInPressureFact(Double inPressureFact) {
        this.inPressureFact = inPressureFact;
    }

    public Double getInPressureProject() {
        return inPressureProject;
    }

    public void setInPressureProject(Double inPressureProject) {
        this.inPressureProject = inPressureProject;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public PropertyOwnership getOwnership() {
        return ownership;
    }

    public void setOwnership(PropertyOwnership ownership) {
        this.ownership = ownership;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Grp-" + id;
    }

    @Override
    public String getTreeElementName() {
        return getName() == null ? toString() : getName();
    }
}
