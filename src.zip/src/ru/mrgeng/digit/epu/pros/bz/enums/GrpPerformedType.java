package ru.mrgeng.digit.epu.pros.bz.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum GrpPerformedType implements EnumClass<Integer> {
    CASE(10),
    BLOC(20),
    STATIC(30),
    REGULATE_DEVISE(40);

    private final Integer id;

    GrpPerformedType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static GrpPerformedType fromId(Integer id) {
        for (GrpPerformedType at : GrpPerformedType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
