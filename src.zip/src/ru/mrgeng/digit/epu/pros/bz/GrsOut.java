package ru.mrgeng.digit.epu.pros.bz;

import ru.mrgeng.digit.epu.mp.MeasParamsMdObj;
import ru.mrgeng.digit.epu.pros.BzNameExtensionI;

import javax.persistence.*;

@Table(name = "DGEPU_GRS_OUT")
@Entity(name = "pros_GrsOut")
public class GrsOut extends MeasParamsMdObj implements BzNameExtensionI {
    private static final long serialVersionUID = 8876285582721626775L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GRS_ID")
    private Grs grs;

    @Column(name = "PRESSURE_WORK_FACT")
    private Double pressureWorkFact;

    @Column(name = "PRESSURE_PROJECT_MAX")
    private Double pressureProjectMax;

    @Column(name = "PRESSURE_PROJECT_MIN")
    private Double pressureProjectMin;

    @Column(name = "QUANT_YEAR")
    private Double quantYear;

    @Column(name = "QUANT_HOUR_MIDDLE")
    private Double quantHourMiddle;

    @Column(name = "QUANT_HOUR_PROJECT_MAX")
    private Double quantHourProjectMax;

    public Double getPressureWorkFact() {
        return pressureWorkFact;
    }

    public void setPressureWorkFact(Double pressureWorkFact) {
        this.pressureWorkFact = pressureWorkFact;
    }

    public Double getPressureProjectMax() {
        return pressureProjectMax;
    }

    public void setPressureProjectMax(Double pressureProjectMax) {
        this.pressureProjectMax = pressureProjectMax;
    }

    public Double getPressureProjectMin() {
        return pressureProjectMin;
    }

    public void setPressureProjectMin(Double pressureProjectMin) {
        this.pressureProjectMin = pressureProjectMin;
    }

    public Grs getGrs() {
        return grs;
    }

    public void setGrs(Grs grs) {
        this.grs = grs;
    }

    public Double getQuantYear() {
        return quantYear;
    }

    public void setQuantYear(Double quantYear) {
        this.quantYear = quantYear;
    }

    public Double getQuantHourMiddle() {
        return quantHourMiddle;
    }

    public void setQuantHourMiddle(Double quantHourMiddle) {
        this.quantHourMiddle = quantHourMiddle;
    }

    public Double getQuantHourProjectMax() {
        return quantHourProjectMax;
    }

    public void setQuantHourProjectMax(Double quantHourProjectMax) {
        this.quantHourProjectMax = quantHourProjectMax;
    }

    @Override
    public String toString() {
        return "GrsOut-" + id;
    }

    @Override
    public String getTreeElementName() {
        return getName() == null ? toString() : getName();
    }
}
