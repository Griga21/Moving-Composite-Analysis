package ru.mrgeng.digit.epu.pros.bz;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.dgcore.entity.Company;
import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.pros.bz.enums.*;

import javax.persistence.*;
import java.time.LocalDate;

@Table(name = "DGEPU_VALVE")
@Entity(name = "pros_Valve")
@NamePattern("%s|name")
public class Valve extends MdObj {
    private static final long serialVersionUID = -3929457691037833857L;

    @Column(name = "CODE_ID")
    private String code;

    @Column(name = "DIAMETER")
    private Double diameter;

    @Column(name = "BRAND")
    private String brand;

    @JoinColumn(name = "PRODUCER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Company producer;

    @Column(name = "PRESSURE_WORK")
    private Double pressureWork;

    @Column(name = "MOUNT")
    private LocalDate mountDate;

    @Column(name = "COMMENT")
    private String comment;

    @Column(name = "RASPRED")
    private Boolean raspred;

    @Column(name = "VALVE_TYPE")
    private Integer valveType;

    @Column(name = "PERFORMED")
    private Integer performedType;

    public PerformedType getPerformedType() {
        return performedType == null ? null : PerformedType.fromId(performedType);
    }

    public void setPerformedType(PerformedType performedType) {
        this.performedType = performedType == null ? null : performedType.getId();
    }

    public ValveType getValveType() {
        return valveType == null ? null : ValveType.fromId(valveType);
    }

    public void setValveType(ValveType valveType) {
        this.valveType = valveType == null ? null : valveType.getId();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Double getDiameter() {
        return diameter;
    }

    public void setDiameter(Double diameter) {
        this.diameter = diameter;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Company getProducer() {
        return producer;
    }

    public void setProducer(Company producer) {
        this.producer = producer;
    }

    public Double getPressureWork() {
        return pressureWork;
    }

    public void setPressureWork(Double pressureWork) {
        this.pressureWork = pressureWork;
    }

    public LocalDate getMountDate() {
        return mountDate;
    }

    public void setMountDate(LocalDate mountDate) {
        this.mountDate = mountDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getRaspred() {
        return raspred;
    }

    public void setRaspred(Boolean raspred) {
        this.raspred = raspred;
    }
}
