package ru.mrgeng.digit.epu.pros.bz;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_PROPERTY_OWNERSHIP")
@Entity(name = "pros_PropertyOwnership")
@NamePattern("%s|name")
public class PropertyOwnership extends Dict {
    private static final long serialVersionUID = 5834985123047393339L;
}
