package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

public enum AsuTpSubjectType implements EnumClass<Integer> {
    GRP_TYPE(10),
    VALVE_TYPE(20),
    SKZ_TYPE(30);

    private final Integer id;

    AsuTpSubjectType(Integer id) {
        this.id = id;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public static AsuTpSubjectType fromId(Integer id) {
        for(AsuTpSubjectType type : AsuTpSubjectType.values()) {
            if(type.getId().equals(id))
                return type;
        }
        return null;
    }
}
