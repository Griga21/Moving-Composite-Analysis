package ru.mrgeng.digit.epu.pros;

import com.haulmont.addon.maps.gis.Geometry;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.dgcore.entity.Department;
import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.mp.Device;

import javax.persistence.*;
import java.time.LocalDate;

@Table(name = "DGEPU_SKZ_OBJ")
@Entity(name = "pros_SkzObj")
@NamePattern("%s|name")
public class SkzObj extends MdObj {
    private static final long serialVersionUID = 5819396621750388918L;

    @Column(name = "COMMISSIONING_DATE")
    private LocalDate commissioningDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEPARTMENT_ID")
    private Department department;

    @Column(name = "ADDRESS", length = 500)
    private String address;

    @Column(name = "LOCATION", columnDefinition = "geometry")
    @Geometry
    @MetaProperty(datatype = "coord")
    @Convert(converter = ProsPostgisPointConvertor.class)
    private Point location;

    @SystemLevel
    @Column(name = "DEVICE_ID")
    private Long deviceId;

    @MetaProperty(related = "deviceId")
    @Transient
    private Device device;

    public LocalDate getCommissioningDate() {
        return commissioningDate;
    }

    public void setCommissioningDate(LocalDate commissioningDate) {
        this.commissioningDate = commissioningDate;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public Long getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Long deviceId) {
        this.deviceId = deviceId;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }
}
