package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_GAS_METER_TYPE_SIZE")
@Entity(name = "pros_GasMeterTypeSize")
public class GasMeterTypeSize extends Dict {
    private static final long serialVersionUID = -987670769116962184L;
}
