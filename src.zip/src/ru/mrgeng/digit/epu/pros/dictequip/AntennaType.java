package ru.mrgeng.digit.epu.pros.dictequip;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import ru.mrgeng.digit.dgcore.entity.Dict;

@Table(name = "DGEPU_ANTENNA_TYPE")
@Entity(name = "pros_AntennaType")
public class AntennaType extends Dict {
    private static final long serialVersionUID = 4721978661031701621L;

    @Column(name = "ABOUT")
    private String about;

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }
}
