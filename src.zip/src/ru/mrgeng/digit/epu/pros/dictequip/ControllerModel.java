package ru.mrgeng.digit.epu.pros.dictequip;

import com.haulmont.chile.core.annotations.Composition;
import com.haulmont.cuba.core.entity.annotation.OnDelete;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.epu.pros.EquipModel;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_CONTROLLER_MODEL")
@Entity(name = "pros_ControllerModel")
public class ControllerModel extends EquipModel {
    private static final long serialVersionUID = 4112152224621840459L;

    @Column(name = "TEMPERATURE_MAX", length = 4)
    private String temperaturemax;

    @Column(name = "TEMPERATURE_MIN", length = 4)
    private String temperaturemin;

    @Column(name = "GSMMODULE_COUNT")
    private Integer gsmmoduleCount;

    @Column(name = "PROTECTION_DEGREE")
    private String protectionDegree;

    @Column(name = "MAX_CURRENT")
    private Integer maxCurrent;

    @Column(name = "EXTERNAL_POWERUNIT_NEED")
    private Boolean externalPowerunitNeed;

    @Column(name = "HASBATTARY")
    private Boolean hasbattary;

    @Column(name = "BATTARY_LIFE")
    private Integer battaryLife;

    @ManyToMany
    @JoinTable(name = "DGEPU_CONTROLLER_MODEL_EQUIP_INTERFACE_LINK",
            joinColumns = @JoinColumn(name = "CONTROLLER_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "EQUIP_INTERFACE_ID"))
    private List<EquipInterface> equipInterfaces;

    @ManyToMany
    @JoinTable(name = "DGEPU_CONTROLLER_MODEL_BATTERY_TYPE_LINK",
            joinColumns = @JoinColumn(name = "CONTROLLER_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "BATTERY_TYPE_ID"))
    private List<BatteryType> batteryTypeList;

    @ManyToMany
    @JoinTable(name = "DGEPU_CONTROLLER_MODEL_DATA_TRANSFER_METHOD_LINK",
            joinColumns = @JoinColumn(name = "CONTROLLER_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "DATA_TRANSFER_METHOD_ID"))
    private List<DataTransferMethod> dataTransferMethods;

    @ManyToMany
    @JoinTable(name = "DGEPU_CONTROLLER_MODEL_EXTERNAL_POWER_LINK",
            joinColumns = @JoinColumn(name = "CONTROLLER_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"))
    private List<ExternalPower> externalPowers;


    @ManyToMany
    @JoinTable(name = "DGEPU_CONTROLLER_MODEL_TRANSFER_PROTOCOL_LINK",
            joinColumns = @JoinColumn(name = "CONTROLLER_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "TRANSFER_PROTOCOL_ID"))
    private List<TransferProtocol> transferProtocols;

    @Composition
    @OnDelete(DeletePolicy.CASCADE)
    @OneToMany(mappedBy = "controllerModel")
    protected List<ControllerModelInoutputLink> controllerModelInoutputLinks;

    public void setTemperaturemax(String temperaturemax) {
        this.temperaturemax = temperaturemax;
    }

    public String getTemperaturemax() { return temperaturemax; }

    public void setTemperaturemin(String temperaturemin) {
        this.temperaturemin = temperaturemin;
    }

    public String getTemperaturemin() { return temperaturemin;  }

    public void setGsmmoduleCount(Integer gsmmoduleCount) {
        this.gsmmoduleCount = gsmmoduleCount;
    }

    public Integer getGsmmoduleCount() { return gsmmoduleCount;    }

    public void setProtectionDegree(String protectionDegree) {
        this.protectionDegree = protectionDegree;
    }

    public String getProtectionDegree() { return protectionDegree;    }

    public void setMaxCurrent(Integer maxCurrent) {
        this.maxCurrent = maxCurrent;
    }

    public Integer getMaxCurrent() {  return maxCurrent;   }

    public void setHasbattary(Boolean hasbattary) {
        this.hasbattary = hasbattary;
    }

    public void setEquipInterfaces(List<EquipInterface> equipInterfaces) {
        this.equipInterfaces = equipInterfaces;
    }

    public List<EquipInterface> getEquipInterfaces() {
        return equipInterfaces;
    }

    public void setBatteryTypeList(List<BatteryType> batteryTypeList) {
        this.batteryTypeList = batteryTypeList;
    }

    public List<BatteryType> getBatteryTypeList() {
        return batteryTypeList;
    }

    public void setDataTransferMethods(List<DataTransferMethod> dataTransferMethods) {
        this.dataTransferMethods = dataTransferMethods;
    }

    public List<DataTransferMethod> getDataTransferMethods() {
        return dataTransferMethods;
    }

    public void setExternalPowers(List<ExternalPower> externalPowers) {
        this.externalPowers = externalPowers;
    }

    public List<ExternalPower> getExternalPowers() {
        return externalPowers;
    }

    public void setTransferProtocols(List<TransferProtocol> transferProtocols) {
        this.transferProtocols = transferProtocols;
    }

    public List<TransferProtocol> getTransferProtocols() {
        return transferProtocols;
    }

    public void setExternalPowerunitNeed(Boolean externalPowerunitNeed) {
        this.externalPowerunitNeed = externalPowerunitNeed;
    }

    public Boolean getExternalPowerunitNeed() {
        return externalPowerunitNeed;
    }

    public Boolean getHasbattary() {
        return hasbattary;
    }

    public void setBattaryLife(Integer battaryLife) {
        this.battaryLife = battaryLife;
    }

    public Integer getBattaryLife() {
        return battaryLife;
    }

    public void setControllerModelInoutputLinks (List<ControllerModelInoutputLink> controllerModelInoutputLinks) {
        this.controllerModelInoutputLinks=controllerModelInoutputLinks;
    }

    public List<ControllerModelInoutputLink> getControllerModelInoutputLinks(){
        return controllerModelInoutputLinks;
    }
}
