package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;
import ru.mrgeng.digit.epu.pros.equipparam.ElectricCurrentType;
import ru.mrgeng.digit.epu.pros.equipparam.NominalVoltage;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_EXTERNAL_POWER")
@Entity(name = "pros_ExternalPower")
public class ExternalPower extends Dict {
    private static final long serialVersionUID = 5505275884237772364L;

    @Column(name = "ELECTRIC_CURRENT")
    private Integer electricCurrent;

    @Column(name = "NOMINAL_VOLTAGE")
    private Integer nominalVoltage;

    @JoinTable(name = "DGEPU_MODEM_MODEL_EXTERNAL_POWER_LINK",
            joinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModels;

    @JoinTable(name = "DGEPU_POWER_UNIT_EXTERNAL_POWER_LINK",
            joinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"),
            inverseJoinColumns = @JoinColumn(name = "POWER_UNIT_ID"))
    @ManyToMany
    private List<PowerUnit> powerUnits;

    @JoinTable(name = "DGEPU_POWER_UNIT_OUT_POWER_LINK",
            joinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"),
            inverseJoinColumns = @JoinColumn(name = "POWER_UNIT_ID"))
    @ManyToMany
    private List<PowerUnit> outpowerUnits;


    public List<ModemModel> getModemModels() {
        return modemModels;
    }

    public void setModemModels(List<ModemModel> modemModels) {
        this.modemModels = modemModels;
    }

    public NominalVoltage getNominalVoltage() {
        return nominalVoltage == null ? null : NominalVoltage.fromId(nominalVoltage);
    }

    public void setNominalVoltage(NominalVoltage nominalVoltage) {
        this.nominalVoltage = nominalVoltage == null ? null : nominalVoltage.getId();
    }

    public ElectricCurrentType getElectricCurrent() {
        return electricCurrent == null ? null : ElectricCurrentType.fromId(electricCurrent);
    }

    public void setElectricCurrent(ElectricCurrentType electricCurrent) {
        this.electricCurrent = electricCurrent == null ? null : electricCurrent.getId();
    }

    public List<PowerUnit> getPowerUnits() { return powerUnits; }

    public void setPowerUnits(List<PowerUnit> powerUnits) { this.powerUnits = powerUnits; }

    public List<PowerUnit> getOutpowerUnits() {
        return outpowerUnits;
    }

    public void setOutpowerUnits(List<PowerUnit> outpowerUnits) {
        this.outpowerUnits = outpowerUnits;
    }
}
