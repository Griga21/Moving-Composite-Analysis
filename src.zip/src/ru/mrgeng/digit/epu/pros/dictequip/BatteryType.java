package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_BATTERY_TYPE")
@Entity(name = "pros_BatteryType")
public class BatteryType extends Dict {
    private static final long serialVersionUID = 3570063281291572270L;

    @Column(name = "SHORT_NAME", length = 64)
    private String shortName;

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }
}
