package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.MdObj;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_CONNECTION_TECH")
@Entity(name = "pros_ConnectionTech")
public class ConnectionTech extends MdObj {
    private static final long serialVersionUID = 8750890794007936832L;
}
