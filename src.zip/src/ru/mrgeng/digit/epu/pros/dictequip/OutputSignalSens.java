package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.pros.equipparam.SignalParam;
import ru.mrgeng.digit.epu.pros.equipparam.SignalType;

import javax.persistence.*;

@Table(name = "DGEPU_OUTPUT_SIGNAL_SENS")
@Entity(name = "pros_OutputSignalSens")
public class OutputSignalSens extends MdObj {
    private static final long serialVersionUID = -1809377180965777118L;

    @Column(name = "SIGNAL_TYPE")
    private Integer signalType;

    @Column(name = "SIGNAL_PARAM")
    private Integer signalParam;

    @Column(name = "SIGNAL")
    private String signal;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SENS_INTERFACE")
    private EquipInterface equipInterface;

    public SignalType getSignalType (){
        return signalType== null ? null : SignalType.fromId(signalType);
    }

    public void setSignalType(SignalType signalType) {
        this.signalType = signalType == null ? null : signalType.getId();
    }

    public SignalParam getSignalParam (){
        return signalParam== null ? null : SignalParam.fromId(signalParam);
    }

    public void setSignalParam(SignalParam signalParam) {
        this.signalParam = signalParam == null ? null : signalParam.getId();
    }

    public String getSignal() {
        return signal;
    }

    public void setSignal(String signal) {
        this.signal = signal;
    }

    public EquipInterface getEquipInterface() {
        return equipInterface;
    }

    public void setEquipInterface(EquipInterface equipInterface) {
        this.equipInterface = equipInterface;
    }
}
