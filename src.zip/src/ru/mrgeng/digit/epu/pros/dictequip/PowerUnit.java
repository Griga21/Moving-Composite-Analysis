package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.epu.pros.EquipModel;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_POWER_UNIT")
@Entity(name = "pros_PowerUnit")
public class PowerUnit extends EquipModel {
    private static final long serialVersionUID = -2114559090328716686L;

    @ManyToMany
    @JoinTable(name = "DGEPU_POWER_UNIT_EXTERNAL_POWER_LINK",
            joinColumns = @JoinColumn(name = "POWER_UNIT_ID"),
            inverseJoinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"))
    private List<ExternalPower> externalPowers;

    @Column(name = "POWER")
    private Double power;

    @Column(name = "OUT_CURRENT")
    private Double outCurrent;

    @ManyToMany
    @JoinTable(name = "DGEPU_POWER_UNIT_OUT_POWER_LINK",
            joinColumns = @JoinColumn(name = "POWER_UNIT_ID"),
            inverseJoinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"))
    private List<ExternalPower> outexternalPowers;

    @Column(name = "HAS_STABILIZATOR")
    private  Boolean hasStabilizator;

    @Column(name = "HAS_CURRENT_CONTROL")
    private Boolean hasCurrentControl;

    @Column(name = "PROTECTION_DEGREE")
    private String protectionDegree;

    @Column(name = "HAS_DIN_INSTALL")
    private Boolean hasDinInstall;

    @Column(name = "TEMPERATURE_MAX", length = 4)
    private String temperaturemax;

    @Column(name = "TEMPERATURE_MIN", length = 4)
    private String temperaturemin;

    public List<ExternalPower> getExternalPowers() {
        return externalPowers;
    }

    public void setExternalPowers(List<ExternalPower> externalPowers) {
        this.externalPowers = externalPowers;
    }

    public Boolean getHasStabilizator() {
        return hasStabilizator;
    }

    public void setHasStabilizator(Boolean hasStabilizator) {
        this.hasStabilizator = hasStabilizator;
    }

    public Boolean getHasCurrentControl() {
        return hasCurrentControl;
    }

    public void setHasCurrentControl(Boolean hasCurrentControl) {
        this.hasCurrentControl = hasCurrentControl;
    }

    public String getProtectionDegree() {
        return protectionDegree;
    }

    public void setProtectionDegree(String protectionDegree) {
        this.protectionDegree = protectionDegree;
    }

    public String getTemperaturemax() {
        return temperaturemax;
    }

    public void setTemperaturemax(String temperaturemax) {
        this.temperaturemax = temperaturemax;
    }

    public String getTemperaturemin() {
        return temperaturemin;
    }

    public void setTemperaturemin(String temperaturemin) {
        this.temperaturemin = temperaturemin;
    }

    public List<ExternalPower> getOutexternalPowers() {
        return outexternalPowers;
    }

    public void setOutexternalPowers(List<ExternalPower> outexternalPowers) {
        this.outexternalPowers = outexternalPowers;
    }

    public Double getPower() {
        return power;
    }

    public void setPower(Double power) {
        this.power = power;
    }

    public Double getOutCurrent() {
        return outCurrent;
    }

    public void setOutCurrent(Double outCurrent) {
        this.outCurrent = outCurrent;
    }

    public Boolean getHasDinInstall() {
        return hasDinInstall;
    }

    public void setHasDinInstall(Boolean hasDinInstall) {
        this.hasDinInstall = hasDinInstall;
    }
}
