package ru.mrgeng.digit.epu.pros.dictequip;

import javax.persistence.*;

@Table(name = "DGEPU_SENSOR_PRESSURE_ITEM")
@Entity(name = "pros_SensorPressureItem")
@PrimaryKeyJoinColumn(name = "ITEM_ID", referencedColumnName = "ID")
@DiscriminatorValue("SPI")
public class SensorPressureItem extends Item  {
    private static final long serialVersionUID = 2115490053174105919L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name ="SENSOR_PRESSURE_MODEL")
    private SensorPressureModel sensorPressureModel;

    public SensorPressureModel getSensorPressureModel() {
        return sensorPressureModel;
    }

    public void setSensorPressureModel(SensorPressureModel sensorPressureModel) {
        this.sensorPressureModel = sensorPressureModel;
    }
}
