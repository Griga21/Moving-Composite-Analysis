package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_GAS_METER_TYPE")
@Entity(name = "pros_GasMeterType")
public class GasMeterType extends Dict {
    private static final long serialVersionUID = -1885798660992040619L;
}
