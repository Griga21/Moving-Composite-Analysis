package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_DATA_TRANSFER_METHOD")
@Entity(name = "pros_DataTransferMethod")
public class DataTransferMethod extends Dict {
    private static final long serialVersionUID = -6362101494222474188L;

    @JoinTable(name = "DGEPU_MODEM_MODEL_DATA_TRANSFER_METHOD_LINK",
            joinColumns = @JoinColumn(name = "DATA_TRANSFER_METHOD_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModels;

    @JoinTable(name = "DGEPU_ANTENNA_MODEL_DATA_TRANSFER_METHOD_LINK",
            joinColumns = @JoinColumn(name = "DATA_TRANSFER_METHOD_ID"),
            inverseJoinColumns = @JoinColumn(name = "ANTENNA_MODEL_ID"))
    @ManyToMany
    private List<AntennaModel> antennaModels;

    public List<AntennaModel> getAntennaModels() {
        return antennaModels;
    }

    public void setAntennaModels(List<AntennaModel> antennaModels) {
        this.antennaModels = antennaModels;
    }

    public List<ModemModel> getModemModels() {
        return modemModels;
    }

    public void setModemModels(List<ModemModel> modemModels) {
        this.modemModels = modemModels;
    }
}
