package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.MdObj;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_TRANSFER_PROTOCOL")
@Entity(name = "pros_TransferProtocol")
public class TransferProtocol extends MdObj {
    private static final long serialVersionUID = 4138979982008177664L;

    @JoinTable(name = "DGEPU_MODEM_MODEL_TRANSFER_PROTOCOL_LINK",
            joinColumns = @JoinColumn(name = "TRANSFER_PROTOCOL_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModels;

    public List<ModemModel> getModemModels() {
        return modemModels;
    }

    public void setModemModels(List<ModemModel> modemModels) {
        this.modemModels = modemModels;
    }
}
