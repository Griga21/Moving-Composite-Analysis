package ru.mrgeng.digit.epu.pros.dictequip;

import javax.persistence.*;

@Table(name = "DGEPU_GAS_METER_ITEM")
@Entity(name = "pros_GasMeterItem")
@PrimaryKeyJoinColumn(name = "ITEM_ID", referencedColumnName = "ID")
@DiscriminatorValue("GMI")
public class GasMeterItem extends Item {
    private static final long serialVersionUID = -8271409221234619492L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GAS_METER_MODEL_ID")
    private GasMeterModel gasMeterModel;

    public GasMeterModel getGasMeterModel() {
        return gasMeterModel;
    }

    public void setGasMeterModel(GasMeterModel gasMeterModel) {
        this.gasMeterModel = gasMeterModel;
    }
}
