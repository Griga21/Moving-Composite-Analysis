package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.epu.pros.EquipModel;
import ru.mrgeng.digit.epu.pros.dictcommon.ParamUnitToir;
import ru.mrgeng.digit.epu.pros.equipparam.PhaseState;
import ru.mrgeng.digit.epu.pros.equipparam.QualityClass;
import ru.mrgeng.digit.epu.pros.equipparam.TransformTech;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_SENSOR_PRESSURE_MODEL")
@Entity(name = "pros_SensorPressureModel")
public class SensorPressureModel extends EquipModel {
    private static final long serialVersionUID = 5071092658316279181L;

    @Column(name = "MEASURE_PHASE")
    private Integer phaseState;

    @Column(name = "TRANSFORM_TECH")
    private Integer transformTech;

    @Column(name = "ABSOLUT_PRES")
    private Boolean abspres;

    @Column(name = "EXCESS_PRES")
    private Boolean excpres;

    @Column(name = "ATMOSFERE_PRES")
    private Boolean atmopres;

    @Column(name = "DIFFERENCE_PRES")
    private Boolean difpres;

    @Column(name = "QUALITY_CLASS")
    private Integer qualityClass;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRESSURE_MEAS_UNIT")
    private ParamUnitToir pressureMeasUnit;

    @Column(name = "PRESSURE_MEAS_MIN")
    private Double pressureMeasMin;

    @Column(name = "PRESSURE_MEAS_MAX")
    private Double pressureMeasMax;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEMPERATURE_ENV_UNIT")
    private ParamUnitToir envtempUnitToir;

    @Column(name = "TEMPERATURE_ENV_MAX")
    private Double temperatureEnvMax;

    @Column(name = "TEMPERATURE_ENV_MIN")
    private Double temperatureEnvMin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEMPERATURE_MEAS_UNIT")
    private ParamUnitToir measTempUnitToir;

    @Column(name = "TEMPERATURE_MEAS_MAX")
    private Double temperatureMeasMax;

    @Column(name = "TEMPERATURE_MEAS_MIN")
    private Double temperatureMeasMin;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "DGEPU_SENSOR_PRESSURE_MODEL_OUTPUT_SIGNAL_SENS_LINK",
            joinColumns = @JoinColumn(name = "SENSOR_PRESSURE_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "OUTPUT_SIGNAL_SENS_ID"))
    private List<OutputSignalSens> outputSignalSensList;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONNECTION_TECH")
    private ConnectionTech connectionTech;

    @Column(name = "IMMER_LENGTH")
    private Double immerlength;

    @Column(name = "PROTECTION_DEGREE")
    private String protectionDegree;

    @Column(name = "MAX_CURRENT")
    private Integer maxCurrent;

    @Column(name = "CHANEL_COUNT")
    private Integer channelCount;

    @Column(name = "TU_NAME")
    private String tuName;

    @Column(name = "EXTERNAL_POWER_NEED")
    private Boolean externalPowerNeed;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn (name ="ELECTR_CONNECTOR")
    private Connector connector;

    @ManyToOne (fetch = FetchType.LAZY)
    @JoinColumn(name ="EXTERNAL_POWER")
    private ExternalPower externalPower;

    @Column(name = "CALIBR_INTERVAL")
    private Double calibrInterval;

    @Column(name = "HAS_DIAGNOSTIC")
    private Boolean hasDiagnostic;

    @Column(name = "EXPLOSION_PROOF")
    private String explosionProof;

    public SensorPressureModel() {
    }

    public PhaseState getPhaseState() {
        return phaseState == null ? null : PhaseState.fromId(phaseState);
    }

    public void setPhaseState(PhaseState phaseState) {
        this.phaseState = phaseState == null ? null : phaseState.getId();
    }

    public TransformTech getTransformTech() {
        return transformTech == null ? null : TransformTech.fromId(transformTech);
    }

    public void setTransformTech(TransformTech transformTech) {
        this.transformTech = transformTech == null ? null : transformTech.getId();
    }

    public QualityClass getQualityClass() {
        return qualityClass == null ? null : QualityClass.fromId(qualityClass);
    }

    public void setQualityClass(QualityClass qualityClass) {
        this.qualityClass = qualityClass == null ? null : qualityClass.getId();
    }

    public Boolean getAbspres() {
        return abspres;
    }

    public void setAbspres(Boolean abspres) {
        this.abspres = abspres;
    }

    public Boolean getExcpres() {
        return excpres;
    }

    public void setExcpres(Boolean excpres) {
        this.excpres = excpres;
    }

    public Boolean getAtmopres() {
        return atmopres;
    }

    public void setAtmopres(Boolean atmopres) {
        this.atmopres = atmopres;
    }

    public Boolean getDifpres() {
        return difpres;
    }

    public void setDifpres(Boolean difpres) {
        this.difpres = difpres;
    }

    public Double getTemperatureEnvMax() {
        return temperatureEnvMax;
    }

    public void setTemperatureEnvMax(Double temperatureEnvMax) {
        this.temperatureEnvMax = temperatureEnvMax;
    }

    public Double getTemperatureEnvMin() {
        return temperatureEnvMin;
    }

    public void setTemperatureEnvMin(Double temperatureEnvMin) {
        this.temperatureEnvMin = temperatureEnvMin;
    }

    public Double getTemperatureMeasMax() {
        return temperatureMeasMax;
    }

    public void setTemperatureMeasMax(Double temperatureMeasMax) {
        this.temperatureMeasMax = temperatureMeasMax;
    }

    public Double getTemperatureMeasMin() {
        return temperatureMeasMin;
    }

    public void setTemperatureMeasMin(Double temperatureMeasMin) {
        this.temperatureMeasMin = temperatureMeasMin;
    }

    public ParamUnitToir getEnvtempUnitToir() {
        return envtempUnitToir;
    }

    public void setEnvtempUnitToir(ParamUnitToir envtempUnitToir) {
        this.envtempUnitToir = envtempUnitToir;
    }

    public ParamUnitToir getMeasTempUnitToir() {
        return measTempUnitToir;
    }

    public void setMeasTempUnitToir(ParamUnitToir measTempUnitToir) {
        this.measTempUnitToir = measTempUnitToir;
    }

    public List<OutputSignalSens> getOutputSignalSensList() {
        return outputSignalSensList;
    }

    public void setOutputSignalSensList(List<OutputSignalSens> outputSignalSensList) {
        this.outputSignalSensList = outputSignalSensList;
    }

    public ConnectionTech getConnectionTech() {
        return connectionTech;
    }

    public void setConnectionTech(ConnectionTech connectionTech) {
        this.connectionTech = connectionTech;
    }

    public Double getImmerlength() {
        return immerlength;
    }

    public void setImmerlength(Double immerlength) {
        this.immerlength = immerlength;
    }

    public ParamUnitToir getPressureMeasUnit() {
        return pressureMeasUnit;
    }

    public void setPressureMeasUnit(ParamUnitToir pressureMeasUnit) {
        this.pressureMeasUnit = pressureMeasUnit;
    }

    public void setPressureMeasMin(Double pressureMeasMin) {
        this.pressureMeasMin = pressureMeasMin;
    }

    public Double getPressureMeasMin() {
        return pressureMeasMin;
    }

    public void setPressureMeasMax(Double pressureMeasMax) {
        this.pressureMeasMax = pressureMeasMax;
    }

    public Double getPressureMeasMax() {
        return pressureMeasMax;
    }

    public String getProtectionDegree() {
        return protectionDegree;
    }

    public void setProtectionDegree(String protectionDegree) {
        this.protectionDegree = protectionDegree;
    }

    public void setMaxCurrent(Integer maxCurrent) {
        this.maxCurrent = maxCurrent;
    }

    public Integer getMaxCurrent() {
        return maxCurrent;
    }

    public void setChannelCount(Integer channelCount) {
        this.channelCount = channelCount;
    }

    public Integer getChannelCount() {
        return channelCount;
    }

    public void setTuName(String tuName) {
        this.tuName = tuName;
    }

    public String getTuName() {
        return tuName;
    }

    public void setExternalPowerNeed(Boolean externalPowerNeed) {
        this.externalPowerNeed = externalPowerNeed;
    }

    public Boolean getExternalPowerNeed() {
        return externalPowerNeed;
    }

    public void setConnector(Connector connector) {
        this.connector = connector;
    }

    public Connector getConnector() {
        return connector;
    }

    public void setExternalPower(ExternalPower externalPower) {
        this.externalPower = externalPower;
    }

    public ExternalPower getExternalPower() {
        return externalPower;
    }

    public void setCalibrInterval(Double calibrInterval) {
        this.calibrInterval = calibrInterval;
    }

    public Double getCalibrInterval() {
        return calibrInterval;
    }

    public void setHasDiagnostic(Boolean hasDiagnostic) {
        this.hasDiagnostic = hasDiagnostic;
    }

    public Boolean getHasDiagnostic() {
        return hasDiagnostic;
    }

    public void setExplosionProof(String explosionProof) {
        this.explosionProof = explosionProof;
    }

    public String getExplosionProof() {
        return explosionProof;
    }
}