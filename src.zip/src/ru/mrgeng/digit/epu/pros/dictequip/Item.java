package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.pros.StmObj;
import ru.mrgeng.digit.epu.pros.Uirg;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_ITEM")
@Entity(name = "pros_Item")
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING)
@Inheritance(strategy = InheritanceType.JOINED)
public class Item extends MdObj {
    private static final long serialVersionUID = -1161538011173401247L;

    @Column(name = "SERIAL_NUM")
    private String serialNum;

    @JoinTable(name = "DGEPU_ITEM_UIRG_LINK",
            joinColumns = @JoinColumn(name = "ITEM_ID"),
            inverseJoinColumns = @JoinColumn(name = "UIRG_ID"))
    @ManyToMany
    private List<Uirg> uirgs;

    @JoinTable(name = "DGEPU_ITEM_STM_OBJ_LINK",
            joinColumns = @JoinColumn(name = "ITEM_ID"),
            inverseJoinColumns = @JoinColumn(name = "STM_OBJ_ID"))
    @ManyToMany
    private List<StmObj> stmObj;

    public List<Uirg> getUirgs() {
        return uirgs;
    }

    public void setUirgs(List<Uirg> uirgs) {
        this.uirgs = uirgs;
    }

    public List<StmObj> getStmObj() {
        return stmObj;
    }

    public void setStmObj(List<StmObj> stmObj) {
        this.stmObj = stmObj;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
}
