package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_FREQUENCY")
@Entity(name = "pros_Frequency")
public class Frequency extends Dict {
    private static final long serialVersionUID = 3809371583245805219L;

    @JoinTable(name = "DGEPU_MODEM_MODEL_FREQUENCY_LINK",
            joinColumns = @JoinColumn(name = "FREQUENCY_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModels;

    @JoinTable(name = "DGEPU_ANTENNA_MODEL_FREQUENCY_LINK",
            joinColumns = @JoinColumn(name = "FREQUENCY_ID"),
            inverseJoinColumns = @JoinColumn(name = "ANTENNA_MODEL_ID"))
    @ManyToMany
    private List<AntennaModel> antennaModels;

    public List<AntennaModel> getAntennaModels() {
        return antennaModels;
    }

    public void setAntennaModels(List<AntennaModel> antennaModels) {
        this.antennaModels = antennaModels;
    }

    public List<ModemModel> getModemModels() {
        return modemModels;
    }

    public void setModemModels(List<ModemModel> modemModels) {
        this.modemModels = modemModels;
    }
}