package ru.mrgeng.digit.epu.pros.dictequip;

import com.haulmont.chile.core.annotations.Composition;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.OnDelete;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.pros.equipparam.SignalMode;
import ru.mrgeng.digit.epu.pros.equipparam.SignalType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Table(name = "DGEPU_INOUTPUTS")
@Entity(name = "pros_Inoutputs")
@NamePattern("%s|name")
public class Inoutputs extends MdObj {
    private static final long serialVersionUID = -6504491832818894112L;

    @Column(name = "SIGNAL_MODE")
    protected Integer signalMode;

    @Column(name = "SIGNAL_TYPE")
    protected Integer signalType;

    @Composition
    @OnDelete(DeletePolicy.CASCADE)
    @OneToMany(mappedBy = "inoutputs")
    protected List<ControllerModelInoutputLink> controllerModelInoutputLinks;

    public void setSignalMode(SignalMode signalMode) {this.signalMode = signalMode == null ? null: signalMode.getId(); }

    public SignalMode getSignalMode() {return signalMode == null ? null :SignalMode.fromId(signalMode);}

    public void setSignalType(SignalType signalType) { this.signalType = signalType == null ? null: signalType.getId(); }

    public SignalType getSignalType() {  return signalType == null ? null : SignalType.fromId(signalType);  }

    public void setControllerModelInoutputLinks (List<ControllerModelInoutputLink> controllerModelInoutputLinks) {
        this.controllerModelInoutputLinks=controllerModelInoutputLinks;}

    public List<ControllerModelInoutputLink> getControllerModelInoutputLinks (){
        return controllerModelInoutputLinks;
    }
}
