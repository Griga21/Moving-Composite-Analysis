package ru.mrgeng.digit.epu.pros.dictequip;

import javax.persistence.*;

@Table(name = "DGEPU_CONTROLLER_ITEM")
@Entity(name = "pros_ControllerItem")
@PrimaryKeyJoinColumn(name = "ITEM_ID", referencedColumnName = "ID")
@DiscriminatorValue("CI")
public class ControllerItem extends Item {
    private static final long serialVersionUID = 7396606926377553911L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONTROLLER_MODEL_ID")
    private ControllerModel controllerModel;

    public ControllerModel getControllerModel() {
        return controllerModel;
    }

    public void setControllerModel(ControllerModel controllerModel) {
        this.controllerModel = controllerModel;
    }
}
