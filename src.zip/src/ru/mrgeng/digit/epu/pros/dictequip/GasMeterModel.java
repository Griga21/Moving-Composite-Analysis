package ru.mrgeng.digit.epu.pros.dictequip;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.epu.pros.EquipModel;
import ru.mrgeng.digit.epu.pros.dictcommon.ParamUnitToir;

import javax.persistence.*;

@Table(name = "DGEPU_GAS_METER_MODEL")
@Entity(name = "pros_GasMeterModel")
@NamePattern("%s|name")
public class GasMeterModel extends EquipModel {

    @Column(name = "REESTR_NUMBER")
    private String reestrNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GAS_METER_TYPE_SIZE_ID")
    private GasMeterTypeSize gasMeterTypeSize;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GAS_METER_TYPE_ID")
    private GasMeterType gasMeterType;

    @Column(name = "CALIBRATION_INTERVAL")
    private Integer calibrationInterval;

    @Column(name = "TYPE_MEASUREINSTRUMENT")
    private String typeMeasureInstrument;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Q_UNIT_ID")
    private ParamUnitToir qUnit;

    @Column(name = "MAX_FLOW")
    private Double maxFlow;

    @Column(name = "MIN_FLOW")
    private Double minFlow;

    @Column(name = "QUOTIENT_FLOW")
    private String quotientFlow;

    @Column(name = "TRANSIENT_FLOW")
    private Double transientFlow;

    @Column (name ="DIAMETR")
    private  Integer diameter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ERR_UNIT_ID")
    private ParamUnitToir errUnit;

    @Column(name = "MAX_ERROR")
    private Double maxError;

    @Column(name = "MIN_ERROR")
    private Double minError;

    @Column(name = "QUOTIENT_ERROR")
    private Double quotientError;

    @Column(name = "TRANSIENT_ERROR")
    private Double transientError;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "P_UNIT_ID")
    private ParamUnitToir pUnit;

    @Column(name = "MAX_WORK_P")
    private Double maxWorkP;

    @Column(name = "MASSA")
    private Double massa;

    @Column(name = "HAS_PSENSOR")
    private Boolean hasPsensor;

    public GasMeterType getGasMeterType() {
        return gasMeterType;
    }

    public void setGasMeterType(GasMeterType gasMeterType) {
        this.gasMeterType = gasMeterType;
    }

    public String getReestrNumber() {
        return reestrNumber;
    }

    public void setReestrNumber(String reestrNumber) {
        this.reestrNumber = reestrNumber;
    }

    public GasMeterTypeSize getGasMeterTypeSize() {
        return gasMeterTypeSize;
    }

    public void setGasMeterTypeSize(GasMeterTypeSize gasMeterTypeSize) {
        this.gasMeterTypeSize = gasMeterTypeSize;
    }

    public Integer getCalibrationInterval() {
        return calibrationInterval;
    }

    public void setCalibrationInterval(Integer calibrationInterval) {
        this.calibrationInterval = calibrationInterval;
    }

    public void setTypeMeasureInstrument(String typeMeasureInstrument) {
        this.typeMeasureInstrument = typeMeasureInstrument;
    }

    public String getTypeMeasureInstrument() {
        return typeMeasureInstrument;
    }

    public void setQUnit(ParamUnitToir qUnit) {
        this.qUnit = qUnit;
    }

    public ParamUnitToir getQUnit() {
        return qUnit;
    }

    public void setErrUnit(ParamUnitToir errUnit) {
        this.errUnit = errUnit;
    }

    public ParamUnitToir getErrUnit() {
        return errUnit;
    }

    public ParamUnitToir getPUnit() {
        return pUnit;
    }

    public void setPUnit(ParamUnitToir pUnit) {
        this.pUnit = pUnit;
    }

    public void setMaxWorkP(Double maxWorkP) {
        this.maxWorkP = maxWorkP;
    }

    public Double getMaxWorkP() {
        return maxWorkP;
    }

    public void setMassa(Double massa) {
        this.massa = massa;
    }

    public Double getMassa() {
        return massa;
    }

    public void setMaxFlow(Double maxFow) {
        this.maxFlow = maxFow;
    }

    public Double getMaxFlow() {
        return maxFlow;
    }

    public Double getMinFlow() {
        return minFlow;
    }

    public void setMinFlow(Double minFlow) {
        this.minFlow = minFlow;
    }

    public String getQuotientFlow() {
        return quotientFlow;
    }

    public void setQuotientFlow(String quotientFlow) {
        this.quotientFlow = quotientFlow;
    }

    public void setTransientFlow(Double transientFlow) {
        this.transientFlow = transientFlow;
    }

    public Double getTransientFlow() {
        return transientFlow;
    }

    public void setMaxError(Double maxError) {
        this.maxError = maxError;
    }

    public Double getMaxError() {
        return maxError;
    }

    public Double getMinError() {
        return minError;
    }

    public void setMinError(Double minError) {
        this.minError = minError;
    }

    public void setQuotientError(Double quotientError) {
        this.quotientError = quotientError;
    }

    public Double getQuotientError() {
        return quotientError;
    }

    public void setTransientError(Double transientError) {
        this.transientError = transientError;
    }

    public Double getTransientError() {
        return transientError;
    }

    public void setHasPsensor(Boolean hasPsensor) {
        this.hasPsensor = hasPsensor;
    }

    public Boolean getHasPsensor() {
        return hasPsensor;
    }

    public void setDiameter(Integer diameter) {
        this.diameter = diameter;
    }

    public Integer getDiameter() {
        return diameter;
    }
}