package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.epu.pros.EquipModel;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_MODEM_MODEL")
@Entity(name = "pros_ModemModel")
public class ModemModel extends EquipModel {
    private static final long serialVersionUID = -494360894337716315L;

    @Column(name = "NUM_SIM")
    private Integer numSim;

    @Column(name = "HAS_INT_ANTENNA")
    private Boolean hasintAntenna;

    @Column(name = "HAS_WATCHDOG")
    private Boolean hasWatchdog;

    @Column(name = "BODY_")
    private String body;

    @Column(name = "HAS_DIN_INSTALL")
    private Boolean hasDinInstall;

    @Column(name = "PROTECTION_DEGREE")
    private String protectionDegree;

    @Column(name = "HAS_INT_TCPIP")
    private Boolean hasIntTCPIP;

    @Column(name = "TEMPERATURE_MIN", length = 4)
    private String temperatureMin;

    @Column(name = "TEMPERATURE_MAX", length = 4)
    private String temperatureMax;

    @Column(name = "EXTERNAL_POWERUNIT_NEED")
    private Boolean externalPowerunitNeed;

    @Column(name = "OPERATING_SYSTEM")
    private String operatingSystem;

    @Column(name = "COMM")
    private String comm;

    @Column(name = "NET_FUNCTIONS")
    private String netFunctions;

    @OneToMany(mappedBy = "modemModel")
    private List<InterfaceBaudRate> interfaceBaudRate;

    @JoinTable(name = "DGEPU_MODEM_MODEL_FREQUENCY_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "FREQUENCY_ID"))
    @ManyToMany
    private List<Frequency> workFrequency;

    @JoinTable(name = "DGEPU_MODEM_MODEL_DATA_TRANSFER_METHOD_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "DATA_TRANSFER_METHOD_ID"))
    @ManyToMany
    private List<DataTransferMethod> transferMethod;

    @ManyToMany
    @JoinTable(name = "DGEPU_MODEM_MODEL_EXTERNAL_POWER_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "EXTERNAL_POWER_ID"))
    private List<ExternalPower> externalPower;

    @JoinTable(name = "DGEPU_MODEM_MODEL_EQUIP_INTERFACE_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "EQUIP_INTERFACE_ID"))
    @ManyToMany
    private List<EquipInterface> interfaces;

    @JoinTable(name = "DGEPU_MODEM_MODEL_TRANSFER_PROTOCOL_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "TRANSFER_PROTOCOL_ID"))
    @ManyToMany
    private List<TransferProtocol> protocols;

    @JoinTable(name = "DGEPU_MODEM_MODEL_ANTCONNECTOR_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "CONNECTOR_ID"))
    @ManyToMany
    private List<Connector> antennaConnector;

    @JoinTable(name = "DGEPU_MODEM_MODEL_EXTPWRCONNECTOR_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "CONNECTOR_ID"))
    @ManyToMany
    private List<Connector> extPowerConnector;

    @JoinTable(name = "DGEPU_MODEM_MODEL_CONNECTOR_LINK",
            joinColumns = @JoinColumn(name = "MODEM_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "CONNECTOR_ID"))
    @ManyToMany
    private List<Connector> connectors;

    public List<Connector> getConnectors() {
        return connectors;
    }

    public void setConnectors(List<Connector> connectors) {
        this.connectors = connectors;
    }

    public List<Connector> getExtPowerConnector() {
        return extPowerConnector;
    }

    public void setExtPowerConnector(List<Connector> extPowerConnector) {
        this.extPowerConnector = extPowerConnector;
    }

    public List<Connector> getAntennaConnector() {
        return antennaConnector;
    }

    public void setAntennaConnector(List<Connector> antennaConnector) {
        this.antennaConnector = antennaConnector;
    }

    public List<InterfaceBaudRate> getInterfaceBaudRate() {
        return interfaceBaudRate;
    }

    public void setInterfaceBaudRate(List<InterfaceBaudRate> interfaceBaudRate) {
        this.interfaceBaudRate = interfaceBaudRate;
    }

    public String getNetFunctions() {
        return netFunctions;
    }

    public void setNetFunctions(String netFunctions) {
        this.netFunctions = netFunctions;
    }

    public String getComm() {
        return comm;
    }

    public void setComm(String comm) {
        this.comm = comm;
    }

    public List<TransferProtocol> getProtocols() {
        return protocols;
    }

    public void setProtocols(List<TransferProtocol> protocols) {
        this.protocols = protocols;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public List<DataTransferMethod> getTransferMethod() {
        return transferMethod;
    }

    public void setTransferMethod(List<DataTransferMethod> transferMethod) {
        this.transferMethod = transferMethod;
    }

    public List<EquipInterface> getInterfaces() {
        return interfaces;
    }

    public void setInterfaces(List<EquipInterface> interfaces) {
        this.interfaces = interfaces;
    }

    public List<ExternalPower> getExternalPower() {
        return externalPower;
    }

    public void setExternalPower(List<ExternalPower> externalPower) {
        this.externalPower = externalPower;
    }

    public List<Frequency> getWorkFrequency() {
        return workFrequency;
    }

    public void setWorkFrequency(List<Frequency> workFrequency) {
        this.workFrequency = workFrequency;
    }

    public void setTemperatureMax(String temperatureMax) {
        this.temperatureMax = temperatureMax;
    }

    public String getTemperatureMax() {
        return temperatureMax;
    }

    public void setTemperatureMin(String temperatureMin) {
        this.temperatureMin = temperatureMin;
    }

    public String getTemperatureMin() {
        return temperatureMin;
    }

    public void setProtectionDegree(String protectionDegree) {
        this.protectionDegree = protectionDegree;
    }

    public String getProtectionDegree() {
        return protectionDegree;
    }

    public void setHasintAntenna(Boolean hasintAntenna) {
        this.hasintAntenna = hasintAntenna;
    }

    public Boolean getHasintAntenna() {
        return hasintAntenna;
    }

    public void setHasWatchdog(Boolean hasWatchdog) {
        this.hasWatchdog = hasWatchdog;
    }

    public Boolean getHasWatchdog() {
        return hasWatchdog;
    }

    public void setHasDinInstall(Boolean hasDinInstall) {
        this.hasDinInstall = hasDinInstall;
    }

    public Boolean getHasDinInstall() {
        return hasDinInstall;
    }

    public void setHasIntTCPIP(Boolean hasIntTCPIP) {
        this.hasIntTCPIP = hasIntTCPIP;
    }

    public Boolean getHasIntTCPIP() {
        return hasIntTCPIP;
    }

    public void setExternalPowerunitNeed(Boolean externalPowerunitNeed) {
        this.externalPowerunitNeed = externalPowerunitNeed;
    }

    public Boolean getExternalPowerunitNeed() {
        return externalPowerunitNeed;
    }

    public void setNumSim(Integer numSim) {
        this.numSim = numSim;
    }

    public Integer getNumSim() {
        return numSim;
    }
}
