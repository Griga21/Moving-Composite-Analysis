package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_EQUIP_INTERFACE")
@Entity(name = "pros_EquipInterface")
public class EquipInterface extends Dict {
    private static final long serialVersionUID = -8642252934782534720L;

    @JoinTable(name = "DGEPU_MODEM_MODEL_EQUIP_INTERFACE_LINK",
            joinColumns = @JoinColumn(name = "EQUIP_INTERFACE_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModels;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INTERFACE_BAUD_RATE_ID")
    private InterfaceBaudRate interfaceBaudRate;

    public InterfaceBaudRate getInterfaceBaudRate() {
        return interfaceBaudRate;
    }

    public void setInterfaceBaudRate(InterfaceBaudRate interfaceBaudRate) {
        this.interfaceBaudRate = interfaceBaudRate;
    }

    public List<ModemModel> getModemModels() {
        return modemModels;
    }

    public void setModemModels(List<ModemModel> modemModels) {
        this.modemModels = modemModels;
    }
}
