package ru.mrgeng.digit.epu.pros.dictequip;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.dgcore.entity.Dict;
import ru.mrgeng.digit.epu.pros.equipparam.ConnectWay;
import ru.mrgeng.digit.epu.pros.equipparam.ConnectorForm;
import ru.mrgeng.digit.epu.pros.equipparam.ConnectorType;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_CONNECTOR")
@Entity(name = "pros_Connector")
@NamePattern("%s|label")
public class Connector extends Dict {
    private static final long serialVersionUID = -4322965803441848498L;

    @Column(name = "LABEL")
    private String label;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "CONNECTOR_TYPE")
    private Integer connectorType;

    @Column(name = "CONNECTOR_FORM")
    private Integer connectorForm;

    @Column(name = "CONNECT_WAY")
    private Integer connectWay;

    @Column(name = "REVERSE_POLARITY")
    private Boolean reversePolarity;

    @Column(name = "CONTACT_COUNT")
    private Integer contactCount;

    @JoinTable(name = "DGEPU_MODEM_MODEL_CONNECTOR_LINK",
            joinColumns = @JoinColumn(name = "CONNECTOR_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModels;

    @JoinTable(name = "DGEPU_MODEM_MODEL_CONNECTOR_LINK",
            joinColumns = @JoinColumn(name = "CONNECTOR_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModelsExtPwr;

    @JoinTable(name = "DGEPU_MODEM_MODEL_CONNECTOR_LINK",
            joinColumns = @JoinColumn(name = "CONNECTOR_ID"),
            inverseJoinColumns = @JoinColumn(name = "MODEM_MODEL_ID"))
    @ManyToMany
    private List<ModemModel> modemModelsConnectors;

    public List<ModemModel> getModemModelsConnectors() {
        return modemModelsConnectors;
    }

    public void setModemModelsConnectors(List<ModemModel> modemModelsConnectors) {
        this.modemModelsConnectors = modemModelsConnectors;
    }

    public List<ModemModel> getModemModelsExtPwr() {
        return modemModelsExtPwr;
    }

    public void setModemModelsExtPwr(List<ModemModel> modemModelsExtPwr) {
        this.modemModelsExtPwr = modemModelsExtPwr;
    }

    public List<ModemModel> getModemModels() {
        return modemModels;
    }

    public void setModemModels(List<ModemModel> modemModels) {
        this.modemModels = modemModels;
    }

    public Integer getContactCount() {
        return contactCount;
    }

    public void setContactCount(Integer contactCount) {
        this.contactCount = contactCount;
    }

    public Boolean getReversePolarity() {
        return reversePolarity;
    }

    public void setReversePolarity(Boolean reversePolarity) {
        this.reversePolarity = reversePolarity;
    }

    public ConnectWay getConnectWay() {
        return connectWay == null ? null : ConnectWay.fromId(connectWay);
    }

    public void setConnectWay(ConnectWay connectWay) {
        this.connectWay = connectWay == null ? null : connectWay.getId();
    }

    public ConnectorForm getConnectorForm() {
        return connectorForm == null ? null : ConnectorForm.fromId(connectorForm);
    }

    public void setConnectorForm(ConnectorForm connectorForm) {
        this.connectorForm = connectorForm == null ? null : connectorForm.getId();
    }

    public ConnectorType getConnectorType() {
        return connectorType == null ? null : ConnectorType.fromId(connectorType);
    }

    public void setConnectorType(ConnectorType connectorType) {
        this.connectorType = connectorType == null ? null : connectorType.getId();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
