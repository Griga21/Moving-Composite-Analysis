package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.epu.pros.equipparam.Directivity;
import ru.mrgeng.digit.epu.pros.EquipModel;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_ANTENNA_MODEL")
@Entity(name = "pros_AntennaModel")
public class AntennaModel extends EquipModel {
    private static final long serialVersionUID = -8277585109985931833L;

    @Column(name = "DIRECTION")
    private Integer direction;

    @Column(name = "IMPEDANCE")
    private Integer impedance;

    @Column(name = "MAX_GAIN")
    private Double maxGain;

    @Column(name = "POWER_")
    private Double power;

    @Column(name = "CABLE_LENGTH")
    private Double cableLength;

    @Column(name = "PROTECTION_DEGREE")
    private String protectionDegree;

    @Column(name = "TEMPERATURE_MAX")
    private Double temperatureMax;

    @Column(name = "TEMPERATURE_MIN")
    private Double temperatureMin;

    @Column(name = "COMM")
    private String comm;

    @JoinTable(name = "DGEPU_ANTENNA_MODEL_FREQUENCY_LINK",
            joinColumns = @JoinColumn(name = "ANTENNA_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "FREQUENCY_ID"))
    @ManyToMany
    private List<Frequency> workFrequency;

    @JoinTable(name = "DGEPU_ANTENNA_MODEL_DATA_TRANSFER_METHOD_LINK",
            joinColumns = @JoinColumn(name = "ANTENNA_MODEL_ID"),
            inverseJoinColumns = @JoinColumn(name = "DATA_TRANSFER_METHOD_ID"))
    @ManyToMany
    private List<DataTransferMethod> transferMethod;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONNECTOR_ID")
    private Connector connector;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ANTENNA_TYPE_ID")
    private AntennaType antennaType;

    @Column(name = "PLACING_")
    private String placing;

    public String getPlacing() {
        return placing;
    }

    public void setPlacing(String placing) {
        this.placing = placing;
    }

    public AntennaType getAntennaType() {
        return antennaType;
    }

    public void setAntennaType(AntennaType antennaType) {
        this.antennaType = antennaType;
    }

    public Connector getConnector() {
        return connector;
    }

    public void setConnector(Connector connector) {
        this.connector = connector;
    }

    public List<DataTransferMethod> getTransferMethod() {
        return transferMethod;
    }

    public void setTransferMethod(List<DataTransferMethod> transferMethod) {
        this.transferMethod = transferMethod;
    }

    public List<Frequency> getWorkFrequency() {
        return workFrequency;
    }

    public void setWorkFrequency(List<Frequency> workFrequency) {
        this.workFrequency = workFrequency;
    }

    public String getComm() {
        return comm;
    }

    public void setComm(String comm) {
        this.comm = comm;
    }

    public Double getTemperatureMin() {
        return temperatureMin;
    }

    public void setTemperatureMin(Double temperatureMin) {
        this.temperatureMin = temperatureMin;
    }

    public Double getTemperatureMax() {
        return temperatureMax;
    }

    public void setTemperatureMax(Double temperatureMax) {
        this.temperatureMax = temperatureMax;
    }

    public String getProtectionDegree() {
        return protectionDegree;
    }

    public void setProtectionDegree(String protectionDegree) {
        this.protectionDegree = protectionDegree;
    }

    public Double getCableLength() {
        return cableLength;
    }

    public void setCableLength(Double cableLength) {
        this.cableLength = cableLength;
    }

    public Double getPower() {
        return power;
    }

    public void setPower(Double power) {
        this.power = power;
    }

    public Double getMaxGain() {
        return maxGain;
    }

    public void setMaxGain(Double maxGain) {
        this.maxGain = maxGain;
    }

    public Integer getImpedance() {
        return impedance;
    }

    public void setImpedance(Integer impedance) {
        this.impedance = impedance;
    }

    public Directivity getDirection() {
        return direction == null ? null : Directivity.fromId(direction);
    }

    public void setDirection(Directivity direction) {
        this.direction = direction == null ? null : direction.getId();
    }
}
