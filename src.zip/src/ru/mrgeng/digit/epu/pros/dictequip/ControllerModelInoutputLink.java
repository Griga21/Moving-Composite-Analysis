package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.epu.mp.Obj;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "DGEPU_CONTROLLER_MODEL_INOUTPUT_LINK")
@Entity(name = "pros_ControllerModelInoutputLink")
public class ControllerModelInoutputLink extends Obj {
    private static final long serialVersionUID = -4964739741167500293L;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONTROLLER_MODEL_ID")
    private  ControllerModel controllerModel;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INOUTPUTS_ID")
    private Inoutputs inoutputs ;

    @NotNull
    @Column(name = "IO_COUNT")
    private Integer iocounts;

    public void setControllerModel(ControllerModel controllerModel) { this.controllerModel = controllerModel; }

    public ControllerModel getControllerModel() { return controllerModel;  }

    public void setInoutputs(Inoutputs inoutputs) { this.inoutputs = inoutputs;  }

    public Inoutputs getInoutputs() {  return inoutputs;  }

    public void setIocounts(Integer iocounts) {  this.iocounts = iocounts;  }

    public Integer getIocounts() {  return iocounts;  }
}
