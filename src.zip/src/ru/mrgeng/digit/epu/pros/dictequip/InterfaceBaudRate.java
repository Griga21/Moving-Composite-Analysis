package ru.mrgeng.digit.epu.pros.dictequip;

import ru.mrgeng.digit.epu.mp.Obj;
import ru.mrgeng.digit.epu.pros.dictcommon.ParamUnitToir;
import ru.mrgeng.digit.epu.pros.equipparam.RxTx;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_INTERFACE_BAUD_RATE")
@Entity(name = "pros_InterfaceBaudRate")
public class InterfaceBaudRate extends Obj {
    private static final long serialVersionUID = -4737659698168134217L;

    @OneToMany(mappedBy = "interfaceBaudRate")
    private List<EquipInterface> eqInterface;

    @Column(name = "RX_TX")
    private Integer rxTx;

    @Column(name = "VALUE_")
    private Integer value;

    @OneToMany(mappedBy = "interfaceBaudRate")
    private List<ParamUnitToir> paramUnit;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MODEM_MODEL_ID")
    private ModemModel modemModel;

    public ModemModel getModemModel() {
        return modemModel;
    }

    public void setModemModel(ModemModel modemModel) {
        this.modemModel = modemModel;
    }

    public List<ParamUnitToir> getParamUnit() {
        return paramUnit;
    }

    public void setParamUnit(List<ParamUnitToir> paramUnit) {
        this.paramUnit = paramUnit;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public RxTx getRxTx() {
        return rxTx == null ? null : RxTx.fromId(rxTx);
    }

    public void setRxTx(RxTx rxTx) {
        this.rxTx = rxTx == null ? null : rxTx.getId();
    }

    public List<EquipInterface> getEqInterface() {
        return eqInterface;
    }

    public void setEqInterface(List<EquipInterface> eqInterface) {
        this.eqInterface = eqInterface;
    }
}
