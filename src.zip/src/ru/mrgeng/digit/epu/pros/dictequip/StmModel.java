package ru.mrgeng.digit.epu.pros.dictequip;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.epu.pros.EquipModel;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_STM_MODEL")
@Entity(name = "pros_StmModel")
@NamePattern("%s|name")
public class StmModel extends EquipModel {
    private static final long serialVersionUID = 5753111426695022487L;
}
