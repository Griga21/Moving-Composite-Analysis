package ru.mrgeng.digit.epu.pros.dictequip;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;

@Table(name = "DGEPU_MODEM_ITEM")
@Entity(name = "pros_ModemItem")
@PrimaryKeyJoinColumn(name = "ITEM_ID", referencedColumnName = "ID")
@DiscriminatorValue("MI")
@NamePattern("%s|name")
public class ModemItem extends Item {
    private static final long serialVersionUID = 4536909676614389254L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EQUIP_MODEL_ID")
    private ModemModel modemModel;

    public ModemModel getModemModel() {
        return modemModel;
    }

    public void setModemModel(ModemModel modemModel) {
        this.modemModel = modemModel;
    }
}
