package ru.mrgeng.digit.epu.pros;

import ru.mrgeng.digit.epu.mp.Obj;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "DGEPU_REQUEST_CHANGE_HAND_BOOK")
@Entity(name = "pros_RequestChangeHandBook")
public class RequestChangeHandBook extends Obj {

    @Column(name = "HAND_BOOK_STATUS")
    private Integer handBookStatus;

    @Column(name = "HAND_BOOK_CODE")
    private String handBookCode;

    @Column(name = "TEXT")
    private String text;

    @Column(name = "HAND_BOOK")
    private String handBook;

    @Column(name = "HAND_BOOK_ID")
    private Long handBookId;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getHandBookCode() {
        return handBookCode;
    }

    public void setHandBookCode(String handBookCode) {
        this.handBookCode = handBookCode;
    }

    public Long getHandBookId() {
        return handBookId;
    }

    public void setHandBookId(Long handBookId) {
        this.handBookId = handBookId;
    }

    public String getHandBook() {
        return handBook;
    }

    public void setHandBook(String handBook) {
        this.handBook = handBook;
    }

    public HandBookStatus getHandBookStatus() {
        return handBookStatus == null ? null : HandBookStatus.fromId(handBookStatus);
    }

    public void setHandBookStatus(HandBookStatus handBookStatus) {
        this.handBookStatus = handBookStatus == null ? null : handBookStatus.getId();
    }
}
