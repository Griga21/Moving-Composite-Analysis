package ru.mrgeng.digit.epu.pros;

import com.haulmont.cuba.core.entity.Entity;

public interface BzNameExtensionI {
    String getTreeElementName();

    static String treeElementNameOf(Entity<?> entity) {
        if (entity instanceof BzNameExtensionI)
            return ((BzNameExtensionI) entity).getTreeElementName();
        return entity.toString();
    }
}
