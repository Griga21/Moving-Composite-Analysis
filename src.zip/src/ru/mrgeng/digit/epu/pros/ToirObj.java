package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.dgcore.entity.Company;
import ru.mrgeng.digit.dgcore.entity.Department;
import ru.mrgeng.digit.dgcore.entity.MdObj;

import javax.persistence.*;
import java.util.UUID;

@MappedSuperclass
@NamePattern("%s|name")
public class ToirObj extends MdObj {
    private static final long serialVersionUID = -1877771694584854300L;

    @Column(name = "COMM", length = 512)
    private String comm;

    @Column(name = "REGION_CODE")
    private Integer regionCode;

    @Column(name = "CODE", length = 128, unique = true)
    private String code;

    @Column(name = "ALTER_SECOND_CODE", length = 128)
    private String alterSecondCode;

    // TODO ЗАМЕНИТЬ НА ДЕВАЙСЫ
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RGC_ID")
    private Company rgc;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TOIR_DEP_ID")
    private Department toirDep;

    @Column(name = "ADDRESS", length = 512)
    private String address;

    @Column(name = "FIAS_ADDRESS_STRING")
    private String fiasAddressString;

    @Column(name = "FIAS_ADDRESS_GUID")
    private UUID fiasAddressGuid;

    public Integer getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(Integer regionCode) {
        this.regionCode = regionCode;
    }

    public UUID getFiasAddressGuid() {
        return fiasAddressGuid;
    }

    public void setFiasAddressGuid(UUID fiasAddressGuid) {
        this.fiasAddressGuid = fiasAddressGuid;
    }

    public String getFiasAddressString() {
        return fiasAddressString;
    }

    public void setFiasAddressString(String fiasAddressString) {
        this.fiasAddressString = fiasAddressString;
    }

    public Company getRgc() {
        return rgc;
    }

    public void setRgc(Company rgc) {
        this.rgc = rgc;
    }

    public Department getToirDep() {
        return toirDep;
    }

    public void setToirDep(Department toirDep) {
        this.toirDep = toirDep;
    }

    public String getComm() {
        return comm;
    }

    public void setComm(String comm) {
        this.comm = comm;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAlterSecondCode() {
        return alterSecondCode;
    }

    public void setAlterSecondCode(String alterSecondCode) {
        this.alterSecondCode = alterSecondCode;
    }
}