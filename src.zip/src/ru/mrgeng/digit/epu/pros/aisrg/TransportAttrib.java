package ru.mrgeng.digit.epu.pros.aisrg;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum TransportAttrib implements EnumClass<Integer> {
    NOTRANSPORT(0),
    GROTRANSPORT (1),
    TRANSITGROTRANSPORT(2);

    private final Integer id;

    TransportAttrib(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static TransportAttrib fromId(Integer id) {
        for (TransportAttrib at : TransportAttrib.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
