package ru.mrgeng.digit.epu.pros.aisrg;

import com.haulmont.addon.maps.gis.Geometry;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.dgcore.entity.Company;
import ru.mrgeng.digit.dgcore.entity.MdObj;
import ru.mrgeng.digit.epu.pros.ProsPointWKTConverter;
import ru.mrgeng.digit.epu.pros.Uirg;
import ru.mrgeng.digit.epu.pros.bz.Grs;
import ru.mrgeng.digit.epu.pros.bz.GrsOut;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Table(name = "DGEPU_CONNECTION_POINT")
@Entity(name = "pros_ConnectionPoint")
@NamePattern("%s|name")
public class ConnectionPoint extends MdObj {
    private static final long serialVersionUID = -2779467148020419245L;

    @Transient
    @MetaProperty(related = "grsId")
    private Grs grs;

    @Column(name = "GRS_ID")
    private Long grsId;

    @Transient
    @MetaProperty(related = "grsOutId")
    private GrsOut grsOut;

    @Column(name = "GRSOUT_ID")
    private Long grsOutId;

    @Column(name = "AISRG_KEY")
    private String aisrgKey;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID")
    private Company company;

    @Column(name = "CODE_SDU_RGK")
    private Integer codeSduRgk;

    @Column(name = "CODE_SDU_GRO")
    private Integer codeSduGro;

    @Column(name = "TRANSPORT_ATTR")
    private Integer transportAttrib;

    @Column(name = "LOCATION")
    @Geometry
    @MetaProperty(datatype = "coord")
    @Convert(converter = ProsPointWKTConverter.class)
    private Point location;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "FIAS_ADDRESS_GUID")
    private UUID fiasAddressGuid;

    @OneToMany(mappedBy = "connectionPoint")
    private List<Uirg> uirgs;

    public Grs getGrs() {
        return grs;
    }

    public void setGrs(Grs grs) {
        this.grs = grs;
        this.grsId = grs == null ? null : grs.getId();
    }

    public GrsOut getGrsOut() {
        return grsOut;
    }

    public void setGrsOut(GrsOut grsOut) {
        this.grsOut = grsOut;
        this.grsOutId = grsOut == null ? null : grsOut.getId();
    }

    public Long getGrsId() {
        return grsId;
    }

    public void setGrsId(Long grsId) {
        this.grsId = grsId;
    }

    public Long getGrsOutId() {
        return grsOutId;
    }

    public void setGrsOutId(Long grsOutId) {
        this.grsOutId = grsOutId;
    }

    public String getAisrgKey() {
        return aisrgKey;
    }

    public void setAisrgKey(String aisrgKey) {
        this.aisrgKey = aisrgKey;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Integer getCodeSduRgk() {
        return codeSduRgk;
    }

    public void setCodeSduRgk(Integer codeSduRgk) {
        this.codeSduRgk = codeSduRgk;
    }

    public Integer getCodeSduGro() {
        return codeSduGro;
    }

    public void setCodeSduGro(Integer codeSduGro) {
        this.codeSduGro = codeSduGro;
    }

    public TransportAttrib getTransportAttrib() {
        return transportAttrib == null ? null : TransportAttrib.fromId(transportAttrib);
    }

    public void setTransportAttrib(TransportAttrib transportAttrib) {
        this.transportAttrib = transportAttrib == null ? null : transportAttrib.getId();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public UUID getFiasAddressGuid() {
        return fiasAddressGuid;
    }

    public void setFiasAddressGuid(UUID fiasAddressGuid) {
        this.fiasAddressGuid = fiasAddressGuid;
    }

    public List<Uirg> getUirgs() {
        return uirgs;
    }

    public void setUirgs(List<Uirg> uirgs) {
        this.uirgs = uirgs;
    }
}
