package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.FileDescriptor;
import ru.mrgeng.digit.epu.mp.Obj;

import javax.persistence.*;

@Table(name = "DGEPU_STM_OBJ_ATTACHMENT")
@Entity(name = "pros_StmObjAttachment")
@NamePattern("%s|name")
public class StmObjAttachment extends Obj {
    private static final long serialVersionUID = -121009376410155154L;

    @Column(name = "NAME")
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STM_OBJ_ID")
    private StmObj stmObj;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FILE_DESCRIPTOR_ID")
    private FileDescriptor fileDescriptor;

    public FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    public void setFileDescriptor(FileDescriptor fileDescriptor) {
        this.fileDescriptor = fileDescriptor;
    }

    public StmObj getStmObj() {
        return stmObj;
    }

    public void setStmObj(StmObj stmObj) {
        this.stmObj = stmObj;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}