package ru.mrgeng.digit.epu.pros;

import com.haulmont.addon.maps.gis.Geometry;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;
import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.epu.pros.aisrg.ConnectionPoint;
import ru.mrgeng.digit.epu.pros.dictequip.Item;

import javax.persistence.*;
import java.util.List;

@PublishEntityChangedEvents
@Table(name = "DGEPU_UIRG")
@Entity(name = "pros_Uirg")
@NamePattern("%s|name")
public class Uirg extends ToirObj {
    private static final long serialVersionUID = -3679003898522739249L;

    @Column(name = "LOCATION")
    @Geometry
    @MetaProperty(datatype = "coord")
    @Convert(converter = ProsPointWKTConverter.class)
    private Point location;

    @Column(name = "LOCATION_ADDRESS", length = 512)
    private String locationAddress;

    @Column(name = "IS_SERVICED", nullable = false)
    private Boolean isServiced = false;

    @OneToMany(mappedBy = "uirg")
    private List<UirgAttachment> attachments;

    @JoinTable(name = "DGEPU_ITEM_UIRG_LINK",
            joinColumns = @JoinColumn(name = "UIRG_ID"),
            inverseJoinColumns = @JoinColumn(name = "ITEM_ID"))
    @ManyToMany
    private List<Item> items;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CON_POINT_ID")
    private ConnectionPoint connectionPoint;

    @OneToMany(mappedBy = "uirg")
    private List<UirgMeterLine> uirgMeterLines;

    @Column(name = "CUSTOMER_CLASSIFIER_GROUP", length = 512)
    private String customerClassifierGroup;

    @Column(name = "IS_CHECKED")
    private Boolean isChecked;

    public List<UirgMeterLine> getUirgMeterLines() {
        return uirgMeterLines;
    }

    public void setUirgMeterLines(List<UirgMeterLine> uirgMeterLines) {
        this.uirgMeterLines = uirgMeterLines;
    }

    public Boolean getIsServiced() {
        return isServiced;
    }

    public void setIsServiced(Boolean isServiced) {
        this.isServiced = isServiced;
    }

    public void setAttachments(List<UirgAttachment> attachments) {
        this.attachments = attachments;
    }

    public List<UirgAttachment> getAttachments() {
        return attachments;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public ConnectionPoint getConnectionPoint() {
        return connectionPoint;
    }

    public void setConnectionPoint(ConnectionPoint connectionPoint) {
        this.connectionPoint = connectionPoint;
    }

    public String getCustomerClassifierGroup() {
        return customerClassifierGroup;
    }

    public void setCustomerClassifierGroup(String customerClassifierGroup) {
        this.customerClassifierGroup = customerClassifierGroup;
    }

    public Boolean getIsChecked() {
        return isChecked;
    }

    public void setIsChecked(Boolean checked) {
        isChecked = checked;
    }

    public String getLocationAddress() {
        return locationAddress;
    }

    public void setLocationAddress(String locationAddress) {
        this.locationAddress = locationAddress;
    }
}
