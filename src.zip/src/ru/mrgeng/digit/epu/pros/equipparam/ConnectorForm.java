package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ConnectorForm implements EnumClass<Integer> {
    ROUND(10),
    RECT(20);

    private final Integer id;

    ConnectorForm(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ConnectorForm fromId(Integer id) {
        for (ConnectorForm at : ConnectorForm.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
