package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ConnectorType implements EnumClass<Integer> {
    AUDIO(10),
    POWER(20),
    NET(30),
    CAR(40),
    VIDEO(50),
    PC(60);

    private final Integer id;

    ConnectorType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ConnectorType fromId(Integer id) {
        for (ConnectorType at : ConnectorType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
