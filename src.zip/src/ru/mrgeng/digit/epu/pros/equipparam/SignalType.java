package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum SignalType implements EnumClass<Integer> {
    ANALOG(10),
    DISCRETE(20);

    private final Integer id;

    SignalType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static SignalType fromId(Integer id) {
        for (SignalType at : SignalType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
