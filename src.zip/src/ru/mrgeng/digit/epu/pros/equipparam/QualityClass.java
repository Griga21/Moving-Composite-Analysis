package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum QualityClass implements EnumClass<Integer> {
    CL01(10),
    CL02(20),
    CL02S(30),
    CL05(40),
    CL05S(50);

    private final Integer id;

    QualityClass(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static QualityClass fromId(Integer id) {
        for (QualityClass at : QualityClass.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
