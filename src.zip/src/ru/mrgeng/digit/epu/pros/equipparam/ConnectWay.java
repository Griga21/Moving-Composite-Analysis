package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ConnectWay implements EnumClass<Integer> {
    MALE(10),
    FEMALE(20);

    private final Integer id;

    ConnectWay(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ConnectWay fromId(Integer id) {
        for (ConnectWay at : ConnectWay.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
