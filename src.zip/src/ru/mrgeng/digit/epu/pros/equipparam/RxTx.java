package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum RxTx implements EnumClass<Integer> {
    RECEIVE(10),
    TRANSMISSION(20);

    private final Integer id;

    RxTx(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static RxTx fromId(Integer id) {
        for (RxTx at : RxTx.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
