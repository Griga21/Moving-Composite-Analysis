package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum TransformTech implements EnumClass<Integer> {
    TERMO(10),
    REOSTAT(20);

    private final Integer id;

    TransformTech(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static TransformTech fromId(Integer id) {
        for (TransformTech at : TransformTech.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}