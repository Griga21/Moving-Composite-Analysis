package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum SignalParam implements EnumClass<Integer> {
    CURRENT(10),
    VOLTAGE(20),
    CURLOOP(30);

    private final Integer id;

    SignalParam(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static SignalParam fromId(Integer id) {
        for (SignalParam at : SignalParam.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
