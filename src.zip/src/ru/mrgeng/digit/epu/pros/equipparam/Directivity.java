package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum Directivity implements EnumClass<Integer> {
    OMNIDIRECT(10),
    SECTOR(20),
    DIRECT(30);

    private final Integer id;

    Directivity(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static Directivity fromId(Integer id) {
        for (Directivity at : Directivity.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
