package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ElectricCurrentType implements EnumClass<Integer> {
    ALTER(10),
    CONSTANT(20);

    private final Integer id;

    ElectricCurrentType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ElectricCurrentType fromId(Integer id) {
        for (ElectricCurrentType at : ElectricCurrentType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
