package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum SignalMode implements EnumClass<Integer> {
    IN(10),
    OUT(20);

    private final Integer id;

    SignalMode(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static SignalMode fromId(Integer id) {
        for (SignalMode at : SignalMode.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
