package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum NominalVoltage implements EnumClass<Integer> {
    V24(10),
    V220(20),
    V12(30);

    private final Integer id;

    NominalVoltage(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static NominalVoltage fromId(Integer id) {
        for (NominalVoltage at : NominalVoltage.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
