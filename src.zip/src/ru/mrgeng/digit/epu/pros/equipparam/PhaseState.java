package ru.mrgeng.digit.epu.pros.equipparam;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum PhaseState implements EnumClass<Integer> {
    GAS (10),
    LIQUID (20),
    SOLID(30);

    private final Integer id;

    PhaseState(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static PhaseState fromId(Integer id) {
        for (PhaseState at : PhaseState.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
