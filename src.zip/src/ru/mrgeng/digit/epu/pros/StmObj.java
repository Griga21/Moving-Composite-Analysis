package ru.mrgeng.digit.epu.pros;

import com.haulmont.addon.maps.gis.Geometry;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;
import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.epu.pros.dictequip.DataTransferMethod;
import ru.mrgeng.digit.epu.pros.dictequip.Item;
import ru.mrgeng.digit.epu.pros.dictequip.StmModel;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

@PublishEntityChangedEvents
@Table(name = "DGEPU_STM_OBJ")
@Entity(name = "pros_StmObj")
@NamePattern("%s|name")
public class StmObj extends ToirObj {
    private static final long serialVersionUID = 6491659082407983239L;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "STM_MODEL_ID")
    @NotNull
    private StmModel stmModel;

    @Column(name = "LOCATION")
    @Geometry
    @MetaProperty(datatype = "coord")
    @Convert(converter = ProsPointWKTConverter.class)
    private Point location;

    @Column(name = "LOCATION_ADDRESS", length = 512)
    private String locationAddress;

    @Column(name = "COMMISSIONING_DATE")
    private LocalDate commissioningDate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ASU_TP_SUBJECT_ID")
    private AsuTpSubject asuTp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DATA_TRANSFER_METHOD_ID")
    private DataTransferMethod dataTransferMethod;

    @Column(name = "SURVEY_FREQUENCY")
    private String surveyFrequency;

    @Column(name = "SURVEY_TIME")
    private LocalTime surveyTime;

    @Column(name = "SERIAL_NUM")
    private String serialNum;

    @Column(name = "STM_OBJ_TYPE")
    private Integer stmObjType;

    @Column(name = "IMUS_CHANNELS")
    private String imusChannels;

    @Column(name = "IS_CHECKED")
    private Boolean isChecked;

    @Column(name = "IS_SERVICED", nullable = false)
    private Boolean isServiced = false;

    @OneToMany(mappedBy = "stmObj")
    private List<StmObjAttachment> attachments;

    @JoinTable(name = "DGEPU_ITEM_STM_OBJ_LINK",
            joinColumns = @JoinColumn(name = "STM_OBJ_ID"),
            inverseJoinColumns = @JoinColumn(name = "ITEM_ID"))
    @ManyToMany
    private List<Item> items;

    public Boolean getIsServiced() {
        return isServiced;
    }

    public void setIsServiced(Boolean isServiced) {
        this.isServiced = isServiced;
    }

    public void setAttachments(List<StmObjAttachment> attachments) {
        this.attachments = attachments;
    }

    public List<StmObjAttachment> getAttachments() {
        return attachments;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public LocalDate getCommissioningDate() {
        return commissioningDate;
    }

    public void setCommissioningDate(LocalDate commissioningDate) {
        this.commissioningDate = commissioningDate;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public StmModel getStmModel() {
        return stmModel;
    }

    public void setStmModel(StmModel stmModel) {
        this.stmModel = stmModel;
    }

    public DataTransferMethod getDataTransferMethod() {
        return dataTransferMethod;
    }

    public void setDataTransferMethod(DataTransferMethod dataTransferMethod) {
        this.dataTransferMethod = dataTransferMethod;
    }

    public String getSurveyFrequency() {
        return surveyFrequency;
    }

    public void setSurveyFrequency(String surveyFrequency) {
        this.surveyFrequency = surveyFrequency;
    }

    public LocalTime getSurveyTime() {
        return surveyTime;
    }

    public void setSurveyTime(LocalTime surveyTime) {
        this.surveyTime = surveyTime;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        StmObj stmObj = (StmObj) o;

        return Objects.equals(id, stmObj.id);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (id != null ? id.hashCode() : 0);
        return result;
    }

    public boolean haveNullField() {
        return stmModel == null ||
                location == null ||
                commissioningDate == null ||
                dataTransferMethod == null ||
                surveyFrequency == null ||
                surveyTime == null ||
                serialNum == null;
    }

    public String getImusChannels() {
        return imusChannels;
    }

    public void setImusChannels(String imusChannels) {
        this.imusChannels = imusChannels;
    }

    public AsuTpSubject getAsuTp() {
        return asuTp;
    }

    public void setAsuTp(AsuTpSubject asuTp) {
        this.asuTp = asuTp;
    }

    public StmObjType getStmObjType() {
        return stmObjType == null ? null : StmObjType.fromId(stmObjType);
    }

    public void setStmObjType(StmObjType stmObjType) {
        this.stmObjType = stmObjType == null ? null : stmObjType.getId();
    }

    public Boolean getIsChecked() {
        return isChecked;
    }

    public void setIsChecked(Boolean checked) {
        isChecked = checked;
    }

    public String getLocationAddress() {
        return locationAddress;
    }

    public void setLocationAddress(String locationAddress) {
        this.locationAddress = locationAddress;
    }
}