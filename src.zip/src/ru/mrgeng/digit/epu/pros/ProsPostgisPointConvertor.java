package ru.mrgeng.digit.epu.pros;

import org.locationtech.jts.geom.Point;
import org.postgresql.util.PGobject;
import ru.mrgeng.digit.epu.gis.BasePostgisPointConvertor;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * Конвертор PostGIS для pros
 */
@Converter
public class ProsPostgisPointConvertor extends BasePostgisPointConvertor implements AttributeConverter<Point, PGobject> {
}
