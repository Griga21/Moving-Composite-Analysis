package ru.mrgeng.digit.epu.pros.dictpromsafety;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Deprecated
@Table(name = "DGEPU_SIZ")
@Entity(name = "pros_Siz")
public class Siz extends Dict {
    private static final long serialVersionUID = 1517669335181876897L;

    @Column(name = "FULL_NAME", length = 512)
    private String fullName;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "NORM_CHAPTER")
    private String normChapter;

    @Column(name = "PARAM_UNIT")
    private String paramUnit;

    @Column(name = "COUNT")
    private Double count;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNormChapter() {
        return normChapter;
    }

    public void setNormChapter(String normChapter) {
        this.normChapter = normChapter;
    }

    public String getParamUnit() {
        return paramUnit;
    }

    public void setParamUnit(String paramUnit) {
        this.paramUnit = paramUnit;
    }

    public Double getCount() {
        return count;
    }

    public void setCount(Double count) {
        this.count = count;
    }
}
