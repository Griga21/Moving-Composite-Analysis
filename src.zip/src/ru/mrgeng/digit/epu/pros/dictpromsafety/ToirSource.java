package ru.mrgeng.digit.epu.pros.dictpromsafety;

import ru.mrgeng.digit.dgcore.entity.MdObj;

import javax.persistence.*;
import java.util.List;

@Table(name = "DGEPU_TOIR_SOURCE")
@Entity(name = "pros_ToirSource")
public class ToirSource extends MdObj {
    private static final long serialVersionUID = -5795863887226792522L;

    @Column(name = "UNIT")
    private String unit;

    @Column(name = "TYPE")
    private Integer type;

//    @JoinTable(name = "DGEPU_TOIR_SOURCE_MANUAL_TOIR_SOURCE_LINK",
//            joinColumns = @JoinColumn(name = "TOIR_SOURCE_ID"),
//            inverseJoinColumns = @JoinColumn(name = "TOIR_SOURCE_MANUAL_ID"))
//    @ManyToMany
//    private List<ToirSourceManual> toirSourceManuals;
//
//    public List<ToirSourceManual> getToirSourceManuals() {
//        return toirSourceManuals;
//    }
//
//    public void setToirSourceManuals(List<ToirSourceManual> toirSourceManuals) {
//        this.toirSourceManuals = toirSourceManuals;
//    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public ToirSourceType getType() {
        return type == null ? null : ToirSourceType.fromId(type);
    }

    public void setType(ToirSourceType type) {
        this.type = type == null ? null : type.getId();
    }
}
