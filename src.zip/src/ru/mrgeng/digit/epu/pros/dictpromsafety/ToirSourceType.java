package ru.mrgeng.digit.epu.pros.dictpromsafety;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ToirSourceType implements EnumClass<Integer> {
    TO(10),
    IN(20),
    RM(30);

    private final Integer id;

    ToirSourceType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ToirSourceType fromId(Integer id) {
        for (ToirSourceType at : ToirSourceType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
