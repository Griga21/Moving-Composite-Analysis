package ru.mrgeng.digit.epu.pros;

import com.haulmont.cuba.core.entity.KeyValueEntity;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class IgnorableMessageToUser {
    public KeyValueEntity messageToUser;
    public LocalDateTime endDateTime;

    public IgnorableMessageToUser(KeyValueEntity keyValueEntity, LocalDateTime endDateTime) {
        this.messageToUser = keyValueEntity;
        this.endDateTime = endDateTime;
        messageToUser.setValue("dateEnd", Date.from(endDateTime.atZone(ZoneId.systemDefault()).toInstant()));
    }
}
