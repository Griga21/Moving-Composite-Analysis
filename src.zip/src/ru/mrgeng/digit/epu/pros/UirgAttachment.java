package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.FileDescriptor;
import ru.mrgeng.digit.epu.mp.Obj;

import javax.persistence.*;

@Table(name = "DGEPU_UIRG_ATTACHMENT")
@Entity(name = "pros_UirgAttachment")
@NamePattern("%s|name")
public class UirgAttachment extends Obj {
    private static final long serialVersionUID = 2436165891347304337L;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FILE_DESCRIPTOR_ID")
    private FileDescriptor fileDescriptor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UIRG_ID")
    private Uirg uirg;

    @Column(name = "NAME")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Uirg getUirg() {
        return uirg;
    }

    public void setUirg(Uirg uirg) {
        this.uirg = uirg;
    }

    public FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    public void setFileDescriptor(FileDescriptor fileDescriptor) {
        this.fileDescriptor = fileDescriptor;
    }
}
