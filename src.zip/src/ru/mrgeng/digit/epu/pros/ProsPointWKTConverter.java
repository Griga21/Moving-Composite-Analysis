package ru.mrgeng.digit.epu.pros;

import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.epu.gis.BaseCoordConvertor;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class ProsPointWKTConverter extends BaseCoordConvertor implements AttributeConverter<Point, String> {
}
