package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;
import ru.mrgeng.digit.epu.mp.Obj;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@NamePattern("%s|id")
@PublishEntityChangedEvents
@Table(name = "DGEPU_UIRG_METER_LINE")
@Entity(name = "pros_UirgMeterLine")
public class UirgMeterLine extends Obj {

    @Column(name = "CHANNEL_ID")
    private Long channelId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UIRG_ID")
    private Uirg uirg;

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    public Uirg getUirg() {
        return uirg;
    }

    public void setUirg(Uirg uirg) {
        this.uirg = uirg;
    }
}
