package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.epu.mp.Obj;
import ru.mrgeng.digit.epu.pros.bz.Grp;
import ru.mrgeng.digit.epu.pros.bz.Valve;
import ru.mrgeng.digit.epu.util.ProsReflectionUtils;

import javax.persistence.*;
import java.util.Set;

@Table(name = "DGEPU_ASU_TP_SUBJECT")
@Entity(name = "pros_AsuTpSubject")
@NamePattern("%s|type")
public class AsuTpSubject extends Obj {
    private static final long serialVersionUID = -7065724083928742401L;

    @Transient
    @MetaProperty(related = {"grp", "valve", "skzObj"})
    private String objName;

    @Column(name = "COMMENTARY", length = 3000)
    private String commentary;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GRP_ID")
    private Grp grp;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VALVE_ID")
    private Valve valve;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SKZ_OBJ_ID")
    private SkzObj skzObj;

    @Column(name = "TYPE", nullable = false)
    private Integer type;

    public String getCommentary() {
        return commentary;
    }

    public void setCommentary(String commentary) {
        this.commentary = commentary;
    }

    public Grp getGrp() {
        return grp;
    }

    public void setGrp(Grp grp) {
        this.grp = grp;
    }

    public Valve getValve() {
        return valve;
    }

    public void setValve(Valve valve) {
        this.valve = valve;
    }

    public SkzObj getSkzObj() {
        return skzObj;
    }

    public void setSkzObj(SkzObj skzObj) {
        this.skzObj = skzObj;
    }

    public AsuTpSubjectType getType() {
        return type == null ? null : AsuTpSubjectType.fromId(type);
    }

    public void setType(AsuTpSubjectType type) {
        this.type = type == null ? null : type.getId();
        if (type == null) {
            ProsReflectionUtils.setNullValueToField(Set.of("grp", "valve", "skzObj"), this);
            return;
        }
        switch (type) {
            case GRP_TYPE: {
                ProsReflectionUtils.setNullValueToField(Set.of("valve", "skzObj"), this);
                break;
            }
            case VALVE_TYPE: {
                ProsReflectionUtils.setNullValueToField(Set.of("grp", "skzObj"), this);
                break;
            }
            case SKZ_TYPE: {
                ProsReflectionUtils.setNullValueToField(Set.of("grp", "valve"), this);
                break;
            }
        }
    }

    @Transient
    @MetaProperty(related = {"grp", "valve", "skzObj"})
    public String getObjName() {
        if(grp != null) {
            return grp.getName();
        }
        if(valve != null) {
            return valve.getName();
        }
        if(skzObj != null) {
            return skzObj.getName();
        }
        return "";
    }
}