package ru.mrgeng.digit.epu.pros;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum StmObjType implements EnumClass<Integer> {
    STM_90(10),
    ASCUG(20),
    CONSUMER(30);

    private final Integer id;

    StmObjType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static StmObjType fromId(Integer id) {
        for (StmObjType at : StmObjType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
