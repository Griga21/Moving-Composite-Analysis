package ru.mrgeng.digit.epu.pros.dictcommon;

import ru.mrgeng.digit.dgcore.entity.Dict;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

// TODO: 09.11.2021 таблица мастер-данных единиц измерений (ОКЕЙ), перенести в отдельное хранилище мастер-данных
@Table(name = "DGEPU_MASTER_PARAM_UNIT")
@Entity(name = "pros_MasterParamUnit")
public class MasterParamUnit extends Dict {
    private static final long serialVersionUID = 1966278723199095948L;

    @Column(name = "ORIG")
    private String orig;

    @Column(name = "NATIONAL_IDENTIFIER")
    private String nationalIdentifier;

    @Column(name = "INTERNATIONAL_IDENTIFIER")
    private String internationalIdentifier;

    @Column(name = "NATIONAL_CODE")
    private String nationalCode;

    @Column(name = "INTERNATIONAL_CODE")
    private String internationalCode;

    public String getOrig() {
        return orig;
    }

    public void setOrig(String orig) {
        this.orig = orig;
    }

    public String getNationalIdentifier() {
        return nationalIdentifier;
    }

    public void setNationalIdentifier(String nationalIdentifier) {
        this.nationalIdentifier = nationalIdentifier;
    }

    public String getInternationalIdentifier() {
        return internationalIdentifier;
    }

    public void setInternationalIdentifier(String internationalIdentifier) {
        this.internationalIdentifier = internationalIdentifier;
    }

    public String getNationalCode() {
        return nationalCode;
    }

    public void setNationalCode(String nationalCode) {
        this.nationalCode = nationalCode;
    }

    public String getInternationalCode() {
        return internationalCode;
    }

    public void setInternationalCode(String internationalCode) {
        this.internationalCode = internationalCode;
    }
}
