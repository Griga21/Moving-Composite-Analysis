package ru.mrgeng.digit.epu.pros.dictcommon;

import ru.mrgeng.digit.dgcore.entity.Dict;
import ru.mrgeng.digit.epu.pros.dictequip.InterfaceBaudRate;

import javax.persistence.*;

@Table(name = "DGEPU_PARAM_UNIT_TOIR")
@Entity(name = "pros_ParamUnitToir")
public class ParamUnitToir extends Dict {
    private static final long serialVersionUID = -3708095860629534534L;

    @Column(name = "ORIG")
    private String orig;

    @Column(name = "NATIONAL_IDENTIFIER")
    private String nationalIdentifier;

    @Column(name = "INTERNATIONAL_IDENTIFIER")
    private String internationalIdentifier;

    @Column(name = "NATIONAL_CODE")
    private String nationalCode;

    @Column(name = "INTERNATIONAL_CODE")
    private String internationalCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INTERFACE_BAUD_RATE_ID")
    private InterfaceBaudRate interfaceBaudRate;

    @Column(name = "CODE_MP_UNIT")
    private String codeMpUnit;

    @Column(name = "CODE_MP_UNIT_METPREFIX")
    private String codeMpUnitMetPrefix;

    public InterfaceBaudRate getInterfaceBaudRate() {
        return interfaceBaudRate;
    }

    public void setInterfaceBaudRate(InterfaceBaudRate interfaceBaudRate) {
        this.interfaceBaudRate = interfaceBaudRate;
    }

    public String getOrig() {
        return orig;
    }

    public void setOrig(String orig) {
        this.orig = orig;
    }

    public String getNationalIdentifier() {
        return nationalIdentifier;
    }

    public void setNationalIdentifier(String nationalIdentifier) {
        this.nationalIdentifier = nationalIdentifier;
    }

    public String getInternationalIdentifier() {
        return internationalIdentifier;
    }

    public void setInternationalIdentifier(String internationalIdentifier) {
        this.internationalIdentifier = internationalIdentifier;
    }

    public String getNationalCode() {
        return nationalCode;
    }

    public void setNationalCode(String nationalCode) {
        this.nationalCode = nationalCode;
    }

    public String getInternationalCode() {
        return internationalCode;
    }

    public void setInternationalCode(String internationalCode) {
        this.internationalCode = internationalCode;
    }

    public String getCodeMpUnit() {
        return codeMpUnit;
    }

    public void setCodeMpUnit(String codeMpUnit) {
        this.codeMpUnit = codeMpUnit;
    }

    public String getCodeMpUnitMetPrefix() {
        return codeMpUnitMetPrefix;
    }

    public void setCodeMpUnitMetPrefix(String codeMpUnitMetPrefix) {
        this.codeMpUnitMetPrefix = codeMpUnitMetPrefix;
    }
}
