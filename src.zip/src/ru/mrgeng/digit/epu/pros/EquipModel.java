package ru.mrgeng.digit.epu.pros;

import com.haulmont.cuba.core.global.DdlGeneration;
import ru.mrgeng.digit.dgcore.entity.Company;
import ru.mrgeng.digit.dgcore.entity.MdObj;

import javax.persistence.*;

@MappedSuperclass
@DdlGeneration(value = DdlGeneration.DbScriptGenerationMode.DISABLED)
public class EquipModel extends MdObj {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCER_ID")
    private Company producer;

    @Column(name = "WEIGHT")
    private  Double weight;

    @Column(name = "DIMENSIONS")
    private String dimensions;

    @Column(name = "LIFETIME")
    private Integer lifetime;

    public Company getProducer() {
        return producer;
    }

    public void setProducer(Company producer) {
        this.producer = producer;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setLifetime(Integer lifetime) { this.lifetime = lifetime; }

    public Integer getLifetime() { return lifetime; }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Double getWeight() {
        return weight;
    }
}
