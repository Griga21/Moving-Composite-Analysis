package ru.mrgeng.digit.epu.pros.servicenorm;

import ru.mrgeng.digit.dgcore.entity.Dict;
import ru.mrgeng.digit.epu.pros.dictcommon.ParamUnitToir;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "DGEPU_SERVICE_PERIODICITY")
@Entity(name = "pros_ServicePeriodicity")
public class ServicePeriodicity extends Dict {
    private static final long serialVersionUID = -2169289306191434689L;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UNIT_ID")
    private ParamUnitToir unit;

    @NotNull
    @Column(name = "VAL", nullable = false)
    private Double val = 0d;

    public ParamUnitToir getUnit() {
        return unit;
    }

    public void setUnit(ParamUnitToir unit) {
        this.unit = unit;
    }

    public Double getVal() {
        return val;
    }

    public void setVal(Double val) {
        this.val = val;
    }
}
