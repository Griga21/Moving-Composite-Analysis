package ru.mrgeng.digit.epu.pros.servicenorm;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

public enum RegDocType implements EnumClass<Integer> {
    NORM_ACT(10),
    FACTORY_PASPORT(20),
    CONTRACT(30);

    private final Integer id;

    RegDocType(Integer id) {
        this.id = id;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public static RegDocType fromId(Integer id) {
        for (RegDocType type : RegDocType.values()) {
            if (type.getId().equals(id)) {
                return type;
            }
        }
        return null;
    }
}
