package ru.mrgeng.digit.epu.pros.servicenorm;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

public enum NormObjType implements EnumClass<Integer> {
    STM(10),
    STM_MODEL(20),
    UIRG(30),
    STM_ALL(40),
    UIRG_ALL(50),
    PRG(60),
    PRG_ALL(70);

    private final Integer id;

    NormObjType(Integer id) {
        this.id = id;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public static NormObjType fromId(Integer id) {
        for (NormObjType norm : NormObjType.values()) {
            if (norm.getId().equals(id)) {
                return norm;
            }
        }
        return null;
    }
}
