package ru.mrgeng.digit.epu.pros.servicenorm;

import com.haulmont.chile.core.annotations.Composition;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.OnDelete;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.dgcore.entity.Contract;
import ru.mrgeng.digit.dgcore.entity.Dict;
import ru.mrgeng.digit.epu.pros.StmObj;
import ru.mrgeng.digit.epu.pros.Uirg;
import ru.mrgeng.digit.epu.pros.bz.Grp;
import ru.mrgeng.digit.epu.pros.dictequip.StmModel;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

@Table(name = "DGEPU_SERVICE_NORM")
@Entity(name = "pros_ServiceNorm")
@NamePattern("%s|name")
public class ServiceNorm extends Dict {
    private static final long serialVersionUID = 1632744214345493391L;

    @NotNull
    @Column(name = "OBJ_TYPE")
    private Integer objType = 10;

    @NotNull
    @Column(name = "DOC_TYPE")
    private Integer docType = 10;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STM_ID")
    private StmObj stm;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STM_MODEL_ID")
    private StmModel stmModel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UIRG_ID")
    private Uirg uirg;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GRP_ID")
    private Grp grp;

    @NotNull
    @Column(name = "ACTIVE", nullable = false)
    private Boolean active = true;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "PERIODICITY_ID")
    private ServicePeriodicity periodicity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONTRACT_ID")
    private Contract contract;

    @Column(name = "COMMENT")
    private String comment;

    @NotNull
    @Column(name = "DATE_FROM")
    private LocalDateTime dateFrom = LocalDateTime.now();

    public NormObjType getObjType() {
        return objType == null ? null : NormObjType.fromId(objType);
    }

    public void setObjType(NormObjType objType) {
        this.objType = objType == null ? null : objType.getId();
    }

    public RegDocType getDocType() {
        return docType == null ? null : RegDocType.fromId(docType);
    }

    public void setDocType(RegDocType docType) {
        this.docType = docType == null ? null : docType.getId();
    }

    public StmModel getStmModel() {
        return stmModel;
    }

    public void setStmModel(StmModel stmModel) {
        this.stmModel = stmModel;
    }

    public StmObj getStm() {
        return stm;
    }

    public void setStm(StmObj stm) {
        this.stm = stm;
    }

    public Uirg getUirg() {
        return uirg;
    }

    public void setUirg(Uirg uirg) {
        this.uirg = uirg;
    }

    public Grp getGrp() {
        return grp;
    }

    public void setGrp(Grp grp) {
        this.grp = grp;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public ServicePeriodicity getPeriodicity() {
        return periodicity;
    }

    public void setPeriodicity(ServicePeriodicity periodicity) {
        this.periodicity = periodicity;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDateTime getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(LocalDateTime dateFrom) {
        this.dateFrom = dateFrom;
    }
}
