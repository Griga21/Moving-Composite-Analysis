package ru.mrgeng.digit.epu.util;

public class DynamicAttributeCode {

    public static final String commHour = "CommHour";

    public static final String averageFull = "averageFull";

    //булевый атрибут, укакзывающий, поддерживается ли опрос с удержанием
    public static final String holdPoll = "holdPoll";

    public static final String reversDif = "reversDif";

    public static final String calcSkzWorkTime = "calcSkzWorkTime";

    public static final String skzLaunchTime = "skzLaunchDate";
}
