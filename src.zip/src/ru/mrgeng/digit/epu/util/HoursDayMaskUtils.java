package ru.mrgeng.digit.epu.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

// индекс бита - час
// 0 - 0
// 1 - 1
// ...
// 23 - 23
public class HoursDayMaskUtils {//todo ADD UNIT TESTS
    // private static final int h0 = 1;
    // private static final int h1 = 2;
    // private static final int h2 = 4;
    // private static final int h3 = 8;
    // private static final int h4 = 16;
    // private static final int h5 = 32;
    // private static final int h6 = 64;
    // private static final int h7 = 128;
    // private static final int h8 = 256;
    // private static final int h9 = 512;
    // private static final int h10 = 1_024;
    // private static final int h11 = 2_048;
    // private static final int h12 = 4_096;
    // private static final int h13 = 8_192;
    // private static final int h14 = 16_384;
    // private static final int h15 = 32_768;
    // private static final int h16 = 65_536;
    // private static final int h17 = 131_072;
    // private static final int h18 = 262_144;
    // private static final int h19 = 524_288;
    // private static final int h20 = 1_048_576;
    // private static final int h21 = 2_097_152;
    // private static final int h22 = 4_194_304;
    // private static final int h23 = 8_388_608;

    private static final int hAll = 16_777_215; // hAll = h23 + h22 + h21 + h20 + h19 + h18 + h17 + h16 + h15 + h14 + h13 + h12 + h11 + h10 + h9 + h8 + h7 + h6 + h5 + h4 + h3 + h2 + h1 + h0;

    private static final List<Integer> fullHourList = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23);

    public static int getEmptyMask() {
        return 0;
    }

    public static int getFullMask() {
        return hAll;
    }

    // удалить из маски час, указывать реальный час (0,1,2,3,4,...23)
    public static int removeHourInMask(int mask, int hour) {
        if (isMaskContainHour(mask, hour)) {
            int oneChangedBitMask = 1 << hour;// hour - т.к. биты нумеруются с нуля
            return mask ^ oneChangedBitMask;
        }
        return mask;
    }

    // проверить наличие часа в маске, указывать реальный час (0,1,2,3,4,...23)
    public static boolean isMaskContainHour(int mask, int hour) {
        return (mask >> hour) != 0;
    }

    // добавить в маску час, указывать реальный час (0,1,2,3,4,...23)
    public static int setHourInMask(int mask, int hour) {
        int oneChangedBitMask = 1 << hour;// т.к. биты нумеруются с нуля
        return mask | oneChangedBitMask;
    }

    // смержит флаги часов двух масок часов
    public static int mergeMask(int firstHoursMask, int secondHoursMask) {
        return firstHoursMask | secondHoursMask;
    }

    // кол-во часов в маске
    public static int totalHoursInDay(int mask) {
        if (mask < 0 || mask > hAll)
            throw new RuntimeException("Не корректная маска маска " + mask);
        int hourCount = 0;
        while (mask != 0) {
            hourCount += mask & 1;//увеличение счётчика, если последняя двоичная цифра = 1
            mask = mask >> 1;  //сдвиг mask на единицу вправо
        }
        return hourCount;
    }

    public static List<Integer> getExistHoursInMask(int mask) {
        if (mask < 0 || mask > hAll)
            throw new RuntimeException("Не корректная маска: " + mask);
        if (getEmptyMask() == mask)
            return Collections.EMPTY_LIST;
        if (getFullMask() == mask)
            return fullHourList;
        List<Integer> haveHours = new ArrayList<>();
        int hour = 0;
        while (mask != 0) {
            if ((mask & 1) == 1) {
                haveHours.add(hour);
            }
            mask = mask >> 1;  //сдвиг mask на единицу вправо
            hour++;
        }
        return haveHours;
    }

    public static List<Integer> getEmptyHoursInMask(int mask) {
        if (mask < 0 || mask > hAll)
            throw new RuntimeException("Не корректная маска маска " + mask);
        if (getFullMask() == mask)
            return Collections.EMPTY_LIST;
        if (getEmptyMask() == mask)
            return fullHourList;
        List<Integer> haveHours = new ArrayList<>();
        int hour = 0;
        while (mask != 0) {
            if ((mask & 1) == 0) {
                haveHours.add(hour);
            }
            mask = mask >> 1;  //сдвиг mask на единицу вправо
            hour++;
        }
        return haveHours;
    }

}
