package ru.mrgeng.digit.epu.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.mrgeng.digit.epu.mp.ParamGrouping;
import ru.mrgeng.digit.epu.param.DataFormat;
import ru.mrgeng.digit.epu.param.Param;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class ParamGroupingUtils {

    private static final Logger log = LoggerFactory.getLogger(ParamGroupingUtils.class);
    private static final NumberFormat numberFormat = NumberFormat.getInstance(new Locale("ru"));

    public static Double calculateByGrouping(Param param, List<Double> valueList) {
        DataFormat format = param.format;
        ParamGrouping paramGrouping = param.paramGrouping;
        Double result;
        switch (paramGrouping) {
            case SUM:
                result = valueList.stream()
                        .filter(Objects::nonNull)
                        .mapToDouble(value -> value)
                        .sum();
                break;
            case MAX: {
                result = valueList.stream()
                        .filter(Objects::nonNull)
                        .mapToDouble(value -> value)
                        .max()
                        .orElse(0);
                break;
            }
            case DIF: {
                double[] doubles = valueList.stream()
                        .filter(Objects::nonNull)
                        .mapToDouble(value -> value)
                        .toArray();
                int length = doubles.length;
                if (length == 0) {
                    result = 0.0;
                    break;
                }
                if (length == 1) {
                    result = doubles[0];
                    break;
                }
                result = doubles[length - 1] - doubles[0];
                break;
            }
            default:
                result = valueList.stream()
                        .filter(Objects::nonNull)
                        .mapToDouble(value -> value)
                        .average()
                        .orElse(0);
                break;
        }
        return format != null ? getDouble(format.toStr(result).replace(" ", "")) : result;
    }

    private static double getDouble(String format) {
        try {
            return numberFormat.parse(format).doubleValue();
        } catch (ParseException e) {
            log.info("Parse exception for {} string", format);
            return 0;
        }
    }
}
