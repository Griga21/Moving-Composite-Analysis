package ru.mrgeng.digit.epu.util;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import com.haulmont.addon.globalevents.GlobalUiEvent;

public class NotifyUtils extends GlobalApplicationEvent implements GlobalUiEvent {
    String message, type;

    public NotifyUtils(Object source, String message, String type) {
        super(source);
        this.message = message;
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
