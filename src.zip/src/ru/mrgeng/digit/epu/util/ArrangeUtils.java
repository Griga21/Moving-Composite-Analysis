package ru.mrgeng.digit.epu.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.util.List;

/**
 * Функции упорядочивания
 */
public class ArrangeUtils {

    Logger log = LoggerFactory.getLogger(ArrangeUtils.class);

    static class RectangleObj<T extends Object> {

        public RectangleObj(T object) {
            this.object = object;
        }

        T object;
        boolean arranged;
        String arrangeMsg;
        Rectangle rectangle;

        @Override
        public String toString() {
            return "RectangleObj{" +
                    "object=" + object +
                    ", arranged=" + arranged +
                    ", rectangle=" + rectangle +
                    ", arrangeMsg='" + arrangeMsg + '\'' +
                    (arranged ? ", edge [X,Y] =[ " + (rectangle.x + rectangle.width) + ", " + (rectangle.y + rectangle.height) + " ]" : "") +
                    '}';
        }
    }

    /**
     *    Последовательно, построчно размещает прямоугольники(ширина {@param rctWidth} выстота {@param rctHeight})
     *  в  указанном окне {@param wndWidth} {@param wndHeight}
     *
     *    Заполняет поля arranged (true - ok, false - ошибка), arrangeMsg (текст ошибки), rectangle(прямоугольник с координатами) в переданных RectangleObj
     *  Останавливается на первом невозможном для размещения объекте.
     *  Если последний объект Ok, значит размещение успешно

     *  Пример,
     *       List<RectangleObj<String>> objs = new ArrayList<>();
     *       for (int i = 1; i < 10; i++) {
     *           objs.add(new RectangleObj<String>("Param" + i));
     *       }
     *       int wndWidth = 600, wndHeight = 100, indWidth = 10, indHeight = 10, rctWidth = 70, rctHeight = 50;
     *       arrange(wndWidth, wndHeight, indWidth, indHeight, rctWidth, rctHeight, objs);
     *       RectangleObj<String> last = objs.get(objs.size() -1);
     *       log.info("Данны упорядочены: {} wndWidth={}, wndHeight={}, indWidth={}, indHeight={}, rctWidth={}, rctHeight={}", last.arranged, wndWidth, wndHeight, indWidth, indHeight, rctWidth, rctHeight);
     *       for (RectangleObj<String> obj : objs) {
     *         log.info("{}", obj);
     *       }
     *
     *
     * @param wndWidth ширина окна
     * @param wndHeight высота окна
     * @param indWidth отступ по ширине (от границ и между плитками)
     * @param indHeight отступ по высоте (от границ и между плитками)
     * @param rctWidth ширина прямоугольника
     * @param rctHeight высота прямоугольника
     * @param objs объекты для упорядочивания
     * @param <T>
     */
    public <T extends Object>
    void arrange(int wndWidth, int wndHeight, int indWidth, int indHeight, int rctWidth, int rctHeight, List<RectangleObj<T>> objs) {
        RectangleObj<T> prev = null;
        for (int i = 0; i < objs.size(); i++) {
            RectangleObj<T> obj = objs.get(i);
            arrangeByPrev(prev, obj, wndWidth, wndHeight, indWidth, indHeight, rctWidth, rctHeight);
            if (!obj.arranged) {
                log.warn("Объект {} не поместился в окне {} {}, последний размещенный {}", obj, wndWidth, wndHeight, prev);
                break;
            } else
                prev = obj;
        }
    }

    private <T extends Object>
    void arrangeByPrev(RectangleObj<T> prev, RectangleObj<T> toArrange, int wndWidth, int wndHeight, int indWidth, int indHeight, int rctWidth, int rctHeight) {
        if (prev == null) {
            if (indWidth + rctWidth > wndWidth - indWidth) {
                toArrange.arranged = false;
                toArrange.arrangeMsg = "Первый объект не помещается по ширине";
                return;
            }
            if (indHeight + rctHeight > wndHeight - indHeight) {
                toArrange.arranged = false;
                toArrange.arrangeMsg = "Первый объект не помещается по высоте";
                return;
            }
            Rectangle cand = new Rectangle(indWidth, indHeight, rctWidth, rctHeight);
            toArrange.rectangle = cand;
            toArrange.arranged = true;
        } else {
            int fromX = prev.rectangle.x;
            int fromY = prev.rectangle.y;
            if (fromX + rctWidth + indWidth + rctWidth > wndWidth - indWidth) {
                if (fromY + rctHeight + indHeight + rctHeight > wndHeight - indHeight) {
                    toArrange.arranged = false;
                    toArrange.arrangeMsg = "Не помещается по высоте";
                } else {
                    Rectangle cand = new Rectangle(indWidth, fromY + indHeight + rctHeight, rctWidth, rctHeight);
                    toArrange.rectangle = cand;
                    toArrange.arranged = true;
                }
            } else {
                Rectangle cand = new Rectangle(fromX + indWidth + rctWidth, fromY, rctWidth, rctHeight);
                toArrange.rectangle = cand;
                toArrange.arranged = true;
            }
        }
    }

}
