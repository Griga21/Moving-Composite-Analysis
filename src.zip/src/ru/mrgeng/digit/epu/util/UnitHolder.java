package ru.mrgeng.digit.epu.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.mrgeng.digit.epu.mp.ParamInfoUtils;

import javax.inject.Inject;
import javax.measure.MetricPrefix;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import java.util.*;

import static javax.measure.MetricPrefix.*;
import static tech.units.indriya.AbstractUnit.ONE;
import static tech.units.indriya.unit.Units.*;

public class UnitHolder {

    private static final Logger log = LoggerFactory.getLogger(UnitHolder.class);

    private static final UnitHolder unitHolder = new UnitHolder();

    @Inject
    private ParamInfoUtils paramInfoUtils;

    static HashMap<String, Unit<?>> unitMap = new HashMap<>();
    static HashMap<String, MetricPrefix> prefixHashMap = new HashMap<>();
    static HashMap<String, Unit<?>> unitWithPrefixMap = new HashMap<>();

    static {
        //units One, Percent, Celsius, Pascal, Kelvin, Ampere, Volt, Ohm, Metre, Metre2, Metre3, KmPerHour, Litre, Kilogram, KG/CM2, Bar, Rtut, kg/m3
        unitMap.put("One", ONE);
        unitMap.put("Percent", PERCENT);
        unitMap.put("Celsius", CELSIUS);
        unitMap.put("Pascal", PASCAL);
        unitMap.put("Kelvin", KELVIN);
        unitMap.put("Ampere", AMPERE);
        unitMap.put("Volt", VOLT);
        unitMap.put("Ohm", OHM);
        unitMap.put("Metre", METRE);
        unitMap.put("Metre2", SQUARE_METRE);
        unitMap.put("Metre3", CUBIC_METRE);
        unitMap.put("KmPerHour", KILOMETRE_PER_HOUR);
        unitMap.put("Litre", LITRE);
        unitMap.put("Kilogram", KILOGRAM);
        unitMap.put("KG/CM2", PASCAL.multiply(98066.5));
        unitMap.put("KGS/M2", PASCAL.multiply(9.80665));
        unitMap.put("Bar", PASCAL.multiply(100000));
        unitMap.put("Rtut", PASCAL.multiply(133.3224));
        unitMap.put("kg/m3", KILOGRAM.divide(CUBIC_METRE));
        unitMap.put("Metre3/hour", CUBIC_METRE.divide(HOUR));
        unitMap.put("hour", HOUR);
        unitMap.put("mg/m3", GRAM.divide(CUBIC_METRE).divide(1000));
        unitMap.put("kwt*h", WATT.multiply(HOUR).multiply(1000));
        unitMap.put("J/h", JOULE.divide(HOUR));
        unitMap.put("Wt*h/m3", WATT.multiply(3600).divide(CUBIC_METRE));
        unitMap.put("mmH2O", PASCAL.multiply(9.80665012481));
        unitMap.put("N*m", JOULE);
        unitMap.put("rpm", HERTZ.divide(60));
        unitMap.put("kcal/m3", WATT.multiply(3600).multiply(0.860).divide(CUBIC_METRE));

        //prefixes
        prefixHashMap.put("deci", DECI);
        prefixHashMap.put("centi", CENTI);
        prefixHashMap.put("milli", MILLI);
        prefixHashMap.put("micro", MICRO);
        prefixHashMap.put("nano", NANO);
        prefixHashMap.put("deka", DEKA);
        prefixHashMap.put("hecto", HECTO);
        prefixHashMap.put("kilo", KILO);
        prefixHashMap.put("mega", MEGA);
        prefixHashMap.put("giga", GIGA);
        initMaps();
    }

    public static class UnitConverterException extends Exception {

        public UnitConverterException(String message) {
            super(message);
        }

    }

    public static UnitHolder getInstance() {
        return unitHolder;
    }

    private static void initMaps() {
        ArrayList<String> pKey = new ArrayList<>(prefixHashMap.keySet());
        ArrayList<MetricPrefix> preVal = new ArrayList<>(prefixHashMap.values());

        ArrayList<String> uKey = new ArrayList<>(unitMap.keySet());
        ArrayList<Unit<?>> uniVal = new ArrayList<>(unitMap.values());

        //заполняем карту префикс.юнит
        for (int i = 0; i < preVal.size(); i++) {
            for (int j = 0; j < uniVal.size(); j++) {
                Unit<?> full = uniVal.get(j).prefix(preVal.get(i));
                unitWithPrefixMap.put(pKey.get(i) + uKey.get(j), full);
            }
        }
    }

    /**
     * (Прим.: килоМЕТР | МЕТР) : кило - префикс, МЕТР - юнит
     *
     * @param metricPrefix   - может отсутствовать
     * @param unitCode       - обязательный параметр
     * @param toMetricPrefix - может отсутствовать
     * @param toUnitCode     - обязательный параметр
     * @param value          - обязательный параметр
     * @return
     * @throws UnitConverterException
     */
    public Double convertValue(String metricPrefix, String unitCode,
                               String toMetricPrefix, String toUnitCode,
                               Double value) throws UnitConverterException {
        Unit<?> unitFrom;
        Unit<?> unitTo;
        /*   вытаскиваем юнит из карты по параметрам
        если префикс не указан - из карты без префикса   */
        if (metricPrefix != null) {
            unitFrom = unitWithPrefixMap.get(metricPrefix + unitCode);
        } else
            unitFrom = unitMap.get(unitCode);
        if (unitFrom == null)
            log.warn("Не найдена ед. изм.(ИЗ): prefix={} unit={}", metricPrefix, unitCode);

        if (toMetricPrefix != null) {
            unitTo = unitWithPrefixMap.get(toMetricPrefix + toUnitCode);
        } else
            unitTo = unitMap.get(toUnitCode);
        if (unitTo == null)
            log.warn("Не найдена ед. изм.(В): prefix={} unit={}", toMetricPrefix, toUnitCode);

        UnitConverter rez = null;

        try {
            rez = unitFrom.getConverterToAny(unitTo);
        } catch (Exception e) {
            throw new UnitConverterException(e.getMessage());
        }
        return rez.convert(value).doubleValue();
    }

    public Set<String> getUnitValidCodes() {
        return new HashSet<>(unitMap.keySet());
    }

    public Set<String> getPrefixValidCodes() {
        return new HashSet<>(prefixHashMap.keySet());
    }

    private Map<String, Set<String>> convertUnitsTestMap = null;

    public Map<String, Set<String>> getConvertUnitsTestMap() {
        if (convertUnitsTestMap == null) {
            convertUnitsTestMap = new HashMap<>();
        }
        for (String unitCode : unitMap.keySet()) {
            for (Map.Entry<String, Unit<?>> entry : unitMap.entrySet()) {

                convertUnitsTestMap.compute(unitCode, (prevKey, prevVal) -> {
                    if (prevVal == null)
                        prevVal = new HashSet<>();
                    try {
                        convertValue(null, unitCode, null, entry.getKey(), 1D);
                        prevVal.add(entry.getKey());
                    } catch (UnitConverterException e) {
                        //в prevVal не добавится новое значение
                    }
                    return prevVal;
                });
            }
        }
        return convertUnitsTestMap;
    }

    /**
     * Проверяет совместимость двух единиц измерения для конвертации
     */
    public boolean areUnitsCompatible(Unit unit1, Unit unit2) {
        if (unit1 == null || unit2 == null) {
            return false;
        }

        try {
            return unit1.isCompatible(unit2);
        } catch (Exception e) {
            log.warn("Ошибка сравнения двух единиц измерений: " + unit1.toString() + " " + unit2.toString());
            return false;
        }
    }

    /**
     * Возвращает список всех единиц измерения из unitMap, которые совместимы с заданной единицей
     * @return список совместимых единиц в виде Map.Entry<String, Unit>
     */
    public List<Map.Entry<String, Unit<?>>> getCompatibleUnits(Unit targetUnit) {
        List<Map.Entry<String, Unit<?>>> compatibleUnits = new ArrayList<>();

        if (targetUnit == null || unitMap == null) {
            return compatibleUnits;
        }

        for (Map.Entry<String, Unit<?>> entry : unitMap.entrySet()) {
            Unit unit = entry.getValue();
            if (unit != null && areUnitsCompatible(targetUnit, unit)) {
                compatibleUnits.add(entry);
            }
        }

        return compatibleUnits;
    }

    /**
     * Возвращает список имен всех единиц измерения, совместимых с заданной
     * @return список имен совместимых единиц
     */
    public List<String> getCompatibleUnitNames(String targetUnitName) {
        List<String> compatibleNames = new ArrayList<>();

        if (targetUnitName == null || !unitMap.containsKey(targetUnitName)) {
            return compatibleNames;
        }

        Unit targetUnit = unitMap.get(targetUnitName);
        List<Map.Entry<String, Unit<?>>> compatibleEntries = getCompatibleUnits(targetUnit);

        for (Map.Entry<String, Unit<?>> entry : compatibleEntries) {
            compatibleNames.add(entry.getKey());
        }

        return compatibleNames;
    }
}
