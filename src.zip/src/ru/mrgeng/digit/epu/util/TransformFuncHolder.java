package ru.mrgeng.digit.epu.util;

import com.haulmont.cuba.core.global.Messages;
import org.apache.commons.lang3.time.DateUtils;
import ru.mrgeng.digit.dgcore.RequestResult;
import ru.mrgeng.digit.dgcore.service.IImportObj;
import ru.mrgeng.digit.dgcore.service.ImportObj;
import ru.mrgeng.digit.epu.mp.TransformFunc;
import ru.mrgeng.digit.epu.transform.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;


/**
 * При добавлении новой функции:
 * 1) добавить проверку в testParams;
 * 2) добавить описание в getFunctionDependencies;
 * 3) добавить тесты в ru/digit/global/TransformFuncTest.java
 * 4) добавить преобразование в transform
 * 5) добавить новую запись в справочник exel
 * ...
 * Х) Протестировать выбор функции преобразования в UI
 */
public class TransformFuncHolder {

    //-- Эти значения - код сущности из справочника
    public static final String DAY_TRUNCATE_MINUS_ONE = "DayTruncMinusOne";
    public static final String DAY_TRUNCATE_MINUS_TWO = "DayTruncMinusTwo";
    public static final String HOUR_TRUNCATE = "HourTrunc";
    public static final String DAY_TRUNCATE = "DayTrunc";
    public static final String HOURS_PLUS_ONE = "HoursPlusOne";
    public static final String HOURS_PLUS_TWO = "HoursPlusTwo";
    public static final String HOURS_PLUS_THREE = "HoursPlusThree";
    public static final String HOURS_PLUS_FOUR = "HoursPlusFour";
    public static final String HOURS_PLUS_FIVE = "HoursPlusFive";
    public static final String HOURS_MINUS_THREE = "HoursMinusThree";
    public static final String HOURS_MINUS_ONE = "HoursMinusOne";
    public static final String HOURS_MINUS_TWO = "HoursMinusTwo";
    //
    public static final String GET_BIT_VALUE = "GetBitValue";
    public static final String GET_SENSOR_VALUES = "GetSensorValues";
    public static final String ROUND_TO_0_OR_100 = "X<1?:X=0;X>100?X=100";
    public static final String GET_EQUAL_VALUE = "GetEqualValue";
    public static final String GET_UNEQUAL_VALUE = "GetUnEqualValue";
    public static final String REVERS_GET_BIT_VALUE = "ReversGetBitValue";
    public static final String PLUS_MINUS_OR_GET_PARAM_VALUE = "+|-|=";
    public static final String BITS_PARSER = "BitsParser";
    public static final String TRANSFORM_4_20_TO_DOUBLE = "4-20_ToDouble";
    public static final String TRANSFORM_400_2000_TO_DOUBLE = "400-2000_ToDouble";
    public static final String TRANSFORM_0_32768_TO_DOUBLE = "0-32768_ToDouble";
    public static final String TRANSFORM_0_100_TO_DOUBLE = "0-100_ToDouble";
    public static final String TRANSFORM_0_10000_TO_DOUBLE = "0-10000_ToDouble";
    public static final String TRANSFORM_20_100_TO_DOUBLE = "20-100_ToDouble";
    public static final String STRING_FROM_BIT_VALUE = "StrForBitValue";
    public static final String STRING_FROM_CODE_VALUE = "StrForCodeValue";
    public static final String DIVIDE_VALUE = "Value/x";
    public static final String MULTIPLY_VALUE = "Value*x";
    public static final String TRANSFORM_0_1023_TO_DOUBLE = "0-1023_ToDouble";
    public static final String TRANSFORM_0_4095_TO_DOUBLE = "0-4095_ToDouble";
    public static final String TRANSFORM_81_409_TO_DOUBLE = "81-409_ToDouble";
    public static final String TRANSFORM_204_1023_TO_DOUBLE = "204-1023_ToDouble";
    public static final String TRANSFORM_0_5042_TO_DOUBLE = "0-5042_ToDouble";
    public static final String TRANSFORM_0_1677_TO_DOUBLE = "0-1677_ToDouble";
    public static final String TRANSFORM_RANGE_TO_RANGE_TO_DOUBLE = "RangeToRangeToDouble";
    public static final String NO_TRANSFORM_STRING = "NoTransformString";
    public static final String NO_TRANSFORM_DOUBLE = "NoTransformDouble";
    private static final ConcurrentMap<String, Bound> map4_20 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map400_2000 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_32768 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_100 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_10000 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map20_100 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_1023 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_4095 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map81_409 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map204_1023 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_5042 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Bound> map0_1677 = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, BitInterpreter> bitMapper = new ConcurrentHashMap<>();

    private static final TransformFuncHolder instance = new TransformFuncHolder();

    public static final TransformFuncHolder getInstance() {
        return instance;
    }

    public <T> T transform(String funcName, String funcParams, T value) throws TransformException {
        try {
            return transformWithParams(funcName, funcParams, value);
        } catch (TransformException te) {
            throw te;
        } catch (Throwable t) {
            throw new TransformException("Ошибка в функции преобразования: " + t.getMessage(), value, funcName + " параметры " + funcParams);
        }
    }

    private Object tryAddTransforms(String funcName, String params, Object value) throws TransformException {
        Transform transform = Transform.fromId(funcName);
        if (transform != null) {
            return TransformProc.getInstance().transform(transform, params, value);
        }
        throw new NotExistTransformException("Неизвестная функция: " + funcName);
    }

    //todo - каждый раз валидировать params в трансформации - не очень производительно решение
    public <T> T transformWithParams(String funcName, String params, T value) throws TransformException {
        switch (funcName) {
            case DAY_TRUNCATE_MINUS_ONE: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.set(Calendar.HOUR_OF_DAY, 0);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 1);
                return (T) cal.getTime();
            }
            case DAY_TRUNCATE_MINUS_TWO: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.set(Calendar.HOUR_OF_DAY, 0);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 2);
                return (T) cal.getTime();
            }
            case DAY_TRUNCATE: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.set(Calendar.HOUR_OF_DAY, 0);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return (T) cal.getTime();
            }
            case HOUR_TRUNCATE: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return (T) cal.getTime();
            }
            case HOURS_PLUS_ONE: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.add(Calendar.HOUR_OF_DAY, 1);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return (T) cal.getTime();
            }
            case HOURS_PLUS_TWO: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.add(Calendar.HOUR_OF_DAY, 2);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return (T) cal.getTime();
            }
            case HOURS_PLUS_THREE: {
                return (T) DateUtils.addHours((Date) value, 3);
            }
            case HOURS_MINUS_THREE: {
                return (T) DateUtils.addHours((Date) value, -3);
            }
            case HOURS_PLUS_FOUR: {
                return (T) DateUtils.addHours((Date) value, 4);
            }
            case HOURS_PLUS_FIVE: {
                return (T) DateUtils.addHours((Date) value, 5);
            }
            case HOURS_MINUS_ONE: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.add(Calendar.HOUR_OF_DAY, -1);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return (T) cal.getTime();
            }
            case HOURS_MINUS_TWO: {
                Calendar cal = Calendar.getInstance();
                cal.setTime((Date) value);
                cal.add(Calendar.HOUR_OF_DAY, -2);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return (T) cal.getTime();
            }
            case GET_BIT_VALUE: {
                Double val = (Double) value;
                int at = Integer.parseInt(params) - 1;
                if (at > 64 || at < 0) {
                    return null;
                }
                long l = val.longValue() >> at & 1;
                return (T) Double.valueOf(l);
            }
            case GET_SENSOR_VALUES: {
                // биты датчик 0-1 CH1, 2-3 CO1, 4-5 FIRE1, 6-7 CH2, 8-9 CO2, 10-11 FIRE2
                int fromIndex = Integer.parseInt(params);
                Double val = (Double) value;

                // По битам n, n+1
                int result = val.shortValue() >> fromIndex & 1;
                result |= (val.shortValue() >> (fromIndex + 1) & 1) << 1;

                return (T) Double.valueOf(result);
            }
            case ROUND_TO_0_OR_100: {
                Double x = (Double) value;
                if (x < 1.0) {
                    return (T) Double.valueOf(0.0);
                } else if (x > 100.0) {
                    return (T) Double.valueOf(100.0);
                }
                return (T) x;
            }
            case GET_EQUAL_VALUE: {
                Double paramParsed = Double.parseDouble(params);
                if (value.equals(paramParsed)) {
                    return (T) Double.valueOf(1.0);
                } else {
                    return (T) Double.valueOf(0.0);
                }
            }
            case GET_UNEQUAL_VALUE: {
                Double paramParsed = Double.parseDouble(params);
                if (value.equals(paramParsed)) {
                    return (T) Double.valueOf(0.0);
                } else {
                    return (T) Double.valueOf(1.0);
                }
            }
            case REVERS_GET_BIT_VALUE: {//--copy of GET_BIT_VALUE
                Double val = (Double) value;
                int at = Integer.parseInt(params) - 1;
                if (at > 64 || at < 0) {
                    return null;
                }
                long l = val.longValue() >> at & 1;
                //--
                if (l == 1) {
                    return (T) Double.valueOf(0.0);
                } else {
                    return (T) Double.valueOf(1.0);
                }
            }
            case PLUS_MINUS_OR_GET_PARAM_VALUE: {
                if (params.startsWith("-") || params.startsWith("+")) {
                    Double x = (Double) value;
                    Double y = Double.parseDouble(params);
                    y = x + y;
                    return (T) y;
                }
                return (T) Double.valueOf(params);
            }
            case BITS_PARSER: {
                long mask = Long.decode(value.toString());
                BitInterpreter bitInterpreter = bitMapper.computeIfAbsent(params, BitInterpreter::new);
                String resultMessage = bitInterpreter.getStringFromMask(mask);
                return (T) resultMessage;
            }
            case TRANSFORM_4_20_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 3.7 || income > 20.3) {
                    throw new TransformException("Выход за границы 4-20: " + income, income, "[4-20]");
                }
                Bound bound = map4_20.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 4d, 16d, 20d);
                return (T) result;
            }
            case TRANSFORM_400_2000_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 370 || income > 2030) {
                    throw new TransformException("Выход за границы 400-2000: " + income, income, "[400-2000]");
                }
                Bound bound = map400_2000.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 400d, 1600d, 2000d);
                return (T) result;
            }
            case TRANSFORM_0_32768_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 0 || income > 32768) {
                    throw new TransformException("Выход за границы 0-32768: " + income, income, "[0-32768]");
                }
                Bound bound = map0_32768.computeIfAbsent(params, Bound::new);
                double percent = (income) / 32768;
                Double result = bound.leftBound + bound.interval * percent;
                return (T) result;
            }
            case TRANSFORM_0_100_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 0 || income > 100) {
                    throw new TransformException("Выход за границы 0-100: " + income, income, "[0-100]");
                }
                Bound bound = map0_100.computeIfAbsent(params, Bound::new);
                double percent = (income) / 100;
                Double result = bound.leftBound + bound.interval * percent;
                return (T) result;
            }
            case TRANSFORM_0_10000_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 0 || income > 10000) {
                    throw new TransformException("Выход за границы 0-10000: " + income, income, "[0-10000]");
                }
                Bound bound = map0_10000.computeIfAbsent(params, Bound::new);
                double percent = (income) / 10000;
                Double result = bound.leftBound + bound.interval * percent;
                return (T) result;
            }
            case TRANSFORM_20_100_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 20 || income > 100) {
                    throw new TransformException("Выход за границы 20-100: " + income, income, "[20-100]");
                }
                Bound bound = map20_100.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 20d, 80d, 100d);
                return (T) result;
            }
            case TRANSFORM_0_1023_TO_DOUBLE: {
                double income = (Double) value;
                if (income < -1 || income > 1024) {
                    throw new TransformException("Выход за границы 0-1023: " + income, income, "[0-1023]");
                }
                Bound bound = map0_1023.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 0d, 1023d, 1023d);
                return (T) result;
            }
            case TRANSFORM_0_4095_TO_DOUBLE: {
                double income = (Double) value;
                if (income < -1 || income > 4096) {
                    throw new TransformException("Выход за границы 0-4095: " + income, income, "[0-4095]");
                }
                Bound bound = map0_4095.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 0d, 4095d, 4095d);
                return (T) result;
            }
            case TRANSFORM_81_409_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 81 || income > 409) {
                    throw new TransformException("Выход за границы 81-409: " + income, income, "[81-409]");
                }
                Bound bound = map81_409.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 81d, 328d, 409d);
                return (T) result;
            }
            case TRANSFORM_204_1023_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 204 || income > 1023) {
                    throw new TransformException("Выход за границы 204-1023: " + income, income, "[204-1023]");
                }
                Bound bound = map204_1023.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 204d, 819d, 1023d);
                return (T) result;
            }
            case TRANSFORM_0_5042_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 0 || income > 5042) {
                    throw new TransformException("Выход за границы 0-5042: " + income, income, "[0-5042]");
                }
                Bound bound = map0_5042.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 0d, 5042d, 5042d);
                return (T) result;
            }
            case TRANSFORM_0_1677_TO_DOUBLE: {
                double income = (Double) value;
                if (income < 0 || income > 1677) {
                    throw new TransformException("Выход за границы 0-1677: " + income, income, "[0-1677]");
                }
                Bound bound = map0_1677.computeIfAbsent(params, Bound::new);
                Double result = bound.calc(income, 0d, 1677d, 1677d);
                return (T) result;
            }
            case STRING_FROM_BIT_VALUE: {
                try {
                    Long longVal = null;
                    if (value instanceof Double) {
                        longVal = ((Double) value).longValue();
                    } else {
                        try {
                            Double paramValue = (Double) ParamTypeHolder.getInstance().getParamValue(value.toString(), ParamTypeHolder.DOUBLE_TYPE_CODE);
                            longVal = paramValue.longValue();
                        } catch (Throwable t) {
                            throw new TransformException("Ошибка получения числа из значения " + value + ": " + t.getMessage(), null, STRING_FROM_BIT_VALUE);
                        }
                    }
                    int i = params.indexOf('=');
                    if (i < 0) {
                        throw new TransformException("Не найден разделитель = в параметре: " + params, null, STRING_FROM_BIT_VALUE);
                    }
                    String bitNumStr = params.substring(0, i).trim();
                    int bitNum = Integer.parseInt(bitNumStr) - 1;
                    boolean revers = false;
                    if (bitNum < 0) {
                        revers = true;
                        bitNum = -bitNum;
                    }
                    if (bitNum > 64) {
                        throw new TransformException("Значение бита " + bitNum + " > 64 в параметре: " + params, null, STRING_FROM_BIT_VALUE);
                    }
                    long isOn = longVal >> bitNum & 1;
                    String res = ((isOn == 1 && !revers) || (isOn == 0 && revers)) ? params.substring(i + 1).trim() : null;
                    return (T) res;
                } catch (Throwable t) {
                    throw new TransformException("Ошибка выполнения функции на значении " + value + ": " + t.getMessage(), null, STRING_FROM_BIT_VALUE);
                }
            }
            case STRING_FROM_CODE_VALUE: {
                try {
                    String strVal = value.toString();
                    int i = params.indexOf('=');
                    if (i < 0) {
                        throw new TransformException("Не найден разделитель = в параметре: " + params, null, STRING_FROM_CODE_VALUE);
                    }
                    String codeStr = params.substring(0, i).trim();
                    return codeStr.equals(strVal.trim()) ? (T) params.substring(i + 1).trim() : null;
                } catch (Throwable t) {
                    throw new TransformException("Ошибка выполнения функции на значении " + value + ": " + t.getMessage(), null, STRING_FROM_CODE_VALUE);
                }
            }
            case DIVIDE_VALUE: {
                Double param;
                try {
                    param = Double.parseDouble(params);
                } catch (NumberFormatException nfe) {
                    throw new TransformException("Делитель не является типом Double: " + params, null, DIVIDE_VALUE);
                }
                if (param <= 0) {
                    throw new TransformException("Делитель меньше или равен нулю:  " + param, null, DIVIDE_VALUE);
                }
                Double result = (Double) value / param;
                return (T) result;
            }
            case MULTIPLY_VALUE: {
                Double param;
                try {
                    param = Double.parseDouble(params);
                } catch (NumberFormatException nfe) {
                    throw new TransformException("Множитель не является типом Double: " + params, null, MULTIPLY_VALUE);
                }
                Double result = (Double) value * param;
                return (T) result;
            }
            default:
                return (T) tryAddTransforms(funcName, params, value);
        }
    }

    class BitInterpreter {// 0==Устройство включено кнопкой;1/0==Номер сим карты;1/1==Номер сим чипа;2==Координаты определенны
        private List<BitKeeper> listBits;

        public BitInterpreter(String codesDescription) {
            HashMap<Integer, BitKeeper> listBitsMap = new HashMap<>();
            String[] oneBitDescription = codesDescription.split(";");
            if (oneBitDescription.length == 0)
                throw new RuntimeException("Должен быть заполнен: " + codesDescription);
            for (String description : oneBitDescription) {
                String[] bitAndMessage = description.split("==");
                if (bitAndMessage.length != 2)
                    throw new RuntimeException("Каждая часть (разделенная ';') должна содержать '==' - разделяющий номер бита и сообщение:" + description);
                String message = bitAndMessage[1];
                String[] bitEnt = bitAndMessage[0].split("/");
                if (bitEnt.length == 2) {
                    Integer bit = Integer.parseInt(bitEnt[0]);
                    BitKeeper keeper = listBitsMap.get(bit);

                    if (keeper == null) {
                        keeper = new BitKeeper();
                        keeper.bitNumber = bit;
                        int val = Integer.parseInt(bitEnt[1]);
                        if (val == 1) {
                            keeper.one = message;
                        } else if (val == 0) {
                            keeper.zero = message;
                        }
                        listBitsMap.put(bit, keeper);
                    } else {
                        int val = Integer.parseInt(bitEnt[1]);
                        if (val == 1) {
                            keeper.one = message;
                        } else if (val == 0) {
                            keeper.zero = message;
                        }
                    }

                } else {
                    Integer bit = Integer.parseInt(bitEnt[0]);
                    BitKeeper keeper = listBitsMap.get(bit);
                    if (keeper == null) {
                        keeper = new BitKeeper();
                        keeper.bitNumber = bit;
                    }
                    keeper.one = message;
                    listBitsMap.put(bit, keeper);
                }
            }
            listBits = listBitsMap.values().stream()
                    .sorted(Comparator.comparingInt(o -> o.bitNumber))
                    .collect(Collectors.toList());
        }

        public String getStringFromMask(long mask) {
            List<String> messages = new ArrayList<>();
            listBits.forEach(interpreter -> {
                int shift = interpreter.bitNumber;
                long resultShift = mask >> shift;
                long result = resultShift & 1;
                if (result == 1) {
                    if (interpreter.one != null)
                        messages.add(interpreter.one);
                } else {
                    if (interpreter.zero != null)
                        messages.add(interpreter.zero);
                }
            });
            return String.join(";\n", messages);
        }
    }

    class BitKeeper {
        int bitNumber;
        String zero;
        String one;
    }

    class Bound {
        double leftBound;
        double rightBound;
        double interval;

        public Bound(String params) {
            try {
                String[] bounds = params.split(":");
                if (bounds.length != 2)
                    throw new IllegalArgumentException("В параметрах преобразования " + params + " должен присутствовать 1 разделитель ':'");
                this.leftBound = Double.parseDouble(bounds[0]);
                this.rightBound = Double.parseDouble(bounds[1]);
                if (leftBound > rightBound)
                    throw new IllegalArgumentException("Левая часть больше правой");
                this.interval = this.rightBound - this.leftBound;
            } catch (Throwable t) {
                throw new IllegalArgumentException("Неправильно задан диапазон '" + params + "': " + t.getMessage());
            }
        }

        Double calc(double income, double leftRawValBorder, double delta, double rightRawValBorder) {
            if (income <= leftRawValBorder) // в этом случае нет смысла в вычислениях, сразу возвращаем граничное значение
                return leftBound;
            else if (income >= rightRawValBorder)
                return rightBound;
            double percent = (income - leftRawValBorder) / delta;
            return leftBound + interval * percent;
        }
    }

    public RequestResult testFuncParams(String funcName, String params) {// для проверки params в UI
        boolean funcExists = getFuncDeps().isFuncExists(funcName);
        if (!funcExists)
            return RequestResult.err("Неизвестная функция: " + funcName);

        boolean reqParams = getFuncDeps().reqParams(funcName);

        if (reqParams && params == null) {
            return RequestResult.err("Для функции " + funcName + " нужно указать параметры преобразования");
        }
        if (!reqParams && params != null) {
            return RequestResult.err("Функция преобразования " + funcName + " не использует параметры преобразования");
        }
        switch (funcName) {
            case REVERS_GET_BIT_VALUE:
            case GET_BIT_VALUE: {
                try {
                    Integer.parseInt(params);
                } catch (Exception e) {
                    return RequestResult.err("Ожидается целое число");
                }
                int at = Integer.parseInt(params) - 1;
                if (at > 64 || at < 0) {
                    return RequestResult.err("Ожидается целое число от 1 до 65");
                }
                return RequestResult.ok();
            }
            case GET_SENSOR_VALUES:
            case PLUS_MINUS_OR_GET_PARAM_VALUE:
            case GET_EQUAL_VALUE:
            case GET_UNEQUAL_VALUE: {
                try {
                    Double.parseDouble(params);
                    return RequestResult.ok();
                } catch (Exception e) {
                    return RequestResult.err("Ожидается число");
                }
            }
            case BITS_PARSER: {
                try {
                    new BitInterpreter(params);
                    return RequestResult.ok();
                } catch (Exception e) {
                    return RequestResult.err(e.getMessage());
                }
            }
            case TRANSFORM_20_100_TO_DOUBLE:
            case TRANSFORM_0_100_TO_DOUBLE:
            case TRANSFORM_0_10000_TO_DOUBLE:
            case TRANSFORM_0_32768_TO_DOUBLE:
            case TRANSFORM_400_2000_TO_DOUBLE:
            case TRANSFORM_0_4095_TO_DOUBLE:
            case TRANSFORM_0_1023_TO_DOUBLE:
            case TRANSFORM_4_20_TO_DOUBLE:
            case TRANSFORM_204_1023_TO_DOUBLE:
            case TRANSFORM_0_5042_TO_DOUBLE:
            case TRANSFORM_0_1677_TO_DOUBLE:
            case TRANSFORM_81_409_TO_DOUBLE: {
                try {
                    new Bound(params);
                    return RequestResult.ok();
                } catch (Exception e) {
                    return RequestResult.err(e.getMessage());
                }
            }
            case STRING_FROM_BIT_VALUE: {
                int i = params.indexOf('=');
                if (i < 0) {
                    return RequestResult.err("Не найден разделитель = в параметре");
                }
                String bitNumStr = params.substring(0, i).trim();
                try {
                    Integer.parseInt(bitNumStr);
                } catch (Exception e) {
                    return RequestResult.err("Значение бита должно быть целым числом");
                }
                int bitNum = Integer.parseInt(bitNumStr) - 1;
                if (bitNum > 64) {
                    return RequestResult.err("Значение бита д. б. < 66 ");
                }
                return RequestResult.ok();
            }
            case STRING_FROM_CODE_VALUE: {
                int i = params.indexOf('=');
                if (i < 0) {
                    return RequestResult.err("Не найден разделитель = в параметре");
                }
                String msgStr = params.substring(i + 1).trim();
                if (msgStr.isBlank()) {
                    return RequestResult.err("Сообщение по коду не может быть пустым");
                }
                return RequestResult.ok();
            }
            case DIVIDE_VALUE: {
                int param;
                try {
                    param = Integer.parseInt(params);
                } catch (NumberFormatException nfe) {
                    return RequestResult.err("Ожидается целое положительное число");
                }
                if (param <= 0) {
                    return RequestResult.err("Ожидается целое положительное число");
                }
                return RequestResult.ok();
            }
            case MULTIPLY_VALUE: {
                try {
                    Double.parseDouble(params);
                } catch (NumberFormatException nfe) {
                    return RequestResult.err("Ожидается число");
                }
                return RequestResult.ok();
            }
        }
        Transform transform = Transform.fromId(funcName);
        if (transform != null) {
            try {
                transform.validateParams(params);
            } catch (TransformValidationException e) {
                return RequestResult.err(e.getMessage());
            }
            return RequestResult.ok();
        }
        return RequestResult.ok();
    }

    public class FunctionDependencies {
        private final Map<String, Map<String, Set<String>>> outToInFunctions = new HashMap<>();
        private final Map<String, Set<String>> functionByOut = new HashMap<>();

        private final Map<String, Set<String>> functionByIn = new HashMap<>();

        private final Set<String> allFunctions = new HashSet<>();

        public final Map<String, Boolean> reqParams = new HashMap<>();

        public final Map<String, String> funcNames = new HashMap<>();

        public final Map<String, Transform> funcEnumValue = new HashMap<>();

        public final Map<String, String> inTypes = new HashMap<>();

        public final Map<String, String> outTypes = new HashMap<>();

        public Set<String> funcsByOut(String func) {
            return functionByOut.get(func);
        }

        public Set<String> funcsByIn(String func) {
            return functionByIn.get(func);
        }

        public Set<String> allFuncs() {
            return allFunctions;
        }

        public Set<String> getDateInDateOutFunctions() {
            return outToInFunctions.get(ParamTypeHolder.DATE_TYPE_CODE)
                    .get(ParamTypeHolder.DATE_TYPE_CODE);
        }

        public String getInType(String funcName) {
            return inTypes.get(funcName);
        }

        public String getOutType(String funcName) {
            return outTypes.get(funcName);
        }

        public boolean isFuncExists(String func) {
                return allFunctions.contains(func);
        }

        public boolean reqParams(String func) {
            return reqParams.getOrDefault(func, false);
        }

        public List<IImportObj> getAllFuncImportObjs(Messages msgs) {
            List<IImportObj> res = new ArrayList<>();
            for (String funcCode : allFunctions) {
                ImportObj obj = new ImportObj("mp_TransformFunc");
                obj.put("code", funcCode);
                Transform transform = funcEnumValue.get(funcCode);
                if (transform != null)
                    obj.put("name", msgs.getMessage(transform));
                else {
                    String name = funcNames.get(funcCode);
                    obj.put("name", name != null ? name : funcCode);
                }
                res.add(obj);
            }
            return res;
        }
    }

    private FunctionDependencies funcDeps = null;

    public FunctionDependencies getFuncDeps() {// только для webUI
        if (funcDeps == null) {
            FunctionDependencies fd = new FunctionDependencies();
            final String DATE = ParamTypeHolder.DATE_TYPE_CODE;
            final String DOUBLE = ParamTypeHolder.DOUBLE_TYPE_CODE;
            final String STRING = ParamTypeHolder.STRING_TYPE_CODE;

            fillFuncDep(fd, DATE, DAY_TRUNCATE_MINUS_ONE, DATE, "Обрезать до 00:00 и отнять 1 день", false);
            fillFuncDep(fd, DATE, DAY_TRUNCATE_MINUS_TWO, DATE, "Обрезать до 00:00 и отнять 2 дня", false);
            fillFuncDep(fd, DATE, HOUR_TRUNCATE, DATE, "Обрезать мин/сек/миллисек", false);
            fillFuncDep(fd, DATE, DAY_TRUNCATE, DATE, "Обрезать до 00:00", false);
            fillFuncDep(fd, DATE, HOURS_PLUS_ONE, DATE, "+1 час", false);
            fillFuncDep(fd, DATE, HOURS_PLUS_TWO, DATE, "+2 часа", false);
            fillFuncDep(fd, DATE, HOURS_PLUS_THREE, DATE, "+3 часа", false);
            fillFuncDep(fd, DATE, HOURS_PLUS_FOUR, DATE, "+4 часа", false);
            fillFuncDep(fd, DATE, HOURS_PLUS_FIVE, DATE, "+5 часов", false);
            fillFuncDep(fd, DATE, HOURS_MINUS_ONE, DATE, "-1 час", false);
            fillFuncDep(fd, DATE, HOURS_MINUS_TWO, DATE, "-2 часа", false);
            fillFuncDep(fd, DATE, HOURS_MINUS_THREE, DATE, "-3 часа", false);
            //--
            fillFuncDep(fd, DOUBLE, GET_BIT_VALUE, DOUBLE, "Получить значение бита");
            fillFuncDep(fd, DOUBLE, GET_SENSOR_VALUES, DOUBLE, "Получить значение 2 бит начиная с указанной позиции");
            fillFuncDep(fd, DOUBLE, ROUND_TO_0_OR_100, DOUBLE, "Менее 1 преобразовывать в 0, более 100 в 100", false);
            fillFuncDep(fd, DOUBLE, GET_EQUAL_VALUE, DOUBLE, "Если число = заданному значению, то вернуть 1, иначе вернуть 0");
            fillFuncDep(fd, DOUBLE, GET_UNEQUAL_VALUE, DOUBLE, "Если равно заданному значению, то вернуть 0, иначе вернуть 1");
            fillFuncDep(fd, DOUBLE, REVERS_GET_BIT_VALUE, DOUBLE, "Получить значение бита и преобразовать в противоположное");
            fillFuncDep(fd, DOUBLE, PLUS_MINUS_OR_GET_PARAM_VALUE, "Прибавить, удалить, установить значение", DOUBLE);
            fillFuncDep(fd, STRING, BITS_PARSER, STRING, "Преобразовать в строку все биты в маске");
            fillFuncDep(fd, DOUBLE, TRANSFORM_4_20_TO_DOUBLE, DOUBLE, "4-20 в число из диапазона (пример параметра 0:10)");
            fillFuncDep(fd, DOUBLE, TRANSFORM_400_2000_TO_DOUBLE, DOUBLE, "0,4 ..2 В (в число из диапазона)");
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_32768_TO_DOUBLE, DOUBLE, "0-32768 в число из диапазона (пример параметра -50:50)");
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_100_TO_DOUBLE, "0-100  в число из диапазона (пример параметра -50:50)", DOUBLE);
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_1023_TO_DOUBLE, DOUBLE, "0-1023 в число из диапазона");
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_4095_TO_DOUBLE, DOUBLE, "0-4095 в число из диапазона");
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_10000_TO_DOUBLE, "0-10000 в число из диапазона", DOUBLE);
            fillFuncDep(fd, DOUBLE, TRANSFORM_20_100_TO_DOUBLE, DOUBLE, "20-100 в число из диапазона (пример параметра -50:50");
            fillFuncDep(fd, DOUBLE, TRANSFORM_81_409_TO_DOUBLE, DOUBLE, "81-409 в число из диапазона");
            fillFuncDep(fd, DOUBLE, TRANSFORM_204_1023_TO_DOUBLE, DOUBLE, "204-1023 в число из диапазона");
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_5042_TO_DOUBLE, DOUBLE, "0-5042 в число из диапазона");
            fillFuncDep(fd, DOUBLE, TRANSFORM_0_1677_TO_DOUBLE, DOUBLE, "0-1677 в число из диапазона");
            fillFuncDep(fd, DOUBLE, STRING_FROM_BIT_VALUE, STRING, "Преобразовать бит в строку. 1=Событие 1");
            fillFuncDep(fd, STRING, STRING_FROM_BIT_VALUE, STRING, "Преобразовать бит в строку. 1=Событие 1");// возможно достаточно варианта по DOUBLE
            fillFuncDep(fd, DOUBLE, STRING_FROM_CODE_VALUE, STRING, "Преобразовать код в строку");
            fillFuncDep(fd, STRING, STRING_FROM_CODE_VALUE, STRING, "Преобразовать код в строку");// возможно достаточно варианта по DOUBLE
            fillFuncDep(fd, DOUBLE, DIVIDE_VALUE, DOUBLE, "Разделить");
            fillFuncDep(fd, DOUBLE, MULTIPLY_VALUE, DOUBLE, "Умножить");

            for (Transform value : Transform.values()) {
                fillFuncDep(fd, value.getCtx().getFromType().code, value.getId(), value.getCtx().getToType().code, value, value.getCtx().isAcceptParams());
            }
            funcDeps = fd;
        }
        return funcDeps;
    }

    private void fillFuncDep(FunctionDependencies fd, String inType, String func, String outType, Transform enumVal, boolean reqParams) {
        fillFuncDep(fd, inType, func, outType, reqParams);
        fd.funcEnumValue.put(func, enumVal);
    }

    private void fillFuncDep(FunctionDependencies fd, String inType, String func, String outType, String name) {
        fillFuncDep(fd, inType, func, outType, true);
        fd.funcNames.put(func, name);
    }

    private void fillFuncDep(FunctionDependencies fd, String inType, String func, String outType, String name, boolean reqParams) {
        fillFuncDep(fd, inType, func, outType, reqParams);
        fd.funcNames.put(func, name);
    }

    private void fillFuncDep(FunctionDependencies fd, String inType, String func, String outType, boolean reqParams) {
        fillFuncDep(fd, inType, func, outType);
        fd.reqParams.put(func, reqParams);
    }

    private void fillFuncDep(FunctionDependencies fd, String inType, String func, String outType) {
        fd.reqParams.put(func, true);
        fd.allFunctions.add(func);

        fd.inTypes.put(func, inType);
        fd.outTypes.put(func, outType);

        fd.functionByIn.compute(inType, (prevKey, prevVal) -> {
            if (prevVal == null)
                prevVal = new HashSet<>();
            prevVal.add(func);
            return prevVal;
        });

        fd.functionByOut.compute(outType, (prevKey, prevVal) -> {
            if (prevVal == null)
                prevVal = new HashSet<>();
            prevVal.add(func);
            return prevVal;
        });

        fd.outToInFunctions.compute(outType, (prevInKey, prevInVal) -> {
            if (prevInVal == null)
                prevInVal = new HashMap<>();
            prevInVal.compute(inType, (prevOutKey, prevOutVal) -> {
                if (prevOutVal == null)
                    prevOutVal = new HashSet<>();
                prevOutVal.add(func);
                return prevOutVal;
            });
            return prevInVal;
        });
    }

}