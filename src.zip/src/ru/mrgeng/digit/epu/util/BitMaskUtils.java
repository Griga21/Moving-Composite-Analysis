package ru.mrgeng.digit.epu.util;

import ru.mrgeng.digit.epu.mp.DeviceParam;
import ru.mrgeng.digit.epu.service.MpService;

public class BitMaskUtils {

    public static final int READ_FLAG_INDEX = 0;
    public static final int WRITE_FLAG_INDEX = 1;

    public static final int READ_FLAG = 0B1;
    public static final int WRITE_FLAG = 0B10;

    public static String getDeviceParamMaskDescription(Integer mask) {
        if (mask == null)
            return null;
        int intMask = mask;
        StringBuilder builder = new StringBuilder();
        if (isRead(intMask))
            builder.append("R");
        if (isWrite(intMask))
            builder.append(builder.length() == 0 ? "W" : "/W");
        return builder.toString();
    }

    public static boolean isRead(Integer mask) {
        return mask != null && isRead((int) mask);
    }

    public static boolean isWrite(Integer mask) {
        return mask != null && isWrite((int) mask);
    }

    public static boolean isRead(int mask) {
        return isBitFill(READ_FLAG_INDEX, mask);
    }

    public static boolean isWrite(int mask) {
        return isBitFill(WRITE_FLAG_INDEX, mask);
    }

    public static boolean isWriteOnly(DeviceParam param) {
        if (param.getFlag() != null && param.getFlag() != 0)
            return param.getFlag() == WRITE_FLAG;
        return getFlagByDeviceParamCode(param.getCode()) == WRITE_FLAG;
    }

    public static int setRead(boolean isRead, Integer mask) {
        return setRead(isRead, getMaskIntValue(mask));
    }

    public static int setWrite(boolean isWrite, Integer mask) {
        return setWrite(isWrite, getMaskIntValue(mask));
    }

    public static int setRead(boolean isRead, int mask) {
        return changeFlag(isRead, READ_FLAG, mask);
    }

    public static int setWrite(boolean isWrite, int mask) {
        return changeFlag(isWrite, WRITE_FLAG, mask);
    }

    private static int changeFlag(boolean isAdd, int flag, int mask) {
        return isAdd ? addFlag(flag, mask) : removeFlag(flag, mask);
    }

    private static int getMaskIntValue(Integer mask) {
        return mask == null ? 0 : mask;
    }

    private static boolean isBitFill(int position, int mask) {
        return (mask >> position & 1) == 1;
    }

    private static int addFlag(int flag, int mask) {
        return mask | flag;
    }

    private static int removeFlag(int flag, int mask) {
        return mask & ~flag;
    }

    /**
     * Использовать только если флаг не установлен
     */
    public static int getFlagByDeviceParamCode(String code) {
        return code.endsWith(MpService.paramSetEnd) ? BitMaskUtils.WRITE_FLAG : BitMaskUtils.READ_FLAG;
    }

}
