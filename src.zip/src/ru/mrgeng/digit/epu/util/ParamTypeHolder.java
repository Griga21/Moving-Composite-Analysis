package ru.mrgeng.digit.epu.util;

import ru.mrgeng.digit.dgcore.DateUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ParamTypeHolder {

    public static final String DOUBLE_TYPE_CODE = "double";
    public static final String DATE_TYPE_CODE = "timestamp";
    public static final String STRING_TYPE_CODE = "string";
    public static final String INTEGER_TYPE_CODE = "int";
    public static final String BOOLEAN_TYPE_CODE = "boolean";
    private Map<String, TypeInfo> types = new HashMap<>();

    private static ParamTypeHolder defaultInstance = new ParamTypeHolder();

    public static final ParamTypeHolder getInstance() {
        return defaultInstance;
    }

    public class ParseError extends Exception {
        public ParseError(String msg) {
            super(msg);
        }
    }

    public abstract class TypeInfo<T> {
        public final String code;

        protected TypeInfo(String code) {
            this.code = code;
        }

        public abstract T parseFromStr(String obj) throws ParseError;

        public String toStr(Object to) {
            return to.toString();
        }

        public boolean isThisType(String typeCode) {
            return typeCode.equals(code);
        }
    }

    public class StringType extends TypeInfo<String> {
        protected StringType(String code) {
            super(code);
        }

        @Override
        public String parseFromStr(String obj) throws ParseError {
            return obj;
        }
    }

    public class DoubleType extends TypeInfo<Double> {
        protected DoubleType(String code) {
            super(code);
        }

        @Override
        public Double parseFromStr(String obj) throws ParseError {
            try {
                if (obj.startsWith("0x") || obj.startsWith("0X")) {
                    Long decode = Long.decode(obj);
                    return decode.doubleValue();
                } else {
                    try {
                        return Double.parseDouble(obj);
                    } catch (Throwable t) {
                        if (obj.contains(",")) {
                            return Double.parseDouble(obj.replace(',', '.'));
                        } else if (obj.equalsIgnoreCase("true"))
                            return 1.0d;
                        if (obj.equalsIgnoreCase("false"))
                            return 0.0d;
                        try {
                            Date date = TIMESTAMP.parseFromStr(obj);
                            return (double) date.getTime();
                        } catch (Throwable ignore) {
                        }
                        throw t;
                    }
                }
            } catch (Throwable t) {
                throw new ParseError("Ошибка получения " + code + " из '" + obj + "': " + t.getMessage());
            }
        }
    }


    public class DateType extends TypeInfo<Date> {

        private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DateUtils.COMMON_TS_FORMAT);

        private final DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern(DateUtils.COMMON_TS_NO_MS_FORMAT);

        private final DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd MMM HH:mm:ss");

        protected DateType(String code) {
            super(code);
        }

        @Override
        public Date parseFromStr(String obj) throws ParseError {
            try {
                LocalDateTime ldt = LocalDateTime.parse(obj, formatter);
                return java.sql.Timestamp.valueOf(ldt);
            } catch (Throwable t) {
                try {
                    LocalDateTime ldt1 = LocalDateTime.parse(obj, formatter1);
                    return java.sql.Timestamp.valueOf(ldt1);
                } catch (Throwable t1) {
                    try {
                        LocalDateTime ldt2 = LocalDateTime.parse(obj, formatter2);
                        return java.sql.Timestamp.valueOf(ldt2);
                    } catch (Throwable t2) {
                        try {
                            return new Date(Long.parseLong(obj));
                        } catch (Throwable t3) {
                            throw new ParseError("Ошибка получения '" + code + "' из " + obj + ": " + t2.getMessage());
                        }

                    }
                }
            }
        }
    }

    public final DoubleType DOUBLE = new DoubleType(DOUBLE_TYPE_CODE);

    public final DateType TIMESTAMP = new DateType(DATE_TYPE_CODE);

    public final StringType STRING = new StringType(STRING_TYPE_CODE);

    public ParamTypeHolder() {
        initKnownTypes();
    }

    public void initKnownTypes() {
        registerType(DOUBLE);
        registerType(TIMESTAMP);
        registerType(STRING);
    }

    public <T> void registerType(TypeInfo<T> type) {
        String code = type.code;
        if (types.containsKey(code))
            throw new IllegalArgumentException("Тип уже был зарегистрирован: " + code + ": " + types.get(code));
        types.put(code, type);
    }

    public Date getDateValue(String value) throws ParseError {
        return TIMESTAMP.parseFromStr(value);
    }

    public Object getParamValue(String from, String toType) throws ParseError {
        TypeInfo typeInfo = types.get(toType);
        if (typeInfo == null)
            throw new ParseError("Неизвестный тип данных " + toType + " значение " + from);
        return typeInfo.parseFromStr(from);
    }

}
