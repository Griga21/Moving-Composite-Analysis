package ru.mrgeng.digit.epu.util;

import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.Set;

public class ProsReflectionUtils {

    public static void setNullValueToField(Set<String> fieldsName, Object object) {
        for (Field declaredField : object.getClass().getDeclaredFields()) {
            if (fieldsName.contains(declaredField.getName())) {
                declaredField.setAccessible(true);
                ReflectionUtils.setField(declaredField, object, null);
            }
        }
    }
}
