package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.service.ObjParams;

import java.util.*;

public class CalcJobData {

    Date minDate;

    Date maxDate;

    Map<String, Map<Date, ObjParams>> dataByObj = new HashMap<>();

    public Date getMinDate() {
        return minDate;
    }

    public List<ObjParams> getObjParams() {
        List<ObjParams> res = new ArrayList<>();
        dataByObj.values().stream().forEach(it -> res.addAll(it.values()));
        return res;
    }

    public void addData(ObjParams objParams) {
        dataByObj.computeIfAbsent(objParams.objId, it-> new HashMap<>()).merge(objParams.paramTime, objParams, (it1, it2) -> { it1.getParams().putAll(it2.getParams()); return it1;});
        if (minDate == null) {
            minDate = objParams.paramTime;
            maxDate = objParams.paramTime;
        } else {
            minDate = objParams.paramTime.before(minDate) ? objParams.paramTime : minDate;
            maxDate = objParams.paramTime.after(maxDate) ? objParams.paramTime : maxDate;
        }
    }

    public Date getMaxDate() {
        return maxDate;
    }

    public Map<String, Map<Date, ObjParams>> getDataByObj() {
        return dataByObj;
    }

    public ObjParams getObjParams(String objId, Date date) {
        final Map<Date, ObjParams> map = dataByObj.get(objId);
        return map != null ? map.get(date) : null;
    }

}
