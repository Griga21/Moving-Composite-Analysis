package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.service.ObjParams;
import ru.mrgeng.digit.dgcore.service.ParamInfo;

import java.util.HashMap;
import java.util.Map;

public class CalcJobDataHolder {

    Map<ParamInfo, CalcJobData> data = new HashMap<>();

    public CalcJobData getJobData(ParamInfo paramInfo) {
        return data.computeIfAbsent(paramInfo, it -> new CalcJobData());
    }

    public void addData(ParamInfo paramInfo, ObjParams paramsList) {
        getJobData(paramInfo).addData(paramsList);
    }

    public Map<ParamInfo, CalcJobData> getData() {
        return data;
    }

}
