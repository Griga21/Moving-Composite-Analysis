package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.DeviceProtoModel;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface ExportDriverService {
    String NAME = "mp_ExportDriverService";

    List<Map<String, List<Map<String, Object>>>> getFullExportReportData(Collection<DeviceProtoModel> drivers,
                                                                         String newServiceCode,
                                                                         boolean keepOriginServiceCode,
                                                                         boolean addOnlyWriteParamEmptyTransform,
                                                                         boolean addEmptyTransform);

}