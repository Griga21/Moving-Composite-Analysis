package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.service.ObjParams;
import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.mp.DeviceType;
import ru.mrgeng.digit.epu.mp.Param;
import ru.mrgeng.digit.epu.mp.ParamGroup;

import java.util.Date;
import java.util.List;
import java.util.Map;

import static ru.mrgeng.digit.epu.service.DeviceParamService.NO_MEAS_POINT;

public interface DeviceDataGeneratorTestService {
    String NAME = "dgepu_DeviceDataGeneratorTestService";

    String PERMISSION_GEN_DATA = "mp.generateData";

    String NO_LINE = NO_MEAS_POINT; // Признак отсутствия линии

    int testGenerateAndValidateDeviceDate(Date startDate, Date endDate, Integer maxCountGeneratedValues, Device device, List<String> lines);

    /**
     * Сохранить сгенерированные данные в Cassandra через ParamService
     *
     * @param device       устройство
     * @param paramListMap списки паказаний параметров разбитые по группам параметров
     * @return при успешной записи выводит запись в лог, при ошибки падает с RuntimeException
     */
    void saveGeneratedDate(Device device, List<String> lines, Map<ParamGroup, List<ObjParams>> paramListMap);

    /**
     * Проверка сгенерированных данных из Cassandra
     *
     * @param device       устройство
     * @param paramListMap списки паказаний параметров разбитые по группам параметров
     * @param dateMap      список заданных дат начала периода и конец периода (фиксируются с клюбчами starDate и endDate)
     * @return при успешной записи выводит запись в лог, при ошибки падает с RuntimeException
     */
    void checkGeneratedValues(Device device, List<String> lines, Map<ParamGroup, List<ObjParams>> paramListMap, Map<String, Date> dateMap);

    /**
     * Формирование сгенерированных значений для всех параметров распределенных за определенный период по группам
     *
     * @param paramGroupParamMap      список параметров разбитые по ParamGroup
     * @param dateMap                 список заданных дат начала периода и конец периода (фиксируются с клюбчами starDate и endDate)
     * @param maxCountGeneratedValues максимально допустимое количесво измерений на заданный период
     * @return возращает сгенерировнные значение для параметров, разбитых на группы парметров
     */
    Map<ParamGroup, List<ObjParams>> generateAllParamsValue(Device device, List<String> lines, Map<ParamGroup, List<Param>> paramGroupParamMap, Map<String, Date> dateMap, Integer maxCountGeneratedValues);

    /**
     * Генерация значейний всех параметров по определенной группе за определенный период
     *
     * @param countGenerateValue количество сгенерируемых значений
     * @param paramList          список параметров
     * @param dateMap            список заданных дат начала периода и конец периода (фиксируются с клюбчами starDate и endDate)
     * @param device             устройство
     * @return список ObjParams с записаными значенимями всех параметров для каждой точке измерения
     */
    List<ObjParams> generateListObjectParam(Integer countGenerateValue, List<Param> paramList, Map<String, Date> dateMap, Device device, List<String> lines, Integer maxCountGeneratedValues);

    /**
     * Получить последние данные за указанный период по возможности используя lastData
     *
     * @param countGenerateValue список параметров разбитые по ParamGroup
     * @return возращает сгенерировнные значение для параметров, разбитых на группы парметров
     */
    Double[] generateValue(Integer countGenerateValue);

    /**
     * Определение даты сгенерированого значения
     *
     * @param startDate  заданная дата начала периода получения данных
     * @param position   порядковый номер сгенерированного значения
     * @param paramGroup группа парамеров
     * @return возращает сгенерировнные значение для параметров, разбитых на группы парметров
     */
    Date definitionObtainData(Date startDate, Integer position, ParamGroup paramGroup);

    /**
     * Формирование списков параметров по ParamGroup
     *
     * @param deviceType тип устройства
     * @return возращает сгенерировнные значение для параметров, разбитых на группы парметров
     */
    Map<ParamGroup, List<Param>> getParamByDeviceType(DeviceType deviceType);

    /**
     * Возращает список параметров для определенного типа группы параметров
     *
     * @param paramGroup параметры группы
     * @return возращает сгенерировнные значение для параметров, разбитых на группы парметров
     */
    List<Param> getParams(ParamGroup paramGroup);
}