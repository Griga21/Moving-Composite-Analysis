package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.RequestResult;

/**
 * Сервис записи в Cassandra
 */
public interface JournalService {
    String NAME = "pros_JournalService";

    void saveRequest(MpService.SvdCmd cmd);

    void saveResult(MpService.SvdCmd cmd, RequestResult result);

}