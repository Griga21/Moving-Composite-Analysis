package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.epu.mp.DeviceParamGroup;

import java.util.List;

public interface DeviceParamGroupService {
    String NAME = "pros_DeviceParamGroupService";

    List<DeviceParamGroup> getHierarchyDeviceParamGroupById(Long id);
}