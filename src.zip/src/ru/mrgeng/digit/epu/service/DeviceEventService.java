package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.ObjParams;
import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.mp.DeviceEvent;
import ru.mrgeng.digit.epu.mp.DeviceEventType;
import ru.mrgeng.digit.epu.param.Param;
import ru.mrgeng.digit.epu.param.SeriousLevel;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Сервис обработки событий устройств
 */
public interface DeviceEventService {

    String NAME = "mp_DeviceEventService";
    String IN_REPAIR = "Принято в ремонт.";
    
    int DAY_LIMIT_DEFAULT = 180;

    List<DeviceEvent> getDeviceEventsByDepartmentId(Long departmentId, boolean unAckDeviceEvent, LocalDateTime from);

    /**
     * @param device
     * @param from
     * @param to
     * @return события за период
     */
    List<DeviceEvent> getLastEventsByDeviceForRepair(Device device, LocalDateTime from, LocalDateTime to);
    
    /**
     * Возвращает события по устройству, которым нужно проставить статус "в работе" при событии изменения статуса
     * ремонт -> в работе из карточки устройства.
     * Возвращается последняя по времени группа подряд идущих событий с ackComm, начинающегося на "Принято в ремонт."
     * и переданным устройством.
     * @param device
     * @return
     */
    List<DeviceEvent> getLastRepairingDevicesEventsGroup(Device device);
    
    /**
     * Возвращает события по устройству, которые нужно отправить в ремонт при отправке в ремонт из жунала событий.
     * Нормализованные события с eventTs раньше переданного до первого ненормализованного события.
     * @param currentDeviceEvent
     * @return
     */
    List<DeviceEvent> getDevicesForRepair(DeviceEvent currentDeviceEvent);
    
    Map<String, Map<Long, ParamEventsState>> getDeviceServiceEvent(String serviceCode);

    boolean isDeviceStatusNotWorking(Device device);

    class EventInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        public DeviceEventType type;
        public Long objId;//DeviceId
        public LocalDateTime eventTs;// LocalDateTime.now()
        public LocalDateTime dataTs;//objParam.paramTime
        public String dataInfo;//короткое описание ошибки
        public String msg;

        @Override
        public String toString() {
            return "EventInfo{" +
                    "type=" + type +
                    ", objId=" + objId +
                    ", eventTs=" + eventTs +
                    ", dataTs=" + dataTs +
                    ", dataInfo='" + dataInfo + '\'' +
                    ", msg='" + msg + '\'' +
                    '}';
        }
    }

    /**
     * Произошло событие на устройстве
     *
     * @param info описание
     * @return event
     */
    DeviceEvent fireDeviceEvent(EventInfo info);

    /**
     * Создать событие по параметру устройства, и кешировать его в serviceLastAlarm.
     *
     * @param serviceLastAlarm - кеш тревог сервиса сбора данных, Id параметров, по oid устройств
     * @param deviceConfig     - конфигурация устройства
     * @param eventInfo        - объект события
     * @param objParam         - одна запись приведенных параметров
     * @param paramInfo        - описание приведенного параметра
     */
    void fireDeviceParamEvent(Map<String, Map<Long, ParamEventsState>> serviceLastAlarm,
                              MpService.DeviceConfig deviceConfig,
                              EventInfo eventInfo,
                              ObjParams objParam,
                              Param paramInfo);

    /**
     * Проверяет кеш, на неснятые события,
     */
    void fireParamNormalization(Map<String, Map<Long, ParamEventsState>> serviceLastAlarm,
                                MpService.DeviceConfig deviceConfig,
                                ObjParams objParam,
                                Double correctVal,
                                Param paramInfo);

    class EventUserInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        public Long eventId;
        public SeriousLevel level;
        public DeviceEventType type;
        public String devName;
        public String eventMsg;
        public LocalDateTime eventTs;
        public LocalDateTime dataTs;
        public LocalDateTime normalizeTs;
        public String normalizeMsg;
        public Device device;
        public ru.mrgeng.digit.epu.mp.Param param;
        public String measCode;

        public LocalDateTime getLastParamDate() {
            if (normalizeTs == null)
                return dataTs;
            return dataTs.isAfter(normalizeTs) ? dataTs : normalizeTs;
        }
    }

    /**
     * Получить краткую информацию о неподтвержденных событиях
     *
     * @param devIds id устройств
     * @return если devIds null или пустой, то IllegalArgumentException
     */
    Map<Long, List<EventUserInfo>> getUnAckDeviceEvents(Set<Long> devIds);

    /**
     * Информация о подтверждении события
     */
    class AckInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        public LocalDateTime ackTs;
        public String ackUser;
        public String ackName;
        public String ackComm;

        @Override
        public String toString() {
            return "AckInfo{" +
                    "ackTs=" + ackTs +
                    ", ackUser='" + ackUser + '\'' +
                    ", ackName='" + ackName + '\'' +
                    ", ackComm='" + ackComm + '\'' +
                    '}';
        }
    }

    /**
     * Подтвердить получение событий
     *
     * @param eventIds id событий
     * @param ackInfo  инфо
     */
    void ackDeviceEvents(List<Long> eventIds, AckInfo ackInfo);

    List<EventUserInfo> getUnAckDeviceEvents(Long devId);

    void fireEvent(EventUserInfo info);
}