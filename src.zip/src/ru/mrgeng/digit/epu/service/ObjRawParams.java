package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.dgcore.service.util.StrUtils;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

/**
 * Структура для передачи исходных("сырых") параметров по объекту
 */
public class ObjRawParams implements Serializable, ErrorAware {

    private static final long serialVersionUID = 1L;

    public String objId;

    public Date paramTime;

    public Date obtainTime;

    public String err;

    public Map<String, String> params;

    @Override
    public String toString() {
        return StrUtils.toStr("ObjRawParams", "objId", objId, "err", err, "pt", paramTime != null ? StrUtils.formatDateWithMs(paramTime) : null, "ot", obtainTime != null ? StrUtils.formatDateWithMs(obtainTime) : null, "", params);
    }

    @Override
    public String getErr() {
        return err;
    }

    public void setErr(String err) {
        this.err = err;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public Date getParamTime() {
        return paramTime;
    }

    public void setParamTime(Date paramTime) {
        this.paramTime = paramTime;
    }

    public Date getObtainTime() {
        return obtainTime;
    }

    public void setObtainTime(Date obtainTime) {
        this.obtainTime = obtainTime;
    }

    public Map<String, String> getParams() {
        return params;
    }

    public void setParams(Map<String, String> params) {
        this.params = params;
    }
}
