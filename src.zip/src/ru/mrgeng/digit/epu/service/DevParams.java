package ru.mrgeng.digit.epu.service;

import com.google.gson.annotations.Expose;

import java.io.Serializable;
import java.util.*;

/**
 * Данные от устройства
 */
public class DevParams implements Serializable {

    // Код сервиса взаимодействия
    @Expose()
    public String svd;

    // Идентификатор запроса
    @Expose()
    public String rid;

    // Идентификатор устройства
    @Expose()
    public String uid;

    // Время формирования данных СВД, мс с момента
    @Expose()
    public long tm;

    // Флаги: 0-31 - Предупреждения,  32 - 63 - Ошибки
    //  0  - 1 признак завершения выполнения запроса/команды
    //  1  - Резерв
    //  2  - Резерв
    @Expose()
    public long flags;

    public static final String D_KEY_TM = "tm"; // Время измерения данных
    public static final String D_KEY_ERROR = "ERRR"; // Параметр в секции данных, содержащий ошибку при получении данных с устройства
    public static final String D_KEY_EVENT = "EVNT"; // Параметр в секции данных, содержащий сообщение о получении данных с устройства
    /**
     * Секция данных. Данные  в виде key/value. Зарезервированные значения key - см. в константах D_KEY_*
     */
    @Expose()
    public  List<Map<String, String>> d;

    @Override
    public String toString() {
        return "DevParams{" +
                "svd='" + svd + '\'' +
                ", rid='" + rid + '\'' +
                ", uid='" + uid + '\'' +
                ", tm=" + tm +
                ", flags=" + flags +
                ", d=" + d +
                '}';
    }
}
