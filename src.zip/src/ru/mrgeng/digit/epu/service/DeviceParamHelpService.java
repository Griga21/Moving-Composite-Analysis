package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.DataPeriodicity;
import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.mp.DeviceType;
import ru.mrgeng.digit.epu.mp.Param;

import java.util.List;

public interface DeviceParamHelpService {
    String NAME = "dgepu_DeviceParamReportService";

    List<Param> getDeviceParamList(Device device, String groupCodeEnd);

    List<Param> getDeviceParamList(Device device, String viewName, DataPeriodicity dataPeriodicity);

    DeviceType getDeviceType(Device device);
}