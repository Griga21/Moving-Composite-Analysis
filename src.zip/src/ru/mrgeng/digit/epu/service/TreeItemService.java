package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.epu.mp.tree.TreeItem;

import java.util.List;

public interface TreeItemService {
    String NAME = "pros_TreeItemService";

    List<TreeItem> getTreeItems();

    static int getResultPriority(List<Integer> priorityList) {
        return priorityList.stream().max(Integer::compareTo).orElse(30);
    }
}