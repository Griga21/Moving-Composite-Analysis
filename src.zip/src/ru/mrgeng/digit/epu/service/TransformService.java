package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.RequestResult;

public interface TransformService {
    String NAME = "dgepu_TransformService";

    /**
     *  Обновить справочник TransformFunc
     * @return Результат обновления
     */
    RequestResult updateTransformFuncs();

}