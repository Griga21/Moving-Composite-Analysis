package ru.mrgeng.digit.epu.service;


import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class ComplexPoll<AP extends AbstractPoll> {

    private AP mainPoll;

    private List<AP> additionalPolls;

    public ComplexPoll(AP poll) {
        this.mainPoll = poll;
    }

    public ComplexPoll<AP> addAdditionalPolls(ComplexPoll<AP> prevPolls,
                                              Consumer<ComplexPoll<AP>> printLogInfo) {
        if (prevPolls.additionalPolls != null)
            additionalPolls = new ArrayList<>(prevPolls.additionalPolls);
        if (prevPolls.getMainPoll().isAdditional()) {
            addAdditionalPolls(prevPolls.getMainPoll());
        } else if (this.getMainPoll().isAdditional()) {
            addAdditionalPolls(this.getMainPoll());
            mainPoll = prevPolls.getMainPoll();
        } else {
            mainPoll.addIgnoredPoll(prevPolls.getMainPoll());
            printLogInfo.accept(this);
        }
        return this;
    }

    private void addAdditionalPolls(AP poll) {
        if (additionalPolls == null)
            additionalPolls = new ArrayList<>();
        additionalPolls.add(poll);
    }

    public AP getMainPoll() {
        return mainPoll;
    }

    public Stream<AP> getPollsStream() {
        if (additionalPolls == null)
            return Stream.of(mainPoll);
        return Stream.concat(Stream.of(mainPoll), additionalPolls.stream());
    }

    public String getGroupCode() {
        return mainPoll.getGroupCode();
    }

}
