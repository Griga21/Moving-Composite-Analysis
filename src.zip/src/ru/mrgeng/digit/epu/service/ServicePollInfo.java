package ru.mrgeng.digit.epu.service;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ServicePollInfo {
    private final Map<Long, List<RealTimePoll>> realTimePollByDeviceId;
    private final Map<Long, List<MissedDataPoll>> missedDataPollByDeviceId;

    private final List<RealTimePoll> defaultRealTimePollPoll;
    private final List<MissedDataPoll> defaultMissedDataPoll;

    private final Consumer<MpService.DeviceConfig> pollInitializer;

    @Deprecated
    final private Map<String, List<MpService.DevicePollDef>> pollDefsByKp;
    @Deprecated
    final private Map<String, List<MpService.DevicePollMissedDataDef>> missedDataPollDefsByKp;

    public ServicePollInfo(Map<Long, List<RealTimePoll>> realTimePollByDeviceId, List<RealTimePoll> defaultRealTimePollPoll,
                           Map<Long, List<MissedDataPoll>> missedDataPollByDeviceId, List<MissedDataPoll> defaultMissedDataPoll) {
        this.pollDefsByKp = null;
        this.missedDataPollDefsByKp = null;
        this.realTimePollByDeviceId = realTimePollByDeviceId;
        this.missedDataPollByDeviceId = missedDataPollByDeviceId;
        this.defaultRealTimePollPoll = defaultRealTimePollPoll;
        this.defaultMissedDataPoll = defaultMissedDataPoll;
        //Если потребуются доп. условия по фильтрации MpService.DeviceConfig, для которых не следует создавать расписание опроса, то указывать здесь
        this.pollInitializer = (dc) -> {
            if (dc.interrogation && dc.driverDataModel != null) {
                dc.missedDataPolls = getMissedDataPolls(dc.internalId);
                dc.realTimePolls = getRealTimePolls(dc.internalId);
            }
        };
    }

    public void initDeviceConfigPoll(MpService.DeviceConfig deviceConfig) {
        pollInitializer.accept(deviceConfig);
    }

    @Deprecated
    public ServicePollInfo(Map<String, List<MpService.DevicePollDef>> pollDefsByKp, Map<String, List<MpService.DevicePollMissedDataDef>> missedDataPollDefsByKp) {
        this.pollDefsByKp = pollDefsByKp;
        this.missedDataPollDefsByKp = missedDataPollDefsByKp;
        this.realTimePollByDeviceId = null;
        this.missedDataPollByDeviceId = null;
        this.defaultRealTimePollPoll = null;
        this.defaultMissedDataPoll = null;
        this.pollInitializer = (dc) -> {
            dc.devPollDefs = getPollDefsByKp(dc.code);
            dc.devPollMissedDataDefs = getMissedDataPollDefsByKp(dc.code);
        };
    }

    public List<RealTimePoll> getRealTimePolls(Long deviceId) {
        return realTimePollByDeviceId.getOrDefault(deviceId, defaultRealTimePollPoll);
    }

    public List<MissedDataPoll> getMissedDataPolls(Long deviceId) {
        return missedDataPollByDeviceId.getOrDefault(deviceId, defaultMissedDataPoll);
    }


    @Deprecated
    private List<MpService.DevicePollDef> getPollDefsByKp(String code) {
        return pollDefsByKp.get(code);
    }

    @Deprecated
    private List<MpService.DevicePollMissedDataDef> getMissedDataPollDefsByKp(String code) {
        return missedDataPollDefsByKp.get(code);
    }
}
