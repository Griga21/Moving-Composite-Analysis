package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.DeviceDataInfo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Сервис для публикации данных по смарт счетчикам в учетные системы (АИС-РНГ, ПРиВА)
 */
public interface SmartMeterService {
    String NAME = "pros_SmartMeterService";

    // Св-во со списком сервисов
    String SMART_SERVICE_KEY = "mp.smartServices";

    // Название параметра с накопительным объемом
    String SMART_VOLUME_PARAM = DeviceDataInfo.DEV_COMMON_SUM_V;

    // Название группы параметров суточных данных по умным счетчикам
    String SMART_DEV_DAY_DATA_GROUP = DeviceDataInfo.METER_DAY_DATA_GROUP;

    String SMART_DEV_LOG_DATA_GROUP = DeviceDataInfo.CORR_GA_GROUP;

    String SMART_DEV_LOG_MSG = DeviceDataInfo.CORR_GA_MSG;

    /**
     * Описание счетчика
     */
    class Meter implements Serializable {
        private static final long serialVersionUID = 1L;

        // id в БД (может быть UUID, код, уникальный id устройства)
        public String dbId;
        // Название
        public String name;
        // Тип
        public String type;
        // Заводской/CСерийный номер
        public String serialNumber;

        @Override
        public String toString() {
            return StrUtils.toStr(getClass().getSimpleName(), "dbId", dbId, "name", name, "type", type, "serialNumber", serialNumber);
        }
    }

    /**
     * Сообщение по счетчику (статусы, аварии)
     */
    class MeterEventLog implements Serializable {
        private static final long serialVersionUID = 1L;

        public MeterEventLog() {
        }

        public MeterEventLog(Date pt, String msg) {
            this.pt = pt;
            this.msg = msg;
        }

        // Время
        public Date pt;

        // Сообщение
        public String msg;

        @Override
        public String toString() {
            return StrUtils.toStr(getClass().getSimpleName(),  "pt", pt,  "msg", msg);
        }
    }

    /**
     * Данные по счетчику
     */
    class MeterData implements Serializable {
        private static final long serialVersionUID = 1L;

        // id s БД
        public String dbId;
        // Время данных
        public Date pt;
        // Время получения
        public Date ot;
        // Объем
        public Double vs;

        // События/Сообщения
        public List<MeterEventLog> events;

        @Override
        public String toString() {
            return StrUtils.toStr(getClass().getSimpleName(), "dbId", dbId, "pt", pt, "ot", ot, "vs", vs, "events", events);
        }
    }

    /**
     * Запрос данных
     */
    class DataRequest implements Serializable {
        private static final long serialVersionUID = 1L;
        // id запроса
        public String requestId;
        // c
        public Date from;
        // по
        public Date to;
        @Override
        public String toString() {
            return StrUtils.toStr(getClass().getSimpleName(), "requestId", requestId, "from", from, "to", to);
        }
    }


    /**
     * @return Полный список смарт-счетчиков
     */
    List<Meter> allGasMeters();

    /**
     * Запрос данных за период
     *
     * @param request Параметры запроса
     * @param meterDbIds Идентификаторы измерителей. Если не указаны, то запрос по всем.
     * @return Данные по счетчикам
     */
    List<MeterData> getData(DataRequest request, List<String> meterDbIds);

    /**
     * Запрос последних данных за период
     *
     * @param request Параметры запроса
     * @param meterDbIds Идентификаторы счетчиков. Если не указаны, то запрос по всем.
     * @return Последние данные по счетчикам
     */
    List<MeterData> getLastData(DataRequest request, List<String> meterDbIds);

    void init();
}