package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.DataPeriodicity;
import ru.mrgeng.digit.epu.mp.Device;

import java.util.List;
import java.util.Map;

/**
 * Сервис генерации имени файла для отчетов за период времени
 */

public interface ReportNamingService {
    String NAME = "dgepu_ReportNamingService";

    /**
     * Возвращает singletonList с мапой "name" : "ПЕРИОД_отчет_МОДЕЛЬ_КОД_ДАТА"
     * Например: Посуточный_отчет_ЕК270_ul133_2026-06-19-09-09-19
     * Разрешенные символы: [^a-zA-Zа-яА-Я0-9._-], остальные заменяются на _
     *
     * @param device          устройство, по которому запрашивается отчет
     * @param dataPeriodicity енам, определяющий периодичность. Возможны значения HOUR, DAY
     * @return
     */
    List<Map<String, String>> getFileName(Device device, DataPeriodicity dataPeriodicity);

}