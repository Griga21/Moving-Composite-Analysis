package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.RequestPeriod;

public class RealTimeJobParams extends JobParams {
    final private RequestPeriod requestPeriod;

    public RealTimeJobParams(String serviceCode, String deviceCode, String groupCode, RequestPeriod requestPeriod, boolean withCommHour) {
        super(serviceCode, deviceCode, groupCode, withCommHour);
        this.requestPeriod = requestPeriod;
    }

    public RequestPeriod getRequestPeriod() {
        return requestPeriod;
    }

    @Override
    public String toString() {
        return StrUtils.toStr("RealTimeJobParams", "serviceCode", getServiceCode(),
                "deviceCode", getDeviceCode(), "groupCode", getGroupCode(),
                "requestPeriod", getRequestPeriod());
    }
}