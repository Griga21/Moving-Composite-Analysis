package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.HandleStat;
import ru.mrgeng.digit.dgcore.service.ObjParams;
import ru.mrgeng.digit.dgcore.service.ParamInfo;
import ru.mrgeng.digit.dgcore.service.Request;

import java.util.List;

/**
 * Обработчик приведенных данных определенной группы, позволяющий формировать расчеты
 */
public interface ICalcJob {

    /**
     * @param req запрос, в рамках которого производится расчет (поступление данных, пересчет)
     * @param ctx контекст сервиса
     * @param stat общая статистика
     * @param paramInfo группа
     * @param inParams параметры
     * @return результаты расчета, null - если нет
     */
    CalcJobDataHolder calcData(Request req, MpService.ServiceCtx ctx, HandleStat stat, ParamInfo paramInfo, List<ObjParams> inParams);

}
