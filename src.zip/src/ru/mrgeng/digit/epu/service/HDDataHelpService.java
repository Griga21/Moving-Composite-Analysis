package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.dgcore.service.ParamData;
import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.mp.DeviceMeasPoint;
import ru.mrgeng.digit.epu.mp.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface HDDataHelpService {
    String NAME = "pros_HDDataHelpService";

    void init();

    List<Param> getHourParams(Device device);

    Map<Date, ParamData> getHourData(Device device, DeviceMeasPoint point, Set<String> params, Date from, Date to) throws Exception;

    List<Param> getDayParams(Device device);

    Map<Date, ParamData> getDayData(Device device, DeviceMeasPoint point, Set<String> params, Date from, Date to) throws Exception;
}