package ru.mrgeng.digit.epu.service;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UpdateConfigInfo implements Serializable {
    final List<String> lastObjId;

    private UpdateConfigInfo(List<String> actualObjId) {
        this.lastObjId = actualObjId;
    }

    public static UpdateConfigInfo of(List<MpService.DeviceConfig> configs) {
        List<String> oids = new ArrayList<>();
        for (MpService.DeviceConfig config : configs) {
            config.fillActualOid(oids);
        }
        return new UpdateConfigInfo(oids);
    }

    public boolean isSame(List<MpService.DeviceConfig> otherConfigs) {
        ArrayList<String> otherOids = new ArrayList<>();
        for (MpService.DeviceConfig config : otherConfigs) {
            config.fillActualOid(otherOids);
        }
        if (lastObjId.size() != otherOids.size())
            return false;
        return otherOids.containsAll(lastObjId);
    }

}