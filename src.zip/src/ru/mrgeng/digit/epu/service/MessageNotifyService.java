package ru.mrgeng.digit.epu.service;

public interface MessageNotifyService {
    String NAME = "pros_MessageNotifyService";

    void notifyMessage(String message, String type);
}