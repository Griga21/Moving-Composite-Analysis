package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.Device;

import java.util.List;


public interface CalculatePriorityTreeService {
    String NAME = "dgepu_CalculatePriorityTreeService";

    Integer getPriorityFromTree(Device device, boolean statusLogger);

    Integer getPriorityFromTree(List<Device> devices, boolean statusLogger);
}