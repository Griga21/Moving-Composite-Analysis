package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.Device;

import java.util.List;

public interface SendCommandService {
    String NAME = "dgepu_SendCommandService";

    void sendCommand(Device device, List<MpService.CmdParams> params) throws Exception;
}