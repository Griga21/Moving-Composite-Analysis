package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.epu.mp.TechSupport;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface DeviceReportService {
    String NAME = "pros_DeviceReportService";

    List<Map<String, String>> getHeaderData(Date from, Date to);
    List<Map<String, Object>> getDeviceData(Date from, Date to, TechSupport techSupport, String measPoint);
}