package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.DeviceStatus;

import java.util.List;
import java.util.Map;

public interface ReportCurrentlyInactiveObjectsService {
    String NAME = "dgepu_ReportCurrentlyInactiveObjectsService";

    List<Map<String, String>> getDeviceParamRaw();
}