package ru.mrgeng.digit.epu.service;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public abstract class IgnoredPoll implements PollPriorityInfo, Serializable {
    private final Long pollId;//id расписания
    private Set<Long> ignoredPoolingIds;//id игнорируемых, но подходящих по критериям расписаний

    public IgnoredPoll(Long pollId) {
        this.pollId = pollId;
    }

    public void addIgnoredPoll(IgnoredPoll poll) {
        initIgnore();
        ignoredPoolingIds.add(poll.getId());
        if (poll.getIgnoredPollIds() != null)
            ignoredPoolingIds.addAll(poll.getIgnoredPollIds());
    }

    private void initIgnore() {
        if (ignoredPoolingIds == null)
            ignoredPoolingIds = new HashSet<>();
    }

    @Override
    public Set<Long> getIgnoredPollIds() {
        return ignoredPoolingIds;
    }

    @Override
    public Long getId() {
        return pollId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        IgnoredPoll that = (IgnoredPoll) o;
        return pollId.equals(that.pollId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pollId);
    }
}
