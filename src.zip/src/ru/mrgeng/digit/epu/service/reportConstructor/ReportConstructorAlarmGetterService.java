package ru.mrgeng.digit.epu.service.reportConstructor;

import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.mp.DeviceMeasPoint;
import ru.mrgeng.digit.epu.mp.DeviceType;
import ru.mrgeng.digit.epu.mp.MeasPoint;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Сервис для страницы алармов в отчетах, вызываемых из ObjReportCustomPeriod
 */

public interface ReportConstructorAlarmGetterService {
    String NAME = "dgepu_ReportConstructorAlarmGetterService";

    /**
     * Находит точку измерения по устройству и опциональной точке измерения устройства
     *
     * @param d устройство
     * @param p точка измерения устройства
     * @return найденная точка измерения или null
     */
    MeasPoint findMeasPointByDeviceAndPoint(Device d, DeviceMeasPoint p);

    /**
     * Получает журнальные данные для одной точки измерения
     *
     * @param deviceType тип устройства
     * @param measPoint  точка измерения
     * @param from       начальная дата
     * @param to         конечная дата
     * @return список карт с полями "data" (дата) и "text" (сообщение)
     */
    List<Map<String, Object>> getJournalDataForSingleMeasPoint(
            DeviceType deviceType,
            MeasPoint measPoint,
            Date from,
            Date to
    );
}