package ru.mrgeng.digit.epu.service.reportConstructor;

import com.fasterxml.jackson.core.type.TypeReference;
import ru.mrgeng.digit.epu.dto.ParamUnitSettingDto;

import java.io.Serializable;
import java.util.Map;

public interface SettingsStorageService {
    String NAME = "dgepu_SettingsStorageService";

    /**
     * Загружает Map<String, T> из настроек пользователя по ключу.
     *
     * @param key     ключ настройки (одна из констант KEY_*)
     * @param typeRef тип мапы для десериализации
     */
    <T> Map<String, T> loadMap(String key, TypeReference<Map<String, T>> typeRef);

    /**
     * Сохраняет Map<String, T> в настройки пользователя по ключу.
     */
    <T> void saveMap(String key, Map<String, T> map);

    void deleteMap(String key);

    class StringStringMapRef extends TypeReference<Map<String, String>> implements Serializable {
        public static final StringStringMapRef INSTANCE = new StringStringMapRef();
    }

    class StringParamUnitSettingDtoMapRef extends TypeReference<Map<String, ParamUnitSettingDto>> implements Serializable {
        public static final StringParamUnitSettingDtoMapRef CONV_MAP_TYPE_REF = new StringParamUnitSettingDtoMapRef();
    }
}
