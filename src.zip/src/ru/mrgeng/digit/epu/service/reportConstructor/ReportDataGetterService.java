package ru.mrgeng.digit.epu.service.reportConstructor;

import ru.mrgeng.digit.epu.dto.ParamUnitSettingDto;
import ru.mrgeng.digit.epu.mp.*;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Серивис для получения данных в конструкторе отчетов
 */

public interface ReportDataGetterService {
    String NAME = "dgepu_ReportDataGetterService";

    List<Map<String, List<Map<String, Object>>>> getDeviceParamValueMeasureUnitConvert(@NotNull Device device,
                                                                                       @NotNull DeviceService service,
                                                                                       @NotNull String groupCodeEnd,
                                                                                       DeviceMeasPoint point,
                                                                                       @NotNull Date from,
                                                                                       @NotNull Date to,
                                                                                       @NotNull Map<String, String> nameMap,
                                                                                       @NotNull Set<String> userKeys,
                                                                                       @NotNull Map<String, ParamUnitSettingDto> unitSettingDtoMap);

    List<Map<String, Object>> getJournalDataForSingleMeasPoint(
            DeviceType deviceType,
            MeasPoint measPoint,
            Date from,
            Date to
    );

    MeasPoint f(Device d, DeviceMeasPoint p);

    String getDinComHour(Device device);
}