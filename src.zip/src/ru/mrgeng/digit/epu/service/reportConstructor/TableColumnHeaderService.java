package ru.mrgeng.digit.epu.service.reportConstructor;

import ru.mrgeng.digit.epu.dto.ParamUnitSettingDto;
import ru.mrgeng.digit.epu.mp.Device;

import java.util.Map;

public interface TableColumnHeaderService {
    String NAME = "dgepu_TableHeaderService";

    /**
     * получение оригинального списка заголовков
     * @param device
     * @param groupCodeEnd
     * @param paramNameOnly
     * @return
     */
    Map<String, String> getDinamicFullHeaderParamUnitMap(Device device, String groupCodeEnd, boolean paramNameOnly);

    /**
     * получение списка с конвертированными единицами
     * @param device
     * @param groupCodeEnd
     * @param paramNameOnly
     * @param unitSettingDtoMap
     * @return
     */
    Map<String, String> getDinamicFullHeaderParamUnitMap(Device device, String groupCodeEnd, boolean paramNameOnly, Map<String, ParamUnitSettingDto> unitSettingDtoMap);
}
