package ru.mrgeng.digit.epu.service.reportConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.mrgeng.digit.epu.mp.Device;
import ru.mrgeng.digit.epu.mp.DeviceMeasPoint;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Сервис для страницы вмешательств в отчетах, вызываемых из ObjReportCustomPeriod
 */

public interface ReportConstructorInterventionsGetterService {
    String NAME = "epu_ReportConstructorInterventionsGetterService";

    Logger log = LoggerFactory.getLogger(ReportConstructorInterventionsGetterService.class);

    List<Map<String, Object>> getInterventions(Date from, Date to, Device device, DeviceMeasPoint point);
}