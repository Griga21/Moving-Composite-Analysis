package ru.mrgeng.digit.epu.service.reportConstructor;

import ru.mrgeng.digit.epu.dto.ParamUnitSettingDto;
import ru.mrgeng.digit.epu.mp.*;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Сервис для отчетов, вызываемых из ObjReportCustomPeriod
 */

public interface ReportConstructorDataGetterService {
    String NAME = "dgepu_ReportDataGetterService";

    /**
     * Формирует отчет по параметрам устройства с конвертацией единиц измерения.
     *
     * @param device            Устройство
     * @param groupCodeEnd      Окончание кода группы параметров
     * @param point             Точка измерения
     * @param from              Начало периода
     * @param to                Конец периода
     * @param nameMap           Карта соответствия ключей и имен
     * @param userKeys          Набор ключей пользователей
     * @param unitSettingDtoMap Настройки единиц измерения
     * @return Список с одной картой, содержащей секции отчета:
     * SECTION_HEAD, SECTION_MASTER, SECTION_CROSS, SECTION_TOTAL, SECTION_LAST_DATE
     */
    List<Map<String, List<Map<String, Object>>>> getDeviceParamValueMeasureUnitConvert(@NotNull Device device,
                                                                                       @NotNull String groupCodeEnd,
                                                                                       DeviceMeasPoint point,
                                                                                       @NotNull Date from,
                                                                                       @NotNull Date to,
                                                                                       @NotNull Map<String, String> nameMap,
                                                                                       @NotNull Set<String> userKeys,
                                                                                       @NotNull Map<String, ParamUnitSettingDto> unitSettingDtoMap);

    List<Map<String, Object>> getDeviceLastKeyValueParam(Device device, DeviceMeasPoint point, String groupCode, Date from, Date to);

    /**
     * Получение коммерческого часа из касандры и из динамического параметра.
     *
     * @param device
     * @param point
     * @return Дто со строками часов, либо "Не задано"
     */
    CommHourDto getComHour(Device device, DeviceMeasPoint point, String groupCodeEnd);

    class CommHourDto {
        private String attributeCommHour;
        private String deviceDataCommHour;

        public String getAttributeCommHour() {
            return attributeCommHour;
        }

        public void setAttributeCommHour(String attributeCommHour) {
            this.attributeCommHour = attributeCommHour;
        }

        public String getDeviceDataCommHour() {
            return deviceDataCommHour;
        }

        public void setDeviceDataCommHour(String deviceDataCommHour) {
            this.deviceDataCommHour = deviceDataCommHour;
        }

        @Override
        public String toString() {
            return "Начало дня приборное: '" + attributeCommHour + '\'' +
                    ", Начало дня программное: '" + deviceDataCommHour;
        }
    }
}