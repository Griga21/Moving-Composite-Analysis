package ru.mrgeng.digit.epu.service;

public abstract class JobParams {
    private final String serviceCode;
    private final String deviceCode;
    private final String groupCode;
    private final boolean withCommHour;

    public JobParams(String serviceCode, String deviceCode, String groupCode, boolean withCommHour) {
        this.deviceCode = deviceCode;
        this.serviceCode = serviceCode;
        this.groupCode = groupCode;
        this.withCommHour = withCommHour;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public boolean isWithCommHour() {
        return withCommHour;
    }
}