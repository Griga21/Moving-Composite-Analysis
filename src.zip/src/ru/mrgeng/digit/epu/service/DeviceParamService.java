package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.DeviceEventType;
import ru.mrgeng.digit.epu.mp.MpObj;
import ru.mrgeng.digit.epu.param.Param;
import ru.mrgeng.digit.epu.param.SeriousLevel;


import java.io.Serializable;
import java.util.*;

/**
 * Сервис для доступа к параметрам по типу устройства
 **/
public interface DeviceParamService {
    String NAME = "pros_DeviceParamUtilsService";

    String NO_MEAS_POINT = "NO_MEAS_POINT";

    static String deviceWithMeasPoint(String devCode, String measPoint) {
        if (measPoint == null || measPoint.equals(NO_MEAS_POINT))
            return devCode;
        else
            return devCode + '.' + measPoint;
    }

    CodeNameObj NO_MEAS_POINT_OBJ = new CodeNameObj(NO_MEAS_POINT, "Без места измерения");

    /**
     * Описание параметров
     */
    class ParamsInfo<P extends Param> implements Serializable {
        private static final long serialVersionUID = 1L;

        public Map<Long, P> params;

        public Map<String, CodeNameObj> groups;

        public Map<CodeNameObj, Map<String, P>> groupParams;

        public Map<String, Map<String, P>> strGroupParams;

        public Set<P> getAll() {
            Set<P> result = new HashSet<>();
            for (Map<String, P> map : strGroupParams.values()) {
                result.addAll(map.values());
            }
            return result;
        }

        public P getStrParamInfo(String group, String param) {
            if (strGroupParams == null || strGroupParams.isEmpty())
                return null;
            Map<String, P> pMap = strGroupParams.get(group);
            if (pMap != null)
                return pMap.get(param);
            return null;
        }

        public Map<String, P> getParamsInfo(String group) {
            if (groups == null)
                return null;
            CodeNameObj codeNameObj = groups.get(group);
            if (codeNameObj == null)
                return null;
            return groupParams.get(codeNameObj);
        }

        public P getParamInfo(String group, String param) {
            Map<String, P> map = getParamsInfo(group);
            if (map == null)
                return null;
            return map.get(param);
        }


        @Override
        public String toString() {
            return "ParamsInfo{" +
                    "groupParams=" + groupParams +
                    '}';
        }
    }


    class ThresholdViolInfo implements Serializable {
        public DeviceEventType type;
        public String dataInfo;
        public String info;

        public ThresholdViolInfo() {
        }

        public ThresholdViolInfo(DeviceEventType type, String dataInfo, String info) {
            this.type = type;
            this.dataInfo = dataInfo;
            this.info = info;
        }
    }

    /**
     * Информация о допустимых порогах параметра
     */
    class ParamsThresholdInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        /**
         * нижний порог предупреждение
         **/
        public Double low1;
        /**
         * нижний порог тревога
         **/
        public Double low2;
        /**
         * верхний порог предупреждение
         **/
        public Double high1;
        /**
         * верхний порог тревога
         **/
        public Double high2;

        @Override
        public String toString() {
            return StrUtils.toStr(getClass().getSimpleName(), "low1", low1, "low2", low2, "high1", high1, "high2", high2);
        }

        /**
         * @param value значение
         * @return результат NO_OVER, LOW_1...
         */
        public ThresholdViolInfo check(Param param, double value) {
            if (low2 != null && value < low2)
                return new ThresholdViolInfo(DeviceEventType.DOWN_2, param.groupAndParam() + '<' + low2, "значение " + param.toStr(value) + " меньше аварийного порога " + low2);
            if (low1 != null && value < low1)
                return new ThresholdViolInfo(DeviceEventType.DOWN_1, param.groupAndParam() + '<' + low1, "значение " + param.toStr(value) + " меньше предупредительного порога " + low1);
            if (high2 != null && value > high2)
                return new ThresholdViolInfo(DeviceEventType.UP_2, param.groupAndParam() + '>' + high2, "значение " + param.toStr(value) + " выше аварийного порога " + high2);
            if (high1 != null && value > high1)
                return new ThresholdViolInfo(DeviceEventType.UP_1, param.groupAndParam() + '>' + high1, "значение " + param.toStr(value) + " выше предупредительного порога " + high1);
            return null;
        }

        public SeriousLevel checkLevel(double value) {
            if (low2 != null && value < low2)
                return SeriousLevel.ALARM;
            if (low1 != null && value < low1)
                return SeriousLevel.WARN;
            if (high2 != null && value > high2)
                return SeriousLevel.ALARM;
            if (high1 != null && value > high1)
                return SeriousLevel.WARN;
            return null;
        }
    }

    /**
     * Вернуть места измерений по типу устройств
     *
     * @param deviceTypeCode код типа
     * @return Список мест измерений без дуплликатов по code
     */
    List<CodeNameObj> getMeasPoints(String deviceTypeCode);
    
    /**
     * Вернуть места измерений по модели устройств
     *
     * @param deviceModelId id модели устройства
     * @return Список мест измерений без дубликатов по code
     */
    List<CodeNameObj> getMeasPointsByDeviceModelId(Long deviceModelId);

    /**
     * @param deviceModelIds id моделей устройств
     * @return отображение (id модели устройства -> список кодов устройств (уникальных в рамках одного id модели))
     */
    Map<Long, Set<String>> getMeasPointsByDeviceModelIds(List<Long> deviceModelIds);
    
    Map<Long, Set<String>> getAllMeasPointsByModelId();

    Map<String, Set<String>> getAllParamGroupCodeByDeviceTypeCode();

    List<Object[]> getDeviceModelTypesParamForDDK(String serviceCode, Set<String> deviceCodeSet);

    ServiceDataChanges CALC_PARAMS_CHANGES = new ServiceDataChanges(NAME, "getCalcParamsByDevType", Arrays.asList("Param", "ParamGroup"));

    /**
     * Вернуть описание вычисляемых параметров по типу устройств
     *
     * @param deviceTypeCode код типа
     * @return описание
     */
    ParamsInfo<Param> getCalcParamsByDevType(String deviceTypeCode);
    
    /**
     * Вернуть описание вычисляемых параметров по типам устройств
     *
     * @param deviceTypeCodes коды типов
     * @return описание
     */
    Map<String, DeviceParamService.ParamsInfo<ru.mrgeng.digit.epu.param.Param>> getCalcParamsByDevTypes(Set<String> deviceTypeCodes);

    ServiceDataChanges THRESHOLDS_CHANGES = new ServiceDataChanges(NAME, "getCalcParamsThresholds", Collections.singletonList("DeviceMpThreshold"));

    /**
     * Вернуть информацию о допустимых порогах приведенных параметров по устройствам сервиса
     *
     * @param serviceCode код сервиса
     * @return id устройства -> код места измерения -> id параметра -> информация о порогах
     */
    Map<Long, Map<String, Map<Long, ParamsThresholdInfo>>> getCalcParamsThresholds(String serviceCode);

    /**
     * Вернуть информацию о допустимых порогах приведенных параметров по устройствам сервиса
     *
     * @param serviceCode код сервиса
     * @return код устройства точка код места измерения точка группа точка код параметра -> информация о порогах
     */
    Map<String, ParamsThresholdInfo> getCalcParamsThresholdsByCodes(String serviceCode);

    Map<String, Map<String, Map<String, Date>>> getParamsIgnoresByCodes(String serviceCode);

    ServiceDataChanges DEVICE_TYPE_CHANGES = new ServiceDataChanges(NAME, "getServiceDeviceTypes", Arrays.asList("Device", "DeviceModel"));

    /**
     * @param serviceIds id сервисов
     * @return типы устройств, опрашиваемые этими сервисами
     */
    Map<Long, Set<Long>> getServiceDeviceTypes(List<Long> serviceIds);

    /**
     * Поиск объекта по коду
     *
     * @param entityName название сущности типа MpObj
     * @param code       код
     * @return первый объект по коду
     */
    <T extends MpObj> T findByCodes(String entityName, String code);

    /**
     * Поиск объектов по кодам
     *
     * @param entityName название сущности типа MpObj
     * @param code       код
     * @return первый объект по коду
     */
    <T extends MpObj> List<T> findByCodes(String entityName, List<String> code);

    Map<Long, Param> loadCalcParamMap();

    Map<String, String> loadParamAbbrMap();

    Map<String, Map<String,String>> loadAbbrMap();
}