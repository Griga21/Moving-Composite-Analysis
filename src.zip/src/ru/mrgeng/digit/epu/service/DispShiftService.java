package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.entity.Department;
import ru.mrgeng.digit.dgcore.entity.SysUser;
import ru.mrgeng.digit.epu.mp.DeviceEvent;
import ru.mrgeng.digit.epu.mp.DispShift;

import java.time.LocalDateTime;
import java.util.List;

public interface DispShiftService {
    String NAME = "pros_DispShiftService";

    String ADMIN_ROLE_NAME = "disp-admin-role";

    SysUser getCurrentDispatcher(Department department);

    SysUser getDispatcherOnDate(LocalDateTime onDate, Department department);

    DispShift getShift(LocalDateTime onDate, Department department);

    void setDispatcher(SysUser dispatcher, Department department);

    void setCurrentDispatcher(String comment);

    List<DeviceEvent> getDeviceEvents(Boolean unAckDeviceEvent, LocalDateTime from);

    boolean currentUserIsDispatcher();

    /**
     * Проверяет, что сессия диспетчера активена, если нет, создает письмо ответственным.
     */
    void warnShiftResponsible();

    List<SysUser> getDeptResponsibleUsers(Department department);
}