package ru.mrgeng.digit.epu.service.checker;

import com.haulmont.cuba.core.entity.Entity;


import java.util.List;

/**
 * Исследователь ассоциаций ManyToOne и связанных объектов для переданного экземпляра сущности
 */
public interface RelationCheckerService {
    String NAME = "pros_RelationCheckerService";

    /**
     * Возвращает отношения с другими сущностями для переданного экземпляра
     * В случае findAll = true вернет полный список отношений и количество связанных объектов
     * В случае findAll = false вернет первое отношение с ненулевым количеством связанных объектов или пустой список.
     *
     * @param entity экземпляр сущности
     * @param skipCascadeDelete true - не выводить связи, которые должны каскадно удаляться
     *                          (помеченные как @OnDeleteInverse(value = DeletePolicy.CASCADE))
     * @param findAll true - для поиска всех отношений, false для поиска первого отношения со связанными объектами
     *
     * @return Список отношений с указанием класса и количества объектов
     */
    <T extends Entity<K>, K> List<Relation> getRelations(T entity, boolean skipCascadeDelete, boolean findAll);
}
