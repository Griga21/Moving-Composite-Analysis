package ru.mrgeng.digit.epu.service.checker;

import java.io.Serializable;

public class Relation implements Serializable {
    private final Class<?> type;
    private final String name;
    private final Long count;

    public Relation(Class<?> type, String name, Long count) {
        this.type = type;
        this.name = name;
        this.count = count;
    }

    public Class<?> getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public Long getCount() {
        return count;
    }

    @Override
    public String toString() {
        return "Relation{" +
                "type=" + (type != null ? type.getCanonicalName(): null) +
                ", name='" + name + '\'' +
                ", count=" + count +
                '}';
    }
}
