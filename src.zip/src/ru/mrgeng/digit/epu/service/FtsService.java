package ru.mrgeng.digit.epu.service;

/**
 * Работа с CUBA FTS.
 */
public interface FtsService {
    String NAME = "dgepu_FtsService";
    
    /**
     * Выполняет CUBA FTS {@code reindexAll}, затем {@code processEntireQueue}
     * @return результат {@code reindexAll} и {@code processEntireQueue}
     */
    String rebuildAllIndex();
}
