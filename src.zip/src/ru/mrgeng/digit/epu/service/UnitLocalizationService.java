package ru.mrgeng.digit.epu.service;


import java.util.Map;

public interface UnitLocalizationService {
    String NAME = "dgepu_UnitLocalizationService";

    String getUnitName(String unitCode);

    public String getUnitNameWithoutPrefix(String unitCode);

    String getPrefixName(String prefixCode);

    String getPrefixNameWithoutPrefix(String prefixCode);

    Map<String, String> getAllUnitNames();

    Map<String, String> getAllPrefixNames();

    /**
     * @return Возращает карту Единиц Измерения: Key -> Localized Name
     */
    Map<String, String> getLocalizedUnitMap();

    /**
     * @return Возращает карту Префиксов: Key -> Localized Name
     */
    Map<String, String> getLocalizedPrefixMap();
}