package ru.mrgeng.digit.epu.service;


import com.haulmont.chile.core.model.MetaClass;

import java.util.List;

public interface DynamicAttributesService {
    String NAME = "pros_DynamicAttributesService";


    List<String> getMissingCodes(Class clazz, String category, List<String> attr);

    List<String> getMissingCodes(Class clazz, List<String> attr);

}