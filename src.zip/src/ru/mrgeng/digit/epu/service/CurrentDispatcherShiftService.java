package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.DispShift;

import java.util.List;

public interface CurrentDispatcherShiftService {
    String NAME = "dgepu_CurrentDispatcherShiftService";


List<DispShift> currentDispShift();
}