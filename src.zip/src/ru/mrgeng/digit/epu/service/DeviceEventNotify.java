package ru.mrgeng.digit.epu.service;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import com.haulmont.addon.globalevents.GlobalUiEvent;
import ru.mrgeng.digit.epu.mp.DeviceEventType;

public class DeviceEventNotify extends GlobalApplicationEvent implements GlobalUiEvent {

    private Long devId;
    private Long eventId;
    private DeviceEventType eventType;

    private boolean show = true;

    public DeviceEventNotify(Object source, DeviceEventType eventType, Long devId) {
        super(source);
        this.eventType = eventType;
        this.devId = devId;
    }

    public DeviceEventNotify(Object source, DeviceEventType eventType, Long devId, boolean show, Long eventId) {
        this(source, eventType, devId);
        this.show = show;
        this.eventId = eventId;
    }

    public DeviceEventType getEventType() {
        return eventType;
    }

    public void setEventType(DeviceEventType eventType) {
        this.eventType = eventType;
    }

    public Long getDevId() {
        return devId;
    }

    public boolean isShow() {
        return show;
    }

    public Long getEventId() {
        return eventId;
    }
}
