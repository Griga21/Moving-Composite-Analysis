package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.epu.mp.*;

import java.io.Serializable;
import java.util.*;

public class MeasPointActualizationResult implements Serializable {
    private static final long serialVersionUID = 1L;

    public MeasPointActualizationResult() {
    }

    public MeasPointActualizationResult(DeviceService service, String errorMessage) {
        this.errorMessage = errorMessage;
        errors.put(service, errorMessage);
    }

    public String errorMessage = null;
    private final Map<ActualizationMark, Integer> updateLineStatistic = new HashMap<>();
    private final Map<DeviceActualizationOption, Integer> deviceBasedStatistic = new HashMap<>();
    private final Map<DeviceService, String> errors = new HashMap<>();
    private final Set<MeasPoint> update = new HashSet<>();

    private int ignoreByHardStatus = 0;
    private int updateCounter = 0;

    public void deviceStatistic(Device device, DeviceActualizationOption option) {
        deviceBasedStatistic.compute(option, (k, v) -> v == null ? 1 : ++v);
    }

    public void deviceStatisticAddTotal(List<Device> devices) {
        deviceBasedStatistic.compute(DeviceActualizationOption.TOTAL, (k, v) -> v == null ? devices.size() : v + devices.size());
    }

    public void add(MeasPoint measPoint, boolean isNew) {
        if (update.contains(measPoint))
            return;
        update.add(measPoint);
        updateCounter++;
        updateLineStatistic.compute(measPoint.getActualizationMark(), (k, v) -> v == null ? 1 : ++v);
    }

    public void mergeStatistic(DeviceService service, MeasPointActualizationResult other) {
        other.updateLineStatistic.forEach((k, v) -> this.updateLineStatistic.merge(k, v, Integer::sum));
        other.deviceBasedStatistic.forEach((k, v) -> this.deviceBasedStatistic.merge(k, v, Integer::sum));
        ignoreByHardStatus += other.ignoreByHardStatus;
        updateCounter += other.update.size();
        errors.put(service, other.errorMessage);
    }

    public int getCount(ActualizationMark mark) {
        return updateLineStatistic.getOrDefault(mark, 0);
    }

    public Set<MeasPoint> getUpdateSet() {
        return update;
    }

    public void ignoreHardStatus() {
        ignoreByHardStatus++;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public int getIgnoreCount() {
        return ignoreByHardStatus;
    }

    public String toString() {
        return "Создано/обновлено линий: " + updateCounter +
                (ignoreByHardStatus == 0 ? "" : ("\nПроигнорировано линий по статусу: " + ignoreByHardStatus)) +
                (updateLineStatistic.isEmpty() ? "" : ("\nCтатистика обновления линий:\n" + statisticToString(updateLineStatistic))) +
                (errors.isEmpty() ? "" : ("\nОшибки по сервисам:\n" + statisticToString(errors))) +
                (deviceBasedStatistic.isEmpty() ? "" : ("\nУстройства :\n" + statisticToString(deviceBasedStatistic)))
                ;
    }

    private String statisticToString(Map<? extends Object, ? extends Object> map) {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<? extends Object, ? extends Object> e : map.entrySet()) {
            if (e.getValue() == null)
                continue;
            if (builder.length() > 0)
                builder.append("\n");
            builder.append(getName(e.getKey()))
                    .append(": ")
                    .append(e.getValue())
                    .append(";");
        }
        return builder.toString();
    }

    private String getName(Object obj) {
        if (obj instanceof SecondName) {
            return ((SecondName) obj).getSecondName();
        }
        return obj.toString();
    }
}
