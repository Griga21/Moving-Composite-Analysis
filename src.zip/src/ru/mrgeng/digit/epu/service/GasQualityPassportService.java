package ru.mrgeng.digit.epu.service;

import com.haulmont.cuba.core.entity.KeyValueEntity;
import ru.mrgeng.digit.epu.mp.*;
import ru.mrgeng.digit.epu.pros.bz.Grs;
import ru.mrgeng.digit.epu.transform.TransParamDef;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public interface GasQualityPassportService {

    String NAME = "dgepu_GasQualityPassportService";

    String SET = ".set";

    String PASSWORD_KEY = "password";
    String DEVICE_KEY = "device";
    String PARAM_KEY = "param";

    List<Device> getDeviceListByGrs(Set<Grs> grsSet);

    Map<TransParamDef, MpService. ParamDef> getParamsByDevice(Device device);

    boolean sendParamsToDevices(GasQualityPassport passport, Set<KeyValueEntity> keyValueEntitySet);

    List<Grs> getGrsByPassport(GasQualityPassport passport);

    GasQualityPassportAttribute getPassportAttributeByParamId(GasQualityPassport gasQualityPassport, Long paramId);

    List<GasQualityPassportAttribute> getListAttributesByPassport(GasQualityPassport gasQualityPassport);

    Param getParamById(Long id);

    Optional<GasQualityProtocol> getProtocolByRequestId(String requestId);

    void updateProtocolStatus();

    Map<DeviceParam, Device> getMapPasswordRequiredParams(GasQualityPassport passport);

    DeviceParam getDeviceParamIfPasswordRequired(DeviceProtoModel deviceProtoModel);

    GasQualityPassport getPassportByProtocol(GasQualityProtocol protocol);

    boolean sendParamsToDevice(GasQualityPassport passport, Set<KeyValueEntity> keyValueEntitySet, Device device, GasQualityProtocol protocol);
}
