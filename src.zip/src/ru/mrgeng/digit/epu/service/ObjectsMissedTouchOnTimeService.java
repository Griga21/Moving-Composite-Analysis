package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.Device;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ObjectsMissedTouchOnTimeService {
    String NAME = "dgepu_ObjectsMissedTouchOnTimeService";

    List<Map<String, String>> getDataMissedTouchOnTime(List<Device> deviceList, Date dateFrom, Double lagTime);
}