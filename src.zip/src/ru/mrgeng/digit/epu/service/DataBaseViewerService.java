package ru.mrgeng.digit.epu.service;

public interface DataBaseViewerService {
    String NAME = "dgepu_DataBaseViewerService";
}