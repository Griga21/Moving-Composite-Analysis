package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.epu.mp.tree.TreeGroup;

import java.util.List;
import java.util.UUID;

public interface TreeGroupService {
    String NAME = "pros_TreeGroupService";
    List<TreeGroup> getHierarchyTreeById(UUID id);
}