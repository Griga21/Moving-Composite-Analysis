package ru.mrgeng.digit.epu.service;

/**
 * Ошибка вызова сервиса
 */
public class ServiceInvokeException extends RuntimeException {

    public ServiceInvokeException() {
    }

    public ServiceInvokeException(String message) {
        super(message);
    }

    public ServiceInvokeException(String message, Throwable cause) {
        super(message, cause);
    }
}
