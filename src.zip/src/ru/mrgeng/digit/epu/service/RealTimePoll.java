package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.DevicePolling;
import ru.mrgeng.digit.epu.mp.RequestPeriod;

public class RealTimePoll extends AbstractPoll {
    private final RequestPeriod requestPeriod;

    public RealTimePoll(DevicePolling polling) {
        super(polling.getId(),
                polling.getCron(),
                polling.getParamGroup().getCode(),
                polling.isAdditional(),
                polling.isWithCommHour());
        this.requestPeriod = polling.getRequestPeriod();
    }

    private RealTimePoll(RealTimePoll poll) {
        super(poll.getId(),
                poll.getCron(),
                poll.getGroupCode(),
                poll.isAdditional(),
                poll.isWithCommHour());
        this.requestPeriod = poll.getRequestPeriod();
        this.addIgnoredPoll(poll);
    }

    public RequestPeriod getRequestPeriod() {
        return requestPeriod;
    }

    @Override
    public RealTimePoll copy() {
        return new RealTimePoll(this);
    }

    @Override
    public RealTimeJobParams getJobParams(String serviceCode, String deviceCode) {
        return new RealTimeJobParams(serviceCode, deviceCode, groupCode, requestPeriod, withCommHour);
    }

    @Override
    public String toString() {
        return StrUtils.toStr(
                "RealTimeDevicePoll",
                "groupCode", groupCode,
                "cron", cron,
                "requestPeriod", requestPeriod,
                "additional", additional,
                "withCommHour", withCommHour);
    }
}