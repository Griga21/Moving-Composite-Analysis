package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.epu.mp.tree.TreeGroup;
import ru.mrgeng.digit.epu.mp.tree.TreeItem;
import ru.mrgeng.digit.epu.mp.tree.TreeObj;

import java.util.List;
import java.util.UUID;

/**
 * Сервис дерева объектов
 **/

public interface TreeService {
    String NAME = "pros_TreeService";

    String treeItemIdCode = "treeItemId";

    /**
     * Обновить данные группы
     *
     * @param group модель TreeGroup
     */
    void update(TreeGroup group);

    /**
     * Удалить объект дерева
     *
     * @param item модель TreeItem
     */
    void remove(TreeItem item);

    /**
     * Список объектов группы
     *
     * @param group модель TreeGroup
     */
    List<TreeObj> getObjectsByGroup(TreeGroup group);

    /**
     * Список дочерних групп
     *
     * @param group модель TreeGroup
     */
    List<TreeGroup> getChildGroups(TreeGroup group);

    //TODO
    TreeGroup getById(String uuid);

    //TODO
    TreeGroup getById(UUID uuid);

    //unchecked
    List<TreeGroup> getAll();
}