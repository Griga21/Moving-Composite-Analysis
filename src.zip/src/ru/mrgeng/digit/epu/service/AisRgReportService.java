package ru.mrgeng.digit.epu.service;

import java.util.List;
import java.util.Map;

public interface AisRgReportService {
    String NAME = "dgepu_AisRgReportService";

    List<Map<String,Object>> getReportData(Boolean uirgs, Boolean meters, int year, int month);
}