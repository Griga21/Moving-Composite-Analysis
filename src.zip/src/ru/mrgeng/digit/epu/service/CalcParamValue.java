package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.service.Data;
import ru.mrgeng.digit.dgcore.service.ParamValue;

/**
 * Объект для расчетных данных параметрам
 */
public class CalcParamValue extends ParamValue {

    private static final long serialVersionUID = 1L;

    Object calcVal;

    public CalcParamValue() {
    }

    public CalcParamValue(Object calcObj) {
        this.calcVal = calcObj;
    }

    @Override
    public Data copy() {
        CalcParamValue paramData = new CalcParamValue();
        paramData.calcVal = calcVal;
        return paramData;
    }

    @Override
    public Data addTotal(Data from) {
        return this;
    }

    @Override
    public Double getParam(String paramName) {
        if (calcVal instanceof Number) {
            Number num = (Number) calcVal;
            return num.doubleValue();
        }
        return null;
    }

    public String getSparam(String paramName) {
        if (calcVal != null)
            return calcVal.toString();
        return null;
    }

    @Override
    public String toString() {
        return calcVal != null ? calcVal.toString() : null;
    }

}
