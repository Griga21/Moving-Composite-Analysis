package ru.mrgeng.digit.epu.service.mapper;

import com.haulmont.cuba.core.entity.KeyValueEntity;

import java.util.List;
import java.util.Map;

public interface MapperKeyValueEntityService {
    String NAME = "dgepu_MapperKeyValueEntityService";
     KeyValueEntity mapToEntity(String key, String value);
     List<KeyValueEntity> mapToEntityList(Map<String, String> map);
}