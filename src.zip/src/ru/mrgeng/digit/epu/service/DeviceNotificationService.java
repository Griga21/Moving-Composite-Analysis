package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.Device;

public interface DeviceNotificationService {
    String NAME = "dgepu_DeviceNotificationService";

    void sendEmail(Device device);

    String getSmtpHost();

}