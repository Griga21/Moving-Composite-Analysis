package ru.mrgeng.digit.epu.service;

import java.util.Map;

/**
 * Работа с описаниями параметров
 */
public interface ParamDescrService {
    String NAME = "pros_ParamDescrService";

    Map<String, String> getUnitMap();

    Map<String, String> getPrefixMap();

    Map<String, String> getUnitAbbrMap();

    Map<String, String> getPrefixAbbrMap();

    /**
     *
     * @return Возращает Map<String, String> где ключ на русском языке, а значение на английском
     */
    Map<String, String> getPrefixAbbrMapReverb();

}