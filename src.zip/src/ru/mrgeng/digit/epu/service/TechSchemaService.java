package ru.mrgeng.digit.epu.service;



import ru.mrgeng.digit.epu.mp.techschema.TechSchemaModel;
import ru.mrgeng.digit.epu.mp.techschema.schemafile.TechSchema;

import java.io.File;
import java.util.List;
import java.util.UUID;

/**
 * Сервис технологической схемы
 */

public interface TechSchemaService {
    String NAME = "pros_TechSchemaService";

    /**
     * Вернуть места измерений по типу устройств
     *
     * @return Список моделей технологических схем
     */
    List<TechSchemaModel> getAll();

    /**
     * Вернуть JSON параметры модели
     *
     * @param objid идентификатор techSchemaModel
     * @return JSON строка модели с параметрами
     */
    String getJson(String objid);

    /**
     * Вернуть модель по идентификатору
     *
     * @param objId идентификатор techSchemaModel
     * @return Модель технологической схемы
     */
    TechSchemaModel getFirstModel(String objId);

    /**
     * Вернуть путь до файла по идентификатору модели
     *
     * @param devId идентификатор techSchemaModel
     * @return Содержимое файла
     */
    String getFileContent(String devId);

    /**
     * Обновить данные модели
     *
     * @param model модель techSchemaModel
     */
    void update(TechSchemaModel model);

    /**
     * Вернуть список моделей по идентификатру
     *
     * @param objId идентификатор_устройства.код_места_измерений
     * @return Список моделей технологических схем
     */
    List<TechSchemaModel> getModelsByObjId(String objId);


    TechSchemaModel getModelById(UUID uuid);

    boolean haveFileContent(TechSchemaModel model);

    /**
     * Вернуть путь до файла по модели
     *
     * @param model модель techSchemaModel
     * @return Содержимое файла
     */
    String getFileContent(TechSchemaModel model);

    List<TechSchemaModel> getModelsBySchema(TechSchema techSchema);

    /**
     * Установить идентификатор svg
     *
     * @param file  файл svg
     * @param svgId устанавливаемый идентификатор
     */
    void setIdToSvg(File file, String svgId);
}