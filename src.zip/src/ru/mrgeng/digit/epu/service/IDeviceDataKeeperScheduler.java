package ru.mrgeng.digit.epu.service;

public interface IDeviceDataKeeperScheduler {

    /**
     * Периодически проверяет, когда последний раз приходили данные для устройств, у которых задана периодичность поступления данных.
     * Запускается по расписанию, которе задано в spring.xml. Если данные не приходили в заданный период поступления данных + mp.device.timeOutMs,
     * создается событие с типом DeviceEventType.NO_DATA
     */

    void checkNoDataEvents();
}