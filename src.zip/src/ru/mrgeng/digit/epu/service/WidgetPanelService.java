package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.widgets.WidgetDto;
import ru.mrgeng.digit.epu.mp.widgets.WidgetSetting;
import ru.mrgeng.digit.epu.mp.widgets.WidgetTextDto;
import ru.mrgeng.digit.epu.mp.Device;

import java.io.Serializable;
import java.util.List;

public interface WidgetPanelService {
    String NAME = "pros_WidgetPanelService";

    class ParamDto implements Serializable {
        public long paramId;
        public String lineCode;
    }

    String getAllParams(long deviceId);

    String getParamsData(long deviceId, List<ParamDto> params);

    void saveSettings(long deviceId, String screenId, List<WidgetDto> widgets, List<WidgetTextDto> texts, String templateName);

    String getSettings(long deviceId, String screenId);

    String getParamsWithData(long deviceId);

    void copySettingIfNeed(Device device, String screenId);

    WidgetSetting getWidgetSetting(long deviceId, String screenId);

    List<WidgetSetting> getWidgetSetting(long deviceId);

    String copySetting(Device source, Device destination, String screenId);

    void setTemplate(Device device, String screenId, WidgetSetting template);

    String setUseTemplate(Device device, String screenId, boolean useTemplate);

    void copySettingFromTemplate(Device device, String screenId, WidgetSetting template);
}