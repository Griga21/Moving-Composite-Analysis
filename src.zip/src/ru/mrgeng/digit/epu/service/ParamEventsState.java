package ru.mrgeng.digit.epu.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.mrgeng.digit.dgcore.DateUtils;
import ru.mrgeng.digit.epu.mp.DeviceEvent;;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

public class ParamEventsState {

    private static final Logger log = LoggerFactory.getLogger(ParamEventsState.class);

    private Date lastEventDate;
    private Date oldestEvent;

    public ParamEventsState(Date eventDate) {
        lastEventDate = eventDate;
        oldestEvent = eventDate;
    }

    public ParamEventsState(DeviceEvent deviceEvent) {
        this(Date.from(deviceEvent.getDataTs().atZone(ZoneId.systemDefault()).toInstant()));
    }

    public Date getLastEventDate() {
        return lastEventDate;
    }

    public Date getOldestEventDate() {
        return oldestEvent;
    }

    public ParamEventsState updateOld(LocalDateTime oldestDeviceEvent) {
        Date oldestDate = Date.from(oldestDeviceEvent.atZone(ZoneId.systemDefault()).toInstant());
        oldestEvent = oldestDate;
        return this;
    }

    public ParamEventsState updateParamEventDates(DeviceEvent deviceEvent) {
        Date eventDate = Date.from(deviceEvent.getDataTs().atZone(ZoneId.systemDefault()).toInstant());
        return updateParamEventDates(eventDate);
    }

    public ParamEventsState updateParamEventDates(Date eventDate) {
        if (eventDate.after(lastEventDate))
            lastEventDate = eventDate;
        if (eventDate.before(oldestEvent))
            oldestEvent = eventDate;
        return this;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtils.COMMON_TS_FORMAT);
        return "ParamEventsDescription{" +
                "lastEventDate=" + dateFormat.format(lastEventDate) +
                ", oldestEvent=" + dateFormat.format(oldestEvent) +
                '}';
    }
}
