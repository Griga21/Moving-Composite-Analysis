package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.ObjParams;
import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.transform.TransformException;

import java.util.Map;

public class ObjParamsTransformException extends ObjParams {

    Map<String, TransformException> paramsTransformException;

    public Map<String, TransformException> getParamsTransformException() {
        return paramsTransformException;
    }

    public void setParamsTransformException(Map<String, TransformException> paramsTransformException) {
        this.paramsTransformException = paramsTransformException;
    }

    @Override
    public String toString() {
        return StrUtils.toStr("ObjParams", "objId", objId, "pt", paramTime, "ot", obtainTime, "params", params, "sparams", sparams, "paramsTransformException", paramsTransformException);
    }
}
