package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.epu.mp.DeviceType;

public interface DeviceModelService {
    String NAME = "pros_DeviceModelService";
    Boolean checkDeviceModelByCodeAndDeviceType(String code, DeviceType deviceType, Long excludeId);
}