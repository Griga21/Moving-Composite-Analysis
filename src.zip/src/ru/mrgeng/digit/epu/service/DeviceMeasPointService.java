package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.DeviceModel;

public interface DeviceMeasPointService {
    String NAME = "pros_DeviceMeasPointService";
    Boolean checkDeviceMeasPointByCodeAndDeviceModel(String code, DeviceModel deviceModel, Long excludeId);
}
