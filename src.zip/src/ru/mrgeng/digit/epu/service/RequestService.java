package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.service.RequestInfo;

import java.util.List;

public interface RequestService {

    String NAME = "digit_RequestService";

    RequestInfo getLast(String requestId);

    int getRequestInfoLastIndex(String requestId);

    List<RequestInfo> getRequestInfos(String requestId, int from, int to);

    void cleanUp(String requestId);

}
