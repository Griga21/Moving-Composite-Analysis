package ru.mrgeng.digit.epu.service;

/**
 * Интерфейс доступа к информации об ошибке, которая передается в виде строки
 */
public interface ErrorAware {

    /**
     * @return null если ошибки нет
     */
    String getErr();

    default boolean hasErr() {
        return getErr() != null && !getErr().isEmpty();
    }

}
