package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.entity.Department;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface DispShiftReportService {
    String NAME = "pros_DispShiftReportService";

    String DISPATCHER_JOURNAL_REPORT_CODE = "dispatcherJournal";

    List<Map<String, String>> dispatcherJournalHeader(Date dateForm, Date dateTo, Department department);

    List<Map<String, String>> dispatcherJournalBody(Date dateForm, Date dateTo, Department department);
}