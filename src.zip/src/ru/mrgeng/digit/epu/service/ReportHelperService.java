package ru.mrgeng.digit.epu.service;

import com.haulmont.bali.collections.ReadOnlyLinkedMapValuesView;
import ru.mrgeng.digit.epu.mp.*;
import ru.mrgeng.digit.epu.dto.UnitConvertDto;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ReportHelperService {
    String NAME = "pros_ReportHelperService";

    static String addDateToFileName(String deviceName, String fullName){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yy HH-mm");
        fullName = fullName + " " + simpleDateFormat.format(new Date());
        return trimExcelFileNameIfNeeded(deviceName, fullName);
    }
    private static String trimExcelFileNameIfNeeded(String deviceName, String fullName){
        int maxExcelFileNameLength = 202;
        if(fullName.length() > maxExcelFileNameLength){
            int trimLength = fullName.length() - maxExcelFileNameLength;
            if(trimLength >= deviceName.length()){
                return fullName;
            }
            String substring = deviceName.substring(0, deviceName.length() - trimLength);
            fullName = fullName.replace(deviceName, substring);
        }
        return fullName;
    }

    List<Map<String, Object>> getDeviceLastKeyValueParamWithMessage(Device device, DeviceService service, DeviceMeasPoint point, String groupCode, Date from, Date to);

    List<Map<String, Object>> getDeviceLastKeyValueParam(Device device, DeviceService service, DeviceMeasPoint point, String groupCode, Date from, Date to);

    List<Map<String, Object>> getDeviceLastKeyValueParam(Device device, DeviceService service, DeviceMeasPoint point, String groupCode, Date from, Date to, List<Map<String, Object>> defaultList);

    String getDeviceGroupCode(Device device, String groupCodeEnd);
    String getDeviceGroupCode(MeasPoint point, String groupCodeEnd);

    Map<String, String> getHeaderParamUnitMap(String groupCodeEnd);

    Map<String, String> getFullHeaderParamUnitMap(Device device, String groupCodeEnd);

    /**
     * Метод используется в отчете Данные о суточном потреблении (по всем подключенным объектам)
     * @return Мапа: "Код" - "Название [единицы измерения]"
     */
    Map<String, String> getParamDesignationUnitMap(Device device, DataPeriodicity dataPeriodicity);

    /**
     * Метод больше не используется в очтете Данные о суточном потреблении (по всем подключенным объектам)n
     */
    @Deprecated
    Map<String, String> getHeaderParamUnitMap(Device device, String groupCodeEnd);

    /**
     * Метод больше не используется в очтете Данные о суточном потреблении (по всем подключенным объектам)
     */
    @Deprecated
    List<Map<String, String>> getHeaderParamUnitListMap(Device device, String groupCodeEnd);

    List<Map<String, Object>> modifyDateVal(List<Map<String, Object>> valList, String keyName, int unit, int count);

    List<Map<String, Object>> modifyDateHourVal(List<Map<String, Object>> valList, String keyName, int count);

    List<Map<String, List<Map<String, Object>>>> getDeviceParamRaw(Device device, String deviceServiceCode, Date from, Date to, Map<String, String> nameMap, Set<String> include, Boolean withAllParams, Boolean withEmptyValueParams);

    List<Map<String, Object>> getDeviceEvents(Date from, Date to, String objId, String serviceCode, String gGroup);

    List<Map<String, Object>> getDeviceEvents(Date from, Date to, String objId, String serviceCode, String gGroup, String dateColName);

    List<Map<String, List<Map<String, Object>>>> getDeviceParamValue(Device device, DeviceService service, String group, DeviceMeasPoint point, Date dateFrom, Date dateTo, Map<String, String> nameMap, Set<String> userKeys, FormatType type);

    /**
     * Пересчет в указанные единицы измерения
     * @return
     */
    public List<Map<String, List<Map<String, Object>>>> getDeviceParamValueWithUnit(Device device,
                                                                                    DeviceService service,
                                                                                    String groupCodeEnd,
                                                                                    DeviceMeasPoint point,
                                                                                    Date from,
                                                                                    Date to,
                                                                                    Map<String, String> nameMap,
                                                                                    Set<String> userKeys,
                                                                                    FormatType type,
                                                                                    Map<String, UnitConvertDto> unitConvertDtoMap);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjects(ReadOnlyLinkedMapValuesView listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjects(Collection<MeasPoint> listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour);

    List<Map<String, List<Map<String, Object>>>> getStatisticHourData(ReadOnlyLinkedMapValuesView listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour);

    Map<String, List<Map<String, Object>>> getDataForAlarmReport(List<MeasPoint> measPoints, Date from, Date to);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjects(ReadOnlyLinkedMapValuesView listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour, String paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjects(Collection<MeasPoint> listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour, String paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjects(ReadOnlyLinkedMapValuesView listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour, Param paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjects(Collection<MeasPoint> listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean useOnlyCommonHour, Param paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjectsWithParamCode(ReadOnlyLinkedMapValuesView listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean deviceCommHour, String paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjectsWithParamCode(Collection<MeasPoint> listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean deviceCommHour, String paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjectsWithParamCode(ReadOnlyLinkedMapValuesView listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean deviceCommHour, Param paramCode);

    List<Map<String, List<Map<String, Object>>>> getVbyAllObjectsWithParamCode(Collection<MeasPoint> listDevice, Date from, Date to, String typeGroup, boolean interrogation, boolean deviceCommHour, Param paramCode);
}
