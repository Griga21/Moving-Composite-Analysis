package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.DataPeriodicity;
import ru.mrgeng.digit.epu.mp.DevicePolling;

public class MissedDataPoll extends AbstractPoll {
    final String paramCode;
    final Integer requestDeep;
    final DataPeriodicity deepType;
    final DataPeriodicity groupPeriodicity;

    public MissedDataPoll(DevicePolling polling) {
        super(polling.getId(),
                polling.getMissedDataCron(),
                polling.getParamGroup().getCode(),
                polling.isAdditionalMissedData(),
                polling.isWithCommHourMissedData());
        this.paramCode = polling.getParam() == null ? null : polling.getParam().getCode();
        this.requestDeep = polling.getRequestDeep();
        this.deepType = polling.getDataPeriodicity();
        this.groupPeriodicity = polling.getParamGroup().getDataPeriodicity();
    }

    private MissedDataPoll(MissedDataPoll poll) {
        super(poll.getId(),
                poll.getCron(),
                poll.getGroupCode(),
                poll.isAdditional(),
                poll.isWithCommHour());
        this.paramCode = poll.getParamCode();
        this.requestDeep = poll.getRequestDeep();
        this.deepType = poll.getDeepType();
        this.groupPeriodicity = poll.getGroupPeriodicity();
        this.addIgnoredPoll(poll);
    }

    @Override
    public MissedDataPoll copy() {
        return new MissedDataPoll(this);
    }

    @Override
    public MissedDataJobParams getJobParams(String serviceCode, String deviceCode) {
        return new MissedDataJobParams(serviceCode,
                deviceCode,
                groupCode,
                paramCode,
                requestDeep,
                deepType,
                withCommHour,
                groupPeriodicity);
    }

    public String getParamCode() {
        return paramCode;
    }

    public Integer getRequestDeep() {
        return requestDeep;
    }

    public DataPeriodicity getDeepType() {
        return deepType;
    }

    private DataPeriodicity getGroupPeriodicity() {
        return groupPeriodicity;
    }

    @Override
    public String toString() {
        return StrUtils.toStr(
                "RealTimeDevicePoll",
                "groupCode", groupCode,
                "cron", cron,
                "paramCode", paramCode,
                "requestDeep", requestDeep,
                "deepType", deepType,
                "additional", additional,
                "withCommHour", groupPeriodicity,
                "groupPeriodicity", groupPeriodicity);
    }
}