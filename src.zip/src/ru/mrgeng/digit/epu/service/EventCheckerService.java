package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.epu.mp.MeasPoint;
import ru.mrgeng.digit.epu.param.SeriousLevel;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface EventCheckerService {
    String NAME = "dgepu_EventCheckerService";

    enum EventData {
        ACCIDENT,
        INTERVENTIONS,
        JOURNAL,
        IGNORED_EVENT,
        POLL_JOURNAL_ERROR

    }

    class MpStruct implements Serializable {
        public Long mpId;
        public Long deviceId;
        public String line;
        public String deviceCode;
        public String service;

        public MpStruct(Long mpId, Long deviceId, String line, String deviceCode, String service) {
            this.mpId = mpId;
            this.deviceId = deviceId;
            this.line = line;
            this.deviceCode = deviceCode;
            this.service = service;
        }

        public String getObjId() {
            return line != null ? deviceCode + "." + line : deviceCode;
        }
    }

    void init();

    boolean hasInterventionsJournalEvent(Date from, Date to, MeasPoint measPoint);

    boolean hasAccidentJournalEvent(Date from, Date to, MeasPoint measPoint);

    boolean hasErrorInPollJournal(Date from, Date to, MeasPoint measPoint);

    boolean hasIgnoredEvents(Date from, Date to, MeasPoint measPoint);

    boolean hasDeviceEvent(Date from, Date to, MeasPoint measPoint);

    boolean hasDeviceEvent(Date from, Date to, MeasPoint measPoint, SeriousLevel level);

    Map<Long, List<EventData>> getEvents(Set<EventData> events, Date from, Date to, List<MpStruct> measPoints, String deviceTypeCode);
}