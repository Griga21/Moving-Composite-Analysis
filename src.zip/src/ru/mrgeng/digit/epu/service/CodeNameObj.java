package ru.mrgeng.digit.epu.service;


import com.google.gson.annotations.Expose;
import ru.mrgeng.digit.dgcore.service.DictObj;
import ru.mrgeng.digit.dgcore.service.util.StrUtils;

import java.io.Serializable;
import java.util.Objects;

public class CodeNameObj implements DictObj, Serializable, Comparable<CodeNameObj> {

    private static final long serialVersionUID = 1L;
    @Expose()
    public String code; // Код объекта
    @Expose()
    public String name; // Название

    public static CodeNameObj of(String name, String code) {
        CodeNameObj e = new CodeNameObj();
        e.code = code;
        e.name = name;
        return e;
    }

    @Override
    public String toString() {
        return StrUtils.toStr(getClass().getSimpleName(), "code", code, "name", name);
    }

    public CodeNameObj() {
    }

    public CodeNameObj(String code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CodeNameObj codeNameObj = (CodeNameObj) o;
        return Objects.equals(code, codeNameObj.code) &&
                Objects.equals(name, codeNameObj.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, name);
    }

    @Override
    public int compareTo(CodeNameObj codeNameObj) {
        if (code == null || codeNameObj.code == null)
            return 0;
        return code.compareTo(codeNameObj.code);
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }
}
