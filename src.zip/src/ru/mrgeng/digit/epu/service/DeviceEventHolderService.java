package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.epu.mp.DeviceEvent;

public interface DeviceEventHolderService {
    String NAME = "pros_DeviceEventHolder";
    void init();
    boolean checkNoDataEventByDeviceCode(String deviceCode);
    DeviceEvent getEventsByDeviceCode(String deviceCode);
    void removeByDeviceCode(String deviceCode);
    void putDeviceEvent(String deviceCode, DeviceEvent deviceEvent);
}