package ru.mrgeng.digit.epu.service;


public interface ServerCommonInformationService {
    String NAME = "pros_ServerCommonInformationService";


 String getServerId();
}