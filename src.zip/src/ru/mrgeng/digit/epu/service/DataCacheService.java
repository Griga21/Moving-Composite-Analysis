package ru.mrgeng.digit.epu.service;

import com.haulmont.cuba.core.entity.BaseLongIdEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public interface DataCacheService {

    String NAME = "digit_DataCacheService";

    class ObjSet<T extends BaseLongIdEntity> implements Serializable {
        private static final long serialVersionUID = 1L;
        public List<T> objs;
        public Set<Long> objIds;

        @Override
        public String toString() {
            return "ObjSet{" +
                    "objs=" + (objs != null ? objs.size() : objs) +
                    ", objIds=" + (objIds != null ? objIds.size() : objIds) +
                    '}';
        }
    }

    <T extends BaseLongIdEntity> ObjSet<T> getCache(String key);

    <T extends BaseLongIdEntity> void putCache(String key, ObjSet<T> objSet);

}
