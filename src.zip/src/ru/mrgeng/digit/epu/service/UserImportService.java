package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.RequestResult;

import java.util.Collection;
import java.util.UUID;

/**
 * Импорт пользователей ЕПУ с назначением ролей из служебной колонки dgepu_role.
 */
public interface UserImportService {
    String NAME = "dgepu_UserImportService";
    
    /**
     * Имопорт из Excel пользователей ЕПУ
     *
     * @param fileDescriptorId ID загруженного Excel-файла с пользователями.
     *                         Обязательные колонки см. в ru/mrgeng/digit/epu/service/importer/UserWorkbook.java
     */
    RequestResult importUsers(UUID fileDescriptorId);
    
    /**
     * Проверка доступа для пользователя к действию импорта пользователей
     *
     * @param roles роли пользователя, для которого запрашивается доступ
     */
    boolean isImportAllowed(Collection<String> roles);
}
