package ru.mrgeng.digit.epu.service;

import com.haulmont.cuba.core.global.Events;
import ru.mrgeng.digit.epu.mp.ObjsChangedEvent;


import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;

public class ServiceDataChanges {

    String serviceName;

    String serviceData;

    Set<String> dependsOfObjs;

    public ServiceDataChanges(String serviceName, String serviceData, Collection<String> dependsOfObjs) {
        this.serviceName = serviceName;
        this.serviceData = serviceData;
        this.dependsOfObjs = new HashSet<>(dependsOfObjs);
    }

    public ServiceDataChangedEvent hasChanges(ObjsChangedEvent event) {
        if (dependsOfObjs.contains(event.getDataName())) {
            return new ServiceDataChangedEvent(event, serviceName, serviceData);
        }
        return null;
    }

    public boolean isOwnChange(ServiceDataChangedEvent changedEvent) {
        return changedEvent.serviceData.equals(serviceData) && changedEvent.serviceName.equals(serviceName);
    }

    public void onOwnEvent(ObjsChangedEvent changedEvent, Consumer<ServiceDataChangedEvent> eventConsumer) {
        ServiceDataChangedEvent sde = hasChanges(changedEvent);
        if (sde != null)
            eventConsumer.accept(sde);

    }

    public void onOwnEvent(ObjsChangedEvent changedEvent, Events events) {
        ServiceDataChangedEvent sde = hasChanges(changedEvent);
        if (sde != null)
            events.publish(changedEvent);

    }

}
