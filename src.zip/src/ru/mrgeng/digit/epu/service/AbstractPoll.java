package ru.mrgeng.digit.epu.service;

public abstract class AbstractPoll extends IgnoredPoll {
    protected final String cron;
    protected final String groupCode;
    protected final boolean additional;
    protected final boolean withCommHour;

    public AbstractPoll(Long id, String cron, String groupCode, boolean additional, boolean withCommHour) {
        super(id);
        this.cron = cron;
        this.groupCode = groupCode;
        this.additional = additional;
        this.withCommHour = withCommHour;
    }

    public String getCron() {
        return cron;
    }

    public boolean isAdditional() {
        return additional;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public boolean isWithCommHour() {
        return withCommHour;
    }

    public abstract <K extends AbstractPoll> K copy();

    public abstract JobParams getJobParams(String serviceCode, String deviceCode);
}