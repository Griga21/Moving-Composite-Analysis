package ru.mrgeng.digit.epu.service;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.Expose;
import com.haulmont.chile.core.datatypes.impl.EnumClass;
import org.slf4j.Logger;
import ru.mrgeng.digit.dgcore.DateUtils;
import ru.mrgeng.digit.dgcore.RequestResult;
import ru.mrgeng.digit.dgcore.service.*;
import ru.mrgeng.digit.dgcore.service.log.LogMsg;
import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.*;
import ru.mrgeng.digit.epu.param.Param;
import ru.mrgeng.digit.epu.transform.TransParamDef;
import ru.mrgeng.digit.epu.util.BitMaskUtils;

import java.io.Serializable;
import java.time.Instant;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static ru.mrgeng.digit.dgcore.DateUtils.COMMON_TS_FORMAT;

/**
 * Управление настройками и получатель данных от сервисов сбора данных
 */
public interface MpService {
    String NAME = "pros_MpService";

    // Формат временных меток в строковом представлении
    String TS_FORMAT = COMMON_TS_FORMAT;

    String TS_FORMAT_2 = "yyyy-MM-dd'T'HH:mm:ss";

    // Название хранилища CUBA для ведения объектов управления сервисами
    String STORAGE = "meas_params";

    String PARAM_CLASS = "device";

    String MANUAL_INPUT = "hand";

    // Разделитель групп и параметров
    char GROUP_PARAM_SEP = '.';

    String SESS_PARAM_ALLOW_SERVICES = "mp.allowServices";

    String LINE_VALID_REGEXP = "^line[1-9]\\d*$";

    CodeNameObj DEVICE_GROUP_RAW = new CodeNameObj("raw", "Исходные");

    CodeNameObj DEVICE_JOURNAL_POLL = new CodeNameObj("jpoll", "Журнал опроса");

    String DEVICE_CONNECT = "Устройство вышло на связь";

    String DEVICE_DISCONNECT = "Связь с устройством завершена";

    String paramSetEnd = ".set";

    String PARAM_TIME_CODE_ENDING = "_Time";

    String GROUP_TIME_CODE_FIRST = "Time";

    String GROUP_TIME_CODE_SECOND = "time";

    /**
     * приведенный параметр; число часовых архивов пришедших за сутки
     */
    String hCount = "hCount";

    /**
     * приведенный параметр; число тревог (ga) пришедших за сутки
     */
    String gaCount = "gaCnt";

    /**
     * приведенный параметр; число событий (gv) пришедших за сутки
     */
    String gvCount = "gvCnt";

    String msgParam = "msg";

    /**
     * Глубина по умолчанию для поиска последних значений параметра в исходных(raw) данных в днях
     */
    int DEFAULT_RAW_DATA_LAST_DEPTH_DAYS = 180;

    /**
     * ParamInfo и время для сохранения настроек адаптеров
     */
    ParamInfo adapterInfo = ParamInfo.ofDevice("adapter", "config");
    Date adapterPt = Date.from(Instant.ofEpochMilli(946684800000L)); // Saturday, 1 January 2000 г., 0:00:00

    /**
     * Статус приложения
     */
    class ApplicationStatus implements Serializable {
        // false - Норма, true - требуется перезапуск
        public boolean needRestart;
    }

    /**
     * @return Текущий статус приложения
     */
    ApplicationStatus getApplicationStatus();

    class ParamAttention implements Serializable {
        public Date lastDate;
        public String message;
        boolean removed = false;

        ParamAttention(String msg, Date paramDate) {
            lastDate = paramDate;
            message = msg;
        }

        @Override
        public String toString() {
            return "ParamAttention{" +
                    ", lastDate=" + lastDate +
                    ", message='" + message + '\'' +
                    '}';
        }
    }

    /**
     * Статусы по работе устройства
     */
    class DeviceStat implements Serializable {

        private static final long serialVersionUID = 1L;

        public Date lastDataAt; // Время получения последних данных

        public Date lastDataErrAt; // Время получения последних ошибок данных

        public String lastDataErrInfo;// DigitCmd.err || ObjRawParams.err

        public Date lastAlarmAt;  // Время получения последних тревог 1-0

        public Date lastOverLimit1At; // Время последнего превышения первого лимита

        public String lastOverLimit1Info;

        public Date lastOverLimitAt; // Время последнего превышения лимитов

        public String lastOverLimitInfo;

        public int colorFraction = 0;

        // код группы //код параметра
        private Map<String, Map<String, ParamAttention>> lastAttentionEventMap;

        public int countTransformException = 0;

        public DeviceStat init(Date lastConnectionDate) {
            lastDataAt = lastConnectionDate;
            return this;
        }

        public Map<String, Map<String, ParamAttention>> getLastAttentionEventMap() {
            if (lastAttentionEventMap == null)
                lastAttentionEventMap = new HashMap<>();
            return lastAttentionEventMap;
        }

        public boolean isHaveTransformException() {
            return countTransformException != 0;
        }

        public ParamAttention getParamAttention(String groupCode, String paramCode) {
            if (countTransformException == 0)
                return null;
            Map<String, ParamAttention> params = getLastAttentionEventMap().get(groupCode);
            if (params == null)
                return null;
            ParamAttention attention = params.get(paramCode);
            if (attention == null)
                return null;
            if (!attention.removed)
                return attention;
            return null;
        }

        @Override
        public String toString() {
            return StrUtils.toStr(getClass().getSimpleName(), "lastData", lastDataAt, "lastAlarm", lastAlarmAt, "limit1", lastOverLimit1At, "limit2", lastOverLimitAt);
        }

        public boolean isColored() {
            return colorFraction != 0;
        }
    }


    class SingleDeviceData implements Serializable {
        public String errorMessage;
        public MpService.DeviceStat deviceStat;
        //  String - devCode.lineX || devCode
        public Map<String, MpService.SingleDeviceMpData> points = new HashMap<>();
    }

    class SingleDeviceMpData implements Serializable {
        public String mpCode;

        //<КодГруппыПараметров<КодПараметра,Значение>>
        public Map<String, Map<String, ParamValue>> mapParamWithLastData = new HashMap<>();

        public SingleDeviceMpData(String mpCode) {
            this.mpCode = mpCode;
        }

        public String getMpCodeNotNull() {
            return mpCode == null ? DeviceParamService.NO_MEAS_POINT : mpCode;
        }
    }

    interface ServiceCtx {

        Logger getLogger();

        Status getStatus();

        String getServiceCode();

        boolean getLogData();

        DeviceConfig findConfig(String devWithLine);

        DeviceStat getDeviceStat(String code, ParamService paramService, ParamInfo paramInfo);

        DeviceConfig getConfig(String devCode);

        DeviceParamService.ParamsInfo<ru.mrgeng.digit.epu.param.Param> getDeviceCalcParams(String devCode);

        Map<String, Map<Long, Param>> getParamsByLines(String devCode);

        Map<String, Map<Long, String>> getTransformsParams(String devCode);

        Map<TransParamDef, MpService.ParamDef> getParamsForWrite(String devCode);

        Map<String, DeviceParamService.ParamsThresholdInfo> getCalcParamsThresholdsByCodes();

        Map<String, Map<String, Map<String, Date>>> getIgnoreParamsEventsByDevice();

        void refreshIgnores();

        void refreshThresholds();
    }

    /**
     * @param serviceCode - код сервиса сбора данных
     */
    void refreshServiceThresholds(String serviceCode);

    /**
     * @param serviceCode - код сервиса сбора данных
     */
    void refreshServiceIgnores(String serviceCode);

    /**
     * @param serviceCode - код сервиса сбора данных
     */
    void refreshServiceConfig(String serviceCode);

    /**
     * @param sysCode  код сервиса
     * @param devCodes коды устройств
     * @return статусы по устройству
     */
    Map<String, DeviceStat> getDeviceStat(String sysCode, List<String> devCodes);

    // Параметр устройства в модели данных протокола взаимодействия с ним
    class ParamDef extends Param {
        private static final long serialVersionUID = 1L;
        public String protoAddress; // Адрес параметра по протоколу (например, регистр Modbus или тэг OPC)
        public Boolean used; // Параметр используется в приведенных данных

        public Integer flag; // Поле флагов параметра, в т.ч READ/WRITE

        public  boolean isWrite() {
            return BitMaskUtils.isWrite(flag != null ? flag : code != null ? BitMaskUtils.getFlagByDeviceParamCode(code) : null);
        }

        public  boolean isRead() {
            return flag == null || BitMaskUtils.isRead(flag);
        }

        @Override
        public String toString() {
            return StrUtils.toStr("ParamDef", "group", groupCode, "code", code, "name", name, "type", type,
                    "addr", protoAddress, "prefix", metricPrefix, "unit", unit, "id", internalId, "isWrite", isWrite(),
                     "used", used, "flag", flag);
        }
    }

    // Группа параметров устройства в модели данных протокола взаимодействия с ним
    class GroupDef extends CodeNameObj {
        private static final long serialVersionUID = 1L;
        public Long internalId;
        public String protoAddress; // Адрес группы по протоколу (например, регистр Modbus или тэг OPC)
        public List<String> parents;

        @Override
        public String toString() {
            return StrUtils.toStr("GroupDef", "code", code, "name", name, "addr", protoAddress, "id", internalId, "parents", parents);
        }
    }

    class GroupDefExt {
        public GroupDefExt(GroupDef groupDef) {
            this.groupDef = groupDef;
        }

        public GroupDef groupDef;
        public String simpleCode;
    }

    // Модель данных драйвера, согласно которой драйвер в СВУ присылает данные с устройств в ЕПУ
    class DeviceProtoModelDef extends CodeNameObj {
        private static final long serialVersionUID = 1L;
        public Long internalId;

        public String devType;
        public List<ParamDef> params;
        public List<GroupDef> groups;
        public List<DeviceActionDef> actions;

        public Map<String, GroupDef> getDriverGroups() {
            return groups.stream().collect(Collectors.toMap(it -> it.code, Function.identity(), (id1, id2) -> id1));
        }

        public Map<String, ParamDef> getDriverParams() {
            return params.stream().collect(Collectors.toMap(it -> it.code, Function.identity(), (id1, id2) -> id1));
        }

        public ParamDef findParamTsFor(ParamDef forParam) {
            String firstTsCand = forParam.code + PARAM_TIME_CODE_ENDING;
            String secondTsCand = forParam.groupCode + GROUP_PARAM_SEP + GROUP_TIME_CODE_FIRST;
            String thirdTsCand = forParam.groupCode + GROUP_PARAM_SEP + GROUP_TIME_CODE_SECOND;
            Optional<ParamDef> any = params.stream().filter(it -> it.code.equals(firstTsCand)).findAny();
            return any.orElse(params.stream().filter(it -> it.code.equals(secondTsCand)).findAny().
                    orElse(params.stream().filter(it -> it.code.equals(thirdTsCand)).findAny().orElse(null)));
        }

        @Override
        public String toString() {
            return StrUtils.toStr("DeviceModelDef", "code", code, "name", name, "devType", devType, "id", internalId, "params", params, "groups", groups);
        }

    }

    class DeviceModelDef extends CodeNameObj {
        private static final long serialVersionUID = 1L;
    }

    class DeviceRecalcConfig implements Serializable {
        private static final long serialVersionUID = 1L;

        public boolean configured;
        public boolean enabled;
        public int accDayPriority = 200;
        public int hourSumPriority = 300;
        public int accHourPriority = 100;
    }

    /**
     * Предполагается, что тип устройства и сервис сбора данных одинаковый для всех устройств в объекте этого класса
     */
    class AverageDevicesInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        public final Long averagerId;
        public final String averageStorageOid;
        public final List<String> sourseOidList;

        public AverageDevicesInfo(Long averagerId, String averageStorageOid, List<String> sourseOidList) {
            this.averagerId = averagerId;
            this.averageStorageOid = averageStorageOid;
            this.sourseOidList = sourseOidList;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            AverageDevicesInfo that = (AverageDevicesInfo) o;
            return averagerId.equals(that.averagerId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(averagerId);
        }
    }

    // Расписание опроса группы параметров устройства
    @Deprecated
    class DevicePollDef extends CodeNameObj implements PollPriorityInfo {
        private static final long serialVersionUID = 1L;
        public String info;
        public String cron;
        public RequestPeriod requestPeriod;

        public Long mainPoolingId;//id подходящего по критериям расписания
        public Set<Long> ignoredPoolingIds;//id игнорируемых, но подходящих по критериям расписаний

        public void addIgnoredPoll(DevicePolling devicePolling) {
            initIgnore();
            ignoredPoolingIds.add(devicePolling.getId());
        }

        public void addIgnoredPoll(DevicePollDef devicePollDef) {
            initIgnore();
            ignoredPoolingIds.add(devicePollDef.mainPoolingId);
            if (devicePollDef.ignoredPoolingIds != null)
                ignoredPoolingIds.addAll(devicePollDef.ignoredPoolingIds);
        }

        private void initIgnore() {
            if (ignoredPoolingIds == null)
                ignoredPoolingIds = new HashSet<>();
        }

        @Override
        public Long getId() {
            return mainPoolingId;
        }

        @Override
        public Set<Long> getIgnoredPollIds() {
            return ignoredPoolingIds;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("DevicePollDef", "code", code, "cron", cron, "info", info);
        }
    }

    // Запрос группы параметров или параметров по устройству
    @Deprecated
    class MissedDataDeviceParams extends CodeNameObj {
        public String paramCode;
        public Integer requestDeep;
        public DataPeriodicity deepType;
        public String convertedCode;

        public Boolean sendAllParamCodes;

        public String deviceCode;
        public String serviceCode;

        @Override
        public String toString() {
            return StrUtils.toStr("Запрос пропущенных данных по устройству", "", deviceCode,
                    "группа", code, "параметр", paramCode, "код сервиса", serviceCode);
        }
    }

    // Конфигурация опроса пропущенных значений группы параметров устройства
    @Deprecated
    class DevicePollMissedDataDef extends CodeNameObj implements PollPriorityInfo {
        private static final long serialVersionUID = 1L;

        public String info;
        public String cron;
        public String paramCode;
        public Integer requestDeep;
        public DataPeriodicity deepType;
        public String convertedCode;


        public Long mainPoolingId;//сылка на подходящее по критериям расписание
        public Set<Long> ignoredPoolingIds;//сылки на игнорируемые, но подходящие по критериям расписания

        public void cashIgnorePoll(DevicePolling devicePolling) {
            initIgnore();
            ignoredPoolingIds.add(devicePolling.getId());
        }

        public void cashIgnorePoll(DevicePollMissedDataDef devicePollDef) {
            initIgnore();
            ignoredPoolingIds.add(devicePollDef.mainPoolingId);
            if (devicePollDef.ignoredPoolingIds != null)
                ignoredPoolingIds.addAll(devicePollDef.ignoredPoolingIds);
        }

        private void initIgnore() {
            if (ignoredPoolingIds == null)
                ignoredPoolingIds = new HashSet<>();
        }

        @Override
        public Long getId() {
            return mainPoolingId;
        }

        @Override
        public Set<Long> getIgnoredPollIds() {
            return ignoredPoolingIds;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("DevicePollDef", "code", code, "cron", cron, "info", info);
        }
    }

    // Точки измерения в устройстве
    class DevicePointDef extends CodeNameObj {
        private static final long serialVersionUID = 1L;
        @Expose()
        private boolean actual = false;

        public boolean isActual() {
            return actual;
        }

        public DevicePointDef getActualCopy() {
            DevicePointDef point = new DevicePointDef();
            point.actual = true;
            point.code = this.code;
            point.name = this.name;
            return point;
        }
    }

    /**
     * Конфигурация действия (команды) в устройстве (для принудительного опроса и т.п.)
     * через запись значения в параметр
     */
    class DeviceActionDef extends CodeNameObj {
        private static final long serialVersionUID = 1L;

        @Expose()
        private ParamDef actParam;
        @Expose()
        private String actValue;

        public ParamDef getActParam() {
            return actParam;
        }

        public void setActParam(ParamDef actParam) {
            this.actParam = actParam;
        }

        public String getActValue() {
            return actValue;
        }

        public void setActValue(String actValue) {
            this.actValue = actValue;
        }

        @Override
        public String toString() {
            return "DeviceActionDef{" +
                    " code='" + code + '\'' +
                    ", name='" + name + '\'' +
                    ", actParam=" + actParam +
                    ", actValue='" + actValue + '\'' +
                    '}';
        }
    }


    // Линия измерения в устройстве
    class DeviceLineDef extends CodeNameObj {
        private static final long serialVersionUID = 1L;
        public String paramGroup; // Код группы параметров в исходных данных

        @Override
        public String toString() {
            return StrUtils.toStr("DeviceLineDef", "code", code, "name", name, "paramGroup", paramGroup);
        }

        public String toCaption() {
            return "Код: " + code + ", группа параметров в драйвере: " + (paramGroup != null ? paramGroup : "не задана");
        }
    }

    // Команда для сервиса взаимодействия
    class DigitCmd extends Request implements ErrorAware {
        public String serviceCode;

        public String err;

        public DigitCmd() {
            init();
        }

        @Override
        public String toString() {
            return "Запрос в Цифра{" +
                    " код сервиса='" + serviceCode + '\'' +
                    ", requestId='" + requestId + '\'' +
                    ", completed=" + completed +
                    ", err=" + err +
                    '}';
        }

        @Override
        public String getErr() {
            return err;
        }
    }

    // Коды команд
    String CMG_GETPARAMS = "getparams"; // Считать параметры из устройства
    String CMG_PUTPARAMS = "putparams"; // Записать параметры в устройство
    String CMG_GETDEVICES = "getdevices"; // Получить устройства и модели данных
    String CMG_GETINFO = "getinfo"; // Получить информацию
    String CMG_GETSTATUS = "getstatus"; // Получить статус

    // Плановый опрос (опрос по расписанию) – основной источник данных с устройств
    // «Докачка» (опрос недостающих данных по расписанию) – дополняет основной источник данных
    // Плановый опрос и «докачка» кроме выполняемых в данный момент заданий может включать т.н. «отложенные» задания опроса, выполнение которых начинается при возникновении соединения с устройством, находящимся на связи в случайные не прогнозируемые моменты времени.
    //         Экстренный (индивидуальный) опрос – опрос, выполняемый по инициативе пользователя системы, с целью оперативного получения данных с устройств.
    // Экстренная запись параметров устройства (например, состав газа), выполняемая по инициативе пользователя.
    // Обновление ПО устройства – выполняемое по плану или инициативе пользователя обновление программного обеспечения устройства.

    // Приоритеты команд
    int PRIO_USER_CONTROL = 1; // управление устройством или задание параметров устройства пользователем;
    int PRIO_USER_REQ = 3; //  экстренный опрос
    int PRIO_PLAN_REQ = 8; // плановый опрос
    int PRIO_PLAN_CONTROL = 10; //  плановое/отложенное программирование устройства
    int PRIO_LOSS_DATA = 12; // «докачка»


    // Запрос изменения параметров устройства
    class RequestChangeDeviceParams extends SvdCmd {

        public RequestChangeDeviceParams() {
            super();
            code = CMG_PUTPARAMS;
            prio = PRIO_USER_CONTROL;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Отправить изменения в устройство", "", deviceCode,
                    "параметры", params, "cmdParams", cmdParams, "запрос", requestId, "создан", DateUtils.ts(createdTs), "приоритет", prio, "код сервиса", serviceCode);
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    class ParamForCmd implements Serializable {
        public String param;
        public Object val = null;
        public String unit = null;

        @Override
        public String toString() {
            return StrUtils.toStr("ParamForCmd", "param", param, "val", val, "unit", unit);
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    class CmdParams implements Serializable {
        public String group;
        public List<ParamForCmd> params;

        @Override
        public String toString() {
            return StrUtils.toStr("ReqParams", "group", group, "params", params);
        }
    }

    class GetDevices extends SvdCmd {
        public GetDevices() {
            super();
            code = CMG_GETDEVICES;
            prio = PRIO_USER_CONTROL;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Запросить список устройств", "запрос", requestId, "создан", DateUtils.ts(createdTs), "приоритет", prio, "код сервиса", serviceCode);
        }
    }

    class GetInfo extends SvdCmd {
        public GetInfo() {
            super();
            code = CMG_GETINFO;
            prio = PRIO_USER_CONTROL;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Запросить диагностические файлы", "объект", deviceCode,
                    "запрос", requestId, "создан", DateUtils.ts(createdTs), "приоритет", prio, "код сервиса", serviceCode);
        }
    }

    class GetStatus extends SvdCmd {
        public GetStatus() {
            super();
            code = CMG_GETSTATUS;
            prio = PRIO_USER_CONTROL;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Запросить статус", "объект", deviceCode,
                    "запрос", requestId, "создан", DateUtils.ts(createdTs), "приоритет", prio, "код сервиса", serviceCode);
        }
    }

    class RequestChangeDeviceParamsDriverBased extends SvdCmd {

        public RequestChangeDeviceParamsDriverBased() {
            super();
            code = CMG_PUTPARAMS;
            prio = PRIO_USER_CONTROL;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Отправить изменения в устройство", "", deviceCode,
                    "параметры", reqParams, "cmdParams", cmdParams, "запрос", requestId, "создан", DateUtils.ts(createdTs), "приоритет", prio, "код сервиса", serviceCode);
        }
    }

    // Команда для сервиса взаимодействия
    class SvdCmd extends Request {
        public String code; // Код команды
        public String connToDevice; // Код у-ва, к которому подключено это у-во
        public String deviceCode; // Код у-ва
        public List<CmdParams> cmdParams;
        public Date from;
        public Date to;
        public Set<String> paramGroups;
        public Set<String> params;

        public int prio = PRIO_PLAN_REQ;

        public String serviceCode;

        public SvdCmd() {
            init();
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Команда в СВ", "Код команды", code, "устройство", deviceCode, "подключен к", connToDevice, "группы", paramGroups, "параметры", params,
                    "с", DateUtils.tsNoMs(from), "по", DateUtils.tsNoMs(to), "запрос", requestId, "создан", DateUtils.ts(createdTs), "код сервиса", serviceCode, "приоритет", prio);
        }

    }

    Function<String, CmdParams> combineGroup = (String groupName) -> {
        MpService.CmdParams reqParams = new MpService.CmdParams();
        reqParams.group = groupName;
        reqParams.params = null;
        return reqParams;
    };

    Function<Set<String>, List<CmdParams>> combineGroups = (Set<String> rawGroupNameList) -> rawGroupNameList.stream()
            .map(combineGroup)
            .collect(toList());

    // Map<String, Set<String>: String - код группы, Set<String> - коды параметров
    Function<Map<String, Set<String>>, List<CmdParams>> transformToCmdParams = (Map<String, Set<String>> groupsRawCodes) -> {
        if (groupsRawCodes != null && groupsRawCodes.size() != 0) {
            return groupsRawCodes.entrySet().stream().map(entry -> {
                MpService.CmdParams reqParams = new MpService.CmdParams();
                reqParams.group = entry.getKey();
                reqParams.params = entry.getValue().stream().map(paramCode -> {
                    MpService.ParamForCmd oneParam = new MpService.ParamForCmd();
                    oneParam.param = paramCode;
                    return oneParam;
                }).collect(toList());
                return reqParams;
            }).collect(toList());
        }
        return null;
    };

    Function<Set<Param>, List<CmdParams>> combineGroupAndParam = (Set<Param> mpServiceParamSet) -> {
        if (mpServiceParamSet != null && mpServiceParamSet.size() != 0) {
            return mpServiceParamSet.stream()
                    .collect(groupingBy(param -> param.groupCode))
                    .entrySet().stream().map(entry -> {
                        MpService.CmdParams reqParams = new MpService.CmdParams();
                        reqParams.group = entry.getKey();
                        reqParams.params = entry.getValue().stream().map(e -> {
                            MpService.ParamForCmd oneParam = new MpService.ParamForCmd();
                            oneParam.param = e.code;
                            return oneParam;
                        }).collect(toList());
                        return reqParams;
                    }).collect(toList());
        }
        return null;
    };

    // Запрос группы параметров или параметров по устройству
    class RequestDeviceParams extends SvdCmd {

        public RequestDeviceParams() {
            super();
            code = CMG_GETPARAMS;
        }

        public RequestDeviceParams(int prio) {
            super();
            code = CMG_GETPARAMS;
            this.prio = prio;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("Запрос данных по устройству", "", deviceCode, "подключен к", connToDevice,
                    "с", DateUtils.tsNoMs(from), "по", DateUtils.tsNoMs(to), "группы", paramGroups, "параметры", params, "запрос", requestId, "создан", DateUtils.ts(createdTs), "код сервиса", serviceCode, "приоритет", prio);
        }
    }

    // Описание конфигурации устройства (КП)
    class DeviceConfig extends CodeNameObj {
        private static final long serialVersionUID = 1L;
        @Expose()
        public Long internalId;
        @Expose()
        public String channelDriver; // Код драйвера
        @Expose()
        public String channelAddress;
        @Expose()
        public String serialNum;
        @Expose()
        public String provider;
        @Expose()
        public String protoAddress;
        @Expose()
        public String devLogin;
        @Expose()
        public String devPassword;
        @Expose()
        public String deviceAddress;
        @Expose()
        @Deprecated
        public String devType;
        @Expose()
        public String devSettings;
        @Expose()
        public boolean interrogation;
        @Expose()
        public String driverDataModel;
        protected DeviceProtoModelDef devModelDef;
        @Expose()
        public String connectedTo;
        @Expose()
        public DeviceModelDef modelDef;
        @Expose()
        public String status;
        public AverageDevicesInfo averageInfo;
        @Expose()
        public List<DevicePointDef> devPointDefs;
        @Expose()
        public boolean actualNoLine = false;
        @Expose()
        public List<DeviceLineDef> devLineDefs;
        @Expose()
        public Map attrs;

        public DeviceRecalcConfig recalcConfig;

        public List<RealTimePoll> realTimePolls;
        public List<MissedDataPoll> missedDataPolls;

        @Deprecated
        public List<DevicePollMissedDataDef> devPollMissedDataDefs;
        @Deprecated
        public List<DevicePollDef> devPollDefs;

        public List<? extends PollPriorityInfo> getMissedDataPollPriority() {
            return missedDataPolls == null ? devPollMissedDataDefs : missedDataPolls;
        }

        public List<? extends PollPriorityInfo> getRealTimePollPriority() {
            return realTimePolls == null ? devPollDefs : realTimePolls;
        }

        public Set<String> getAllOid() {
            if (devPointDefs == null || devPointDefs.size() == 0) {
                return Set.of(code);
            } else {
                return devPointDefs.stream()
                        .map(point -> code + "." + point.code)
                        .collect(Collectors.toSet());
            }
        }

        public void fillActualOid(Collection<String> collection) {
            if (actualNoLine)
                collection.add(code);
            if (devPointDefs != null) {
                for (DevicePointDef point : devPointDefs) {
                    if (point.isActual()) {
                        collection.add(code + "." + point.code);
                    }
                }
            }
        }

        public Set<String> getAllGroupParamsCode(String groupCode) {
            return devModelDef == null ? null :
                    devModelDef.params.stream()
                            .filter(paramDef -> paramDef.groupCode.equals(groupCode))
                            .filter(paramDef -> !paramDef.groupCode.endsWith(paramSetEnd))
                            .map(e -> e.code)
                            .collect(Collectors.toSet());
        }

        public DeviceProtoModelDef getDevModelDef() {
            return devModelDef;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("DeviceConfig",
                    "code", code, "name", name, "serialNum", serialNum, "provider", channelDriver,
                    "channelAddr", channelAddress, "driver", provider, "protoAddr", protoAddress, "modelDef", modelDef, "devType", devType, "driverDataModel", driverDataModel,
                    "devLogin", devLogin, "devPassword", devPassword, "settings", devSettings, "deviceAddress", deviceAddress, "connectedTo", connectedTo,
                    "interrogation", interrogation, "realTimePolls", realTimePolls, "missedDataPolls", missedDataPolls,
                    "polls", devPollDefs, "measPoints", devPointDefs, "devLineDefs", devLineDefs, "attrs", attrs);
        }

        @Override
        public boolean equals(Object object) {
            if (this == object) return true;
            if (object == null || getClass() != object.getClass()) return false;
            if (!super.equals(object)) return false;
            DeviceConfig that = (DeviceConfig) object;
            return Objects.equals(internalId, that.internalId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), internalId);
        }
    }

    class Status implements Serializable {
        private static final long serialVersionUID = 1L;
        public String code;
        public Date confChangeAt;
        public Date lastCmdAt;
        public Date lastDataAt;
        public Date lastStatusReqAt;

        @Override
        public String toString() {
            return StrUtils.toStr("Status",
                    "code", code, "confChangeAt", confChangeAt, "lastDataAt", lastDataAt, "lastCmdAt", lastCmdAt, "lastStatusReqAt", lastStatusReqAt);
        }
    }

    Status getStatus(String serviceCode);

    RequestResult sendCmd(SvdCmd cmd);

    /**
     * Отправить команду в сервис взаимодейсвия с КП
     *
     * @param cmd команда
     * @return результат
     */
    RequestResult sendSvdCmd(SvdCmd cmd);

    DeviceParamService.ParamsInfo<ru.mrgeng.digit.epu.param.Param> getDeviceCalcParams(String serviceCode, String devCode);

    /**
     * @param serviceCode код сервиса
     * @param devCode код устройства
     * @return Соответствие приведенного параметра исходному на запись
     */
    Map<TransParamDef, MpService.ParamDef> getParamsForWrite(String serviceCode, String devCode);

    Map<String, Map<Long, Param>> getParamsByLines(String serviceCode, String devCode);

    Map<String, Map<Long, String>> getTransformsParams(String serviceCode, String devCode);

    Map<String, Set<String>> getUsefulNullableMeasPoints(String serviceCode);

    List<SvdCmd> getCmds(String serviceCode);

    /**
     * @param serviceCode
     * @param devCode код устройства
     * @return выполняющиеся команды по устройству
     */
    List<SvdCmd> getDeviceCmds(String serviceCode, String devCode);

    List<DeviceProtoModelDef> getDriverDataModels(String serviceCode);

    DeviceProtoModelDef getDeviceDriverDataModel(String serviceCode, String devCode);

    DeviceProtoModelDef getDriverDataModel(String serviceCode, String driverCode);

    /**
     * Получить активные конфигурации КП по коду сервиса
     *
     * @param serviceCode код сервиса
     * @return конфигурации
     */
    List<DeviceConfig> getDeviceConfigs(String serviceCode);

    /**
     * @param serviceCode код сервиса
     * @return JSON с конфигурациями DeviceConfig для СВУ. В них пропускается часть атрибутов.
     */
    String svdDeviceConfigs(String serviceCode);

    /**
     * Получить параметры для чтения указанной модели
     *
     * @param model модель
     * @return параметры модели по кодам
     */
    DeviceProtoModelDef getDriverReadParams(String serviceCode, DeviceProtoModel model);

    /**
     * Получить редактируемые параметры указанной модели
     *
     * @param model модель
     * @return параметры модели по кодам
     */
    DeviceProtoModelDef getDriverSetParams(String serviceCode, DeviceProtoModel model);


    DeviceConfig getOneDeviceConfig(String serviceCode, String devCode);

    /**
     * Определить какой из вариантов расписаний будет применен для сервиса
     *
     * @param serviceCode код сервиса сбора данных
     * @return true - расписания только по группе приведенных параметров,
     * false - расписания только по группам параметров драйвера
     */
    boolean isDriverParamGroupBasedPool(String serviceCode);

    /**
     * Получить параметры указанной модели
     *
     * @param model модель
     * @return параметры модели по кодам
     */
    DeviceProtoModelDef getDriver(String serviceCode, DeviceProtoModel model);

    /**
     * Получить коды групп исходных параметров вместе с их исходными параметрами
     * по коду группы приведенных параметров для конкретного устройства
     *
     * @return если вернет null, то отсутствует кешированное преобразование,
     * (возможно перезагрузка преобразований и конфигураций драйвера исправит ситуацию, но только если изменены преобразования драйвера в бд)
     * если вернет пустую коллекцию, то найдено устройство с преобразованием, но нет конкретного преобразования для paramGroup,
     * гипотетически может быть size > 1, если из 2-х (или более) исходных групп сохраняются данные в одну приведенную
     */
    Map<String, Set<String>> getRawGroupCodes(String serviceCode, DeviceProtoModel model, String devCode, String paramGroup);


    /**
     * Записать исходные данные, полученные от КП
     *
     * @param cmd       cmd
     * @param objParams данные
     * @return результат
     */
    RequestResult putRawParams(DigitCmd cmd, List<ObjRawParams> objParams);

    RequestResult putDevParams(DevParams params);

    /**
     * Параметр запроса, инициирующий полную синхронизацию при обработке структуры putDevices
     */
    String SYNC_OBJS_PARAM = "syncObjs";

    /**
     * Значение параметра "syncObjs", указывающее на полную синхронизацию всех объектов
     */
    String SYNC_OBJS_PARAM_VAL_ALL = "all";
    /**
     * Значение параметра "syncObjs", указывающее на полную синхронизацию объектов драйвера (группы, параметры, преобразования)
     */
    String SYNC_OBJS_PARAM_VAL_DRIVER = "driver";


    /**
     * Сохранить модели данных драйверов и устройства.
     * <p>
     * Если в запросе(cmd) указан параметр "syncObjs"(константа SYNC_OBJS_PARAM), например:
     * <p>
     * "reqParams": {"params": {"syncObjs":"driver"}}
     * <p>
     * и если данные обработаны без ошибок (добавление, обновление), то будет выполнена полная синхронизация (удаление):
     * запрашивается список объектов в хранилище и сравнивается со списком объектов
     * в пакете, удаляются данные из хранилища, которые отсутствуют в пакете.
     * <p>
     * Варианты значений "syncObjs"
     * all - синхронизация и моделей и списка моделей и устройств, применять с осторожностью - может удалить много объектов в соотвествии с алгоритмом
     * driver - синхронизация групп параметров и параметров моделей драйверов, преобразований по этим параметров
     * название_сущности1,название_сущности2 - синхронизировать указанные через запятую сущности (можно также указать черех запятую all или driver)
     * <p>
     * Параметры, группы и преобразования в хранилище  при синхронизации ищутся по принадлежности к модели данных драйвера, который приходит в пакете.
     * Модели данных и устройства в хранилище при синхронизации ищутся по принадлежности к сервису (cmd.serviceCode).
     * <p>
     * <p>
     * <p>
     * <p>
     * all - синхронизация и моделей и списка моделей и устройств, применять с осторожностью - может удалить много объектов в соотвествии с алгоритмом
     * driver - синхронизация групп параметров и параметров моделей драйверов, преобразований по этим параметров
     * название_сущности1,название_сущности2 - синхронизировать указанные через запятую сущности (можно также указать черех запятую all или driver)
     * <p>
     * Параметры, группы и преобразования в хранилище  при синхронизации ищутся по принадлежности к модели данных драйвера, который приходит в пакете.
     * Модели данных и устройства в хранилище при синхронизации ищутся по принадлежности к сервису (cmd.serviceCode).
     *
     * @param cmd        запрос
     * @param dataModels модели данных драйверов
     * @param devices    конфигурации устройств
     * @return результат обработки
     */
    RequestResult putDevices(DigitCmd cmd, List<DeviceProtoModelDef> dataModels, List<DeviceConfig> devices);

    /**
     * Вывести объект в JSON (для отладки)
     *
     * @param obj объект
     * @return JSON - представление объекта
     */
    String toJson(Object obj);

    <T> T fromJson(String str, Class<T> clazz);

    void reloadSettings(String serviceCode, boolean updateConfChangeAt);

    /**
     * Сбросить кеши контекста данных работы с сервисом без запуска повторной актуализации и уведомлений о перезагрузке.
     *
     * @param serviceCode код сервиса
     */
    void reloadServiceWorkCtxCache(String serviceCode);

    void reloadTransforms(String serviceCode);

    /**
     * Получить данные по устройствам в разрезе дат измерений
     *
     * @param req    запрос
     * @param info   информация
     * @param objs   id устройств (с учетом мест измерений)
     * @param params параметры
     * @return данные по параметрам
     */
    Map<Date, Map<String, ParamData>> getObjParams(PeriodRequest req, ParamInfo info, List<String> objs, Set<String> params);

    /**
     * Получить данные по устройствам в разрезе id устройств
     *
     * @param req    запрос
     * @param info   информация
     * @param objs   id устройств (с учетом мест измерений)
     * @param params параметры
     * @return данные по параметрам
     */
    Map<String, List<ObjParams>> getObjData(PeriodRequest req, ParamInfo info, List<String> objs, Set<String> params);

    RequestResult startPoll(String serviceCode, Boolean sendAllParamCodes);

    RequestResult startPoll(String serviceCode, Boolean sendAllParamCodes, String targetServerId);

    @Deprecated
    RequestResult requestMissedDataByCondition(String serviceCode, int deepInDay, String paramGroups, Integer periodPoliticId, String filterByTcpCsdOrOther, String targerParameter);

    @Deprecated
    RequestResult requestMissedDataByStringCondition(String serviceCode, String deepInDayStr, String paramGroups, String periodPoliticIdStr, String filterByTcpCsdOrOther, String targetParameter);

    @Deprecated
    List<MpService.RequestDeviceParams> createMissedDataCmdByStringCondition(String serviceCode, String deepInDayStr, String paramGroups, String periodPoliticIdStr, String filterByTcpCsdOrOther, String targetParameter);

    @Deprecated
    RequestDeviceParams createMissedDataCmdAndLogByParams(String serviceCode, boolean sendParams, String devCode, int requestDeep, String convertedCode, String driverParamCode,
                                                          DataPeriodicity deepType, String targetParameter);

    RequestDeviceParams createRealTimeCmd(String serviceCode,
                                          String devCode,
                                          boolean sendParams,
                                          String groupCode,
                                          RequestPeriod requestPeriod,
                                          boolean withCommHour);

    RequestDeviceParams createMissedDataCmd(String serviceCode,
                                            String devCode,
                                            boolean sendParams,
                                            int requestDeep,
                                            String groupCode,
                                            DataPeriodicity deepType,
                                            String param,
                                            boolean withCommHour,
                                            DataPeriodicity groupPeriodicity);

    PeriodRequest getMissedDataPeriodRequest(Date currentDate,
                                             DataPeriodicity deepType,
                                             int requestDeep,
                                             int commHour,
                                             DataPeriodicity groupPeriodicity,
                                             boolean withCommHour);

    boolean containPoll(String serviceCode);

    RequestResult stopPoll(String serviceCode);

    enum TransformType implements EnumClass<String> {
        TRANSFORM(false),
        TRANSFORM_AND_CALCULATE(true);

        private final boolean calculate;

        TransformType(boolean calculate) {
            this.calculate = calculate;
        }

        public boolean isCalculate() {
            return calculate;
        }

        @Override
        public String getId() {
            return name();
        }
    }

    enum HistoricalArchiveRecalcMode implements EnumClass<String> {
        KEEP_UNMARKED_AS_DIRECT,
        OVERWRITE_UNMARKED,
        OVERWRITE_DIRECT_DAY;

        @Override
        public String getId() {
            return name();
        }
    }

    RequestResult recalcRawData(PeriodRequest request, ParamInfo pi, List<String> devs, Set<String> rawParams, TransformType transformType);

    RequestResult recalcRawData(PeriodRequest request, ParamInfo pi, List<String> devs, Set<String> rawParams, TransformType transformType, HistoricalArchiveRecalcMode historicalArchiveRecalcMode);

    /**
     * Информация об изменении конфигурации
     */
    class ConfChangeInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        public Date changedAt;

        @Override
        public String toString() {
            return StrUtils.toStr("ConfChangeInfo", "changeAt", changedAt);
        }
    }

    Map<String, ConfChangeInfo> getServiceConfChanges();

    /**
     * @param service Вывести статистику в журнал
     */
    void logServiceStat(String service);

    /**
     * @param service Вывести названия задач в журнал
     */
    void logServiceJobScheduler(String service);

    /**
     * Вывести информацию по зависшим командам
     */
    void checkHangingCmds();

    /**
     * Отправить сообщения в журнал опроса
     *
     * @param service сервис
     * @param msgs    сообщения
     */
    void log(String service, List<LogMsg> msgs);

    void init();

    /**
     * Сообщения журнала опроса
     */
    default LogMsg jpollMsg(DigitCmd cmd) {
        return new LogMsg().service(cmd.serviceCode).request(cmd.requestId).component(DEVICE_JOURNAL_POLL.code).now();
    }

    default LogMsg jpollMsg(String service, String devCode) {
        return new LogMsg().service(service).objId(devCode).component(DEVICE_JOURNAL_POLL.code).now();
    }

    Boolean getConnectStatus(MeasPoint mp);

    /**
     * Метод для получения работоспособности устройства
     * Если в последний запланированный период опроса устройства были получены данные - устройство работоспособно
     * @return Работоспособно ли устройство
     */
    Boolean isDeviceWorking(PeriodRequest periodRequest, ParamInfo paramInfo, MeasPoint measPoint);

    /**
     * Метод определения на связи ли устройство
     * Идет поиск по журналу опроса, находятся записи с сообщениями "Устройство вышло на связь" и "Связь с устройством завершена"
     * Если последнее по времени сообщение = "Устройство вышло на связь", то устройство на связи, иначе нет
     * @return На связи ли устройство
     */
    Boolean isDeviceConnected(PeriodRequest periodRequest, ParamInfo paramInfo, MeasPoint measPoint);

    /**
     * Метод для расчета последнего времени выполнения cron (с библиотекой cronutils)
     * @return Последнее время выполнения cron
     */
    Date getLastCronExecutionTime(String cron);

    /**
     * Метод для расчета последнего времени выполнения cron до определенной даты (с библиотекой cronutils)
     * @return Последнее время выполнения cron до определенной даты
     */
    Date getLastCronExecutionTime(Date date, String cron);

    List<Date> getAllCronExecutionsTimeForPeriod(PeriodRequest periodRequest, String cron);

    PeriodRequest getPeriodRequestForConnectionType(Device device);

    PeriodRequest getPeriodRequestFromDevicePolling(Device device);

    PeriodRequest getPeriodRequestFromDevicePolling(Device device, Integer secondsToSearchConnection);

    List<DevicePolling> getDevicePollings(Device device);

    /**
     * Проверить преобразование данных
     * @param rawInfo параметр драйвера
     * @param calcInfo приведенный параметр с преобразованиями
     * @param rawValue исходное значение
     * @return Результат. Преобразованное значение в .RequestResult.results
     */
    RequestResult testTransform(MpService.ParamDef rawInfo,
                                TransParamDef calcInfo,
                                String rawValue);

    /**
     * @param service код сервиса
     * @param devCode код устройства
     * @param paramGroup код группы параметра
     * @param paramCode код параметра
     * @return Последнее полученное значение
     */
    ParamValue getLastParamValue(String service, String devCode, String paramGroup, String paramCode);

    /**
     * Проверка можно ли опросить устройство
     * @param device опрашиваемое устройство
     * @return  пустую строку "" если можно
     */
    String checkDeviceType(Device device);


    /**
     * Метод сохранения настроек для адаптера
     * @param serviceCode код сервиса
     * @param config сами настройки
     */
    void saveAdapterConfig(String serviceCode, Map<String,String> config);

    /**
     * Метод получения настроек для адаптеров
     * @param serviceCode код сервиса взаимодействия
     * @return настройки
     */
    Map<String,String> getAdapterConfig(String serviceCode);
}
