package ru.mrgeng.digit.epu.service;

import ru.mrgeng.digit.dgcore.RequestResult;
import ru.mrgeng.digit.dgcore.event.LogMsgEvent;
import ru.mrgeng.digit.dgcore.service.ParamInfo;
import ru.mrgeng.digit.dgcore.service.PeriodRequest;
import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.Device;

import java.io.Serializable;
import java.util.*;

/**
 * Сервис расчета параметров статистики по работе устройств
 */
public interface WorkStatService extends ICalcJob {

    String NAME = "dgepu_WorkStatService";

    ParamInfo statTable = ParamInfo.ofDevice("stat", "all");

    /**
     * Параметры статистики по работе устройств
     */
    enum WorkStatParam {

        POLL_ERR, // Ошибка в журнале опроса
        JRN_ALARM, // Наличие тревог
        JRN_TAMPER; // Наличие вмешательств в устройство

        WorkStatParam() {
            valueInTable = new HashMap<>();
            valueInTable.put(name(), "1");
        };

        public final Map<String, String> valueInTable;
    }

    /**
     * Результат запроса c первым появлением DevStatParam за период
     */
    class FirstStatParamResult {

        private Long deviceId; // ID устройства

        private  Map<WorkStatParam, Date> params; // Наличие параметра и его первое появление за период

        public FirstStatParamResult(Long deviceId, Map<WorkStatParam, Date> params) {
            this.deviceId = deviceId;
            this.params = params;
        }

        public Long getDeviceId() {
            return deviceId;
        }

        public Map<WorkStatParam, Date> getParams() {
            return params;
        }
    }

    /**
     * @param periodRequest период
     * @param deviceIds список ID устройства
     * @param params параметры работоспособности
     * @return результаты FirtsStatParamAtResult
     */
    Map<Long,Map<WorkStatParam, Date>> getFirstStatParam(PeriodRequest periodRequest, Collection<Long> deviceIds, List<WorkStatParam> params);

    /**
     * Удалить статистику по работе устройств по указанным параметрам за период (при пересчете и др.)
     * @param periodRequest период
     * @param deviceIds ID устройств
     * @param params параметры для удаления
     * @return результат
     */
    RequestResult deleteWorkStatParams(PeriodRequest periodRequest, List<Long> deviceIds, List<WorkStatParam> params);

    void onLogMsgEvent(LogMsgEvent event);

    class WorkStat implements Serializable {
        private static final long serialVersionUID = 1L;
        public Date plannedConnectionTime;
        public Date realConnectionTime;
        public Long paramsAmount;
        public Long uniqueParamsAmount;

        @Override
        public String toString() {
            return StrUtils.toStr("WorkStat",
                    "plannedConnectionTime", plannedConnectionTime, "realConnectionTime", realConnectionTime, "paramsAmount", paramsAmount, "uniqueParamsAmount", uniqueParamsAmount);
        }
    }

    /**
     * Отчет о работоспособности
     */
    class WorkStatRep implements Serializable {
        private static final long serialVersionUID = 1L;

        public int total = 0; // Сколько сеансов связи ожидалось
        public int dataGot = 0; // Сколько сеансов связи завершилось передачей данных (любых)
        public Double gotPrc; // % Получения данных
        @Override
        public String toString() {
            return total == 0 ? "Неопределено" : String.format("%.1f%% ожидалось подключений: %d, получено данных: %d", gotPrc, total,  dataGot);
        }
    }

    default WorkStatRep getDataGetOnTimePrc(List<WorkStat> workStats) {
        WorkStatRep res = new WorkStatRep();
        if (workStats == null || workStats.isEmpty())
            return res;
        int total = 0;
        int dataGot = 0;
        for (WorkStat workStat : workStats) {
            total++;
            if (workStat.realConnectionTime != null && workStat.paramsAmount != null && workStat.paramsAmount > 0)
                dataGot++;
        }
        res.total = total;
        res.dataGot = dataGot;
        res.gotPrc =  ((double)dataGot / total) * 100;
        return res;
    }

    /**
     * Параметры расчета работоспособности
     */
    class WorkStatRequestParam implements Serializable {
        private static final long serialVersionUID = 1L;
        public Integer searchConnSecs;

        public WorkStatRequestParam(Integer searchConnSecs) {
            this.searchConnSecs = searchConnSecs;
        }

        @Override
        public String toString() {
            return StrUtils.toStr("WorkStatRequestParam",
                    "secondsToSearchConnection", searchConnSecs);
        }
    }

    /**
     * Метод для получения статистики работоспособности устройства
     * Находит ожидаемые моменты выхода устройства на связь по cron или опросам.
     * Далее ищет данные по периоду (определенный момент +- значение mp.device.secondsToSearchConnection)
     * @param periodRequest период для определения работоспособности
     * @param device устройство
     * @see WorkStat
     * @return список статистик по работоспособности на каждый ожидаемый момент выхода на связь (WorkStat.plannedConnectionTime)
     */
    List<WorkStat> workStatByRawData(PeriodRequest periodRequest, Device device);

    /**
     * Метод для получения статистики работоспособности устройства
     * Находит ожидаемые моменты выхода устройства на связь по cron или опросам.
     * Далее ищет данные по периоду (определенный момент +- secondsToSearchConnection)
     * @param periodRequest период для определения работоспособности
     * @param device устройство
     * @param workStatRequestParam параметр для задания диапазона поиска данных
     * @see WorkStat
     * @return список статистик по работоспособности на каждый ожидаемый момент выхода на связь (WorkStat.plannedConnectionTime)
     */
    List<WorkStat> workStatByRawData(PeriodRequest periodRequest, Device device, WorkStatRequestParam workStatRequestParam);
    
    /**
     * Получает статистику работоспособности устройства в определенный момент времени.
     * Ищет данные по периоду (определенный момент +- 5 минут).
     *
     * @param date Момент времени для получения данных
     * @param device
     * @return
     */
    WorkStat workStatByRawData(Date date, Device device);
}