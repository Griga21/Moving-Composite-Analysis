package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.DataPeriodicity;

public class MissedDataJobParams extends JobParams {
    private final String paramCode;
    private final Integer requestDeep;
    private final DataPeriodicity deepType;
    private final DataPeriodicity groupPeriodicity;

    public MissedDataJobParams(String serviceCode,
                               String deviceCode,
                               String groupCode,
                               String paramCode,
                               Integer requestDeep,
                               DataPeriodicity deepType,
                               boolean withCommHour,
                               DataPeriodicity groupPeriodicity) {
        super(serviceCode, deviceCode, groupCode, withCommHour);
        this.paramCode = paramCode;
        this.requestDeep = requestDeep;
        this.deepType = deepType;
        this.groupPeriodicity = groupPeriodicity;
    }

    public String getParamCode() {
        return paramCode;
    }

    public Integer getRequestDeep() {
        return requestDeep;
    }

    public DataPeriodicity getDeepType() {
        return deepType;
    }

    @Override
    public String toString() {
        return StrUtils.toStr("RealTimeJobParams", "serviceCode", getServiceCode(),
                "deviceCode", getDeviceCode(), "groupCode", getGroupCode(),
                "paramCode", getParamCode(), "requestDeep", getRequestDeep(), "deepType", getDeepType());
    }

    public DataPeriodicity getGroupPeriodicity() {
        return groupPeriodicity;
    }
}