package ru.mrgeng.digit.epu.service;

import java.util.Set;

public interface PollPriorityInfo {
    Long getId();

    Set<Long> getIgnoredPollIds();
}