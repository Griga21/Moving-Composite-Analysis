package ru.mrgeng.digit.epu.service;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;

public class ServiceDataChangedEvent extends GlobalApplicationEvent {

    String serviceName;

    String serviceData;

    /**
     * Create a new ApplicationEvent.
     *
     * @param source the object on which the event initially occurred (never {@code null})
     */
    public ServiceDataChangedEvent(Object source) {
        super(source);
    }

    public ServiceDataChangedEvent(Object source, String serviceName, String serviceData) {
        super(source);
        this.serviceName = serviceName;
        this.serviceData = serviceData;
    }

    @Override
    public String toString() {
        return "ServiceDataChangedEvent{" +
                "serviceName='" + serviceName + '\'' +
                ", serviceData='" + serviceData + '\'' +
                '}';
    }
}
