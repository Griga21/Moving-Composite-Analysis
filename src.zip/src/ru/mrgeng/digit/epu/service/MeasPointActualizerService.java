package ru.mrgeng.digit.epu.service;


import ru.mrgeng.digit.epu.mp.DeviceService;

import java.util.Map;
import java.util.Set;

/**
 * Сервис актуализации мест измерений, создаст недостающие места, и отредактирует метки
 * в текущих местах измерения, если это потребуется
 */
public interface MeasPointActualizerService {
    String NAME = "mp_MeasPointActualizerService";

    MeasPointActualizationResult actualizeAllService();

    MeasPointActualizationResult actualizeService(DeviceService service);

    MeasPointActualizationResult actualizeService(String serviceCode);

    /**
     * @param serviceCode код сервиса
     * @return список кодов актуальных(MeasPoint.isActual) мест измерения: код устройства -> коды мест измерения
     */
    Map<String, Set<String>> getActualLines(String serviceCode);
}