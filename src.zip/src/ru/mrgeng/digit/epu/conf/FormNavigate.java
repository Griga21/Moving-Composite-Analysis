package ru.mrgeng.digit.epu.conf;

/**
 * Интерфейс навигации форм
 */
public interface FormNavigate {

    void navigate(String path);

}
