package ru.mrgeng.digit.epu.dto;

import java.io.Serializable;

public class UnitConvertDto implements Serializable {

    private String paramCode;

    private String oldUnit;
    private String oldPrefix;
    private String selectUnit;
    private String selectPrefix;

    public String getParamCode() {
        return paramCode;
    }

    public void setParamCode(String paramCode) {
        this.paramCode = paramCode;
    }

    public String getOldUnit() {
        return oldUnit;
    }

    public void setOldUnit(String oldUnit) {
        this.oldUnit = oldUnit;
    }

    public String getOldPrefix() {
        return oldPrefix;
    }

    public void setOldPrefix(String oldPrefix) {
        this.oldPrefix = oldPrefix;
    }

    public String getSelectUnit() {
        return selectUnit;
    }

    public void setSelectUnit(String selectUnit) {
        this.selectUnit = selectUnit;
    }

    public String getSelectPrefix() {
        return selectPrefix;
    }

    public void setSelectPrefix(String selectPrefix) {
        this.selectPrefix = selectPrefix;
    }
}
