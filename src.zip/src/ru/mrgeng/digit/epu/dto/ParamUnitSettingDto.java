package ru.mrgeng.digit.epu.dto;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

public class ParamUnitSettingDto implements Serializable {
    /**
     * пример paramCode: Q
     */
    private String paramCode;
    /**
     * пример paramName: Q [М³/ч] Среднесуточный расход газа
     */
    private String paramFullName;

    private String oldPrefix;
    @NotNull
    private String oldUnit;
    private String newPrefix;
    @NotNull
    private String newUnit;
    private Integer accuracy;

    public ParamUnitSettingDto() {
    }

    public ParamUnitSettingDto(String paramCode, String paramFullName, String oldPrefix, String oldUnit, String newPrefix, String newUnit, Integer accuracy) {
        this.paramCode = paramCode;
        this.paramFullName = paramFullName;
        this.oldPrefix = oldPrefix;
        this.oldUnit = oldUnit;
        this.newPrefix = newPrefix;
        this.newUnit = newUnit;
        this.accuracy = accuracy;
    }

    @Override
    public String toString() {
        return "ParamUnitSettingDto{" +
                "paramCode='" + paramCode + '\'' +
                ", paramName='" + paramFullName + '\'' +
                ", oldPrefix='" + oldPrefix + '\'' +
                ", oldUnit='" + oldUnit + '\'' +
                ", newPrefix='" + newPrefix + '\'' +
                ", newUnit='" + newUnit + '\'' +
                ", accuracy=" + accuracy +
                '}';
    }

    public static Builder builder() {
        return new Builder();
    }


    //region getterSetter
    public String getParamCode() {
        return paramCode;
    }

    public void setParamCode(String paramCode) {
        this.paramCode = paramCode;
    }

    public String getParamFullName() {
        return paramFullName;
    }

    public void setParamFullName(String paramFullName) {
        this.paramFullName = paramFullName;
    }

    public String getOldPrefix() {
        return oldPrefix;
    }

    public void setOldPrefix(String oldPrefix) {
        this.oldPrefix = oldPrefix;
    }

    public String getOldUnit() {
        return oldUnit;
    }

    public void setOldUnit(String oldUnit) {
        this.oldUnit = oldUnit;
    }

    public String getNewPrefix() {
        return newPrefix;
    }

    public void setNewPrefix(String newPrefix) {
        this.newPrefix = newPrefix;
    }

    public String getNewUnit() {
        return newUnit;
    }

    public void setNewUnit(String newUnit) {
        this.newUnit = newUnit;
    }

    public Integer getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(Integer accuracy) {
        this.accuracy = accuracy;
    }
    //endregion


    public static class Builder {

        private String paramCode;
        private String paramName;

        private String oldPrefix;
        private String oldUnit;
        private String newPrefix;
        private String newUnit;
        private Integer accuracy;

        public Builder paramCode(String paramCode) {
            this.paramCode = paramCode;
            return this;
        }

        public Builder paramName(String paramName) {
            this.paramName = paramName;
            return this;
        }

        public Builder oldPrefix(String oldPrefix) {
            this.oldPrefix = oldPrefix;
            return this;
        }

        public Builder oldUnit(String oldUnit) {
            this.oldUnit = oldUnit;
            return this;
        }

        public Builder newPrefix(String newPrefix) {
            this.newPrefix = newPrefix;
            return this;
        }

        public Builder newUnit(String newUnit) {
            this.newUnit = newUnit;
            return this;
        }

        public Builder accuracy(Integer accuracy) {
            this.accuracy = accuracy;
            return this;
        }

        public ParamUnitSettingDto build() {
            return new ParamUnitSettingDto(paramCode, paramName, oldPrefix, oldUnit, newPrefix, newUnit, accuracy);
        }
    }
}