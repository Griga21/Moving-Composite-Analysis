package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface ArchiveRecalcConfig extends Config {

    @Property("calc.h2d.avgParamsRules")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("p-p|t-t|Kkorr-Kkorr|dP-dP|Qo-Qo")
    List<String> getDayAvgRules();

    @Property("calc.h2d.maxParamsRules")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("vs-vs|Vbt-Vbt")
    List<String> getDayMaxRules();

    @Property("calc.h2d.diffParamsRules")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("vs-v|Vbt-vr")
    List<String> getDayDiffRules();

    @Property("calc.h2d.accDayDiffParamsRules")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("vs-v|Vbt-vr")
    List<String> getAccDayDiffRules();

    @Property("calc.h2d.sumParamsRules")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("v-v")
    List<String> getDaySumRules();


}
