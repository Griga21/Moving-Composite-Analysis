package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface SkzDevFormConfig extends Config, DevFormConfig {

    @Default("P10D")
    @Property("mp.skz.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("line1")
    @Property("mp.skz.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("skz")
    @Property("mp.skz.defGroup")
    String getDevDefGroup();

    @Property("mp.skz.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("Current|Voltage")
    List<String> getDevDefParams();

    @Property("mp.skz.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.SKZ_CODE;
    }
}