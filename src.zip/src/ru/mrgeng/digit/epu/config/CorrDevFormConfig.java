package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface CorrDevFormConfig extends Config, DevFormConfig {

    @Default("P10D")
    @Property("mp.corr.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("line1")
    @Property("mp.corr.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("arc_d")
    @Property("mp.corr.defGroup")
    String getDevDefGroup();

    @Property("mp.corr.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("v")
    List<String> getDevDefParams();

    @Property("mp.corr.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.CORR_CODE;
    }

    @Override
    default boolean isHasLines() {
        return true;
    }
}