package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface DeviceMapFragConfig extends Config {

    @Property("map.devfrag.corrShowParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("arc_d.v|arc_d.p|arc_d.t")
    List<String> getCorrShowParams();

    @Property("map.devfrag.chroShowParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("chro_d.metan")
    List<String> getChroShowParams();

    @Property("map.devfrag.prgShowParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("")
    List<String> getPrgShowParams();

    @Property("map.devfrag.skzShowParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("")
    List<String> getSkzShowParams();

    @Property("map.devfrag.smartShowParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("")
    List<String> getSmartShowParams();

    @Default("3600000")
    @Property("map.devfrag.defNoDataMs")
    Integer getDefNoDataMs();

    @Default("17")
    @Property("map.devfrag.disableClustOnZoom")
    Integer getDisableClustOnZoom();

}