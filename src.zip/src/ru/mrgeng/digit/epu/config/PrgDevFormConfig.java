package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface PrgDevFormConfig extends Config, DevFormConfig {

    @Default("P10D")
    @Property("mp.prg.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("NO_MEAS_POINT")
    @Property("mp.prg.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("prg_cur")
    @Property("mp.prg.defGroup")
    String getDevDefGroup();

    @Property("mp.prg.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("prg_p_in|prg_p_out|prg_t_gaz")
    List<String> getDevDefParams();

    @Property("mp.prg.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.PRG_CODE;
    }
}