package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.defaults.DefaultInteger;
import com.haulmont.cuba.core.config.defaults.DefaultString;
import com.haulmont.cuba.core.global.Secret;

@Source(type = SourceType.DATABASE)
public interface WidgetConfig extends Config {

/*    @DefaultString("ksasliJW9LfU0AuJ5xLG4WlTdPs")
    @Secret
    @Property("widget.accessToken")
    String getAccessToken();*/

    @Default("30000")
    @Property("виджеты.время.удерживания")
    Integer getHoldPeriod();

    @Default("20000")
    @Property("виджеты.период.обновления")
    Integer getUpdatePeriod();

    @Default("5000")
    @Property("виджеты.период.обновления.приудержании")
    Integer getHoldUpdatePeriod();

    @Default("230")
    @Property("виджеты.ширина")
    Integer getDefaultWidth();

    @Default("180")
    @Property("виджеты.высота")
    Integer getDefaultHeight();

    @DefaultInteger(14)
    @Property("виджеты.размер.название")
    Integer getWidgetNameSize();

    @DefaultInteger(1000)
    @Property("виджеты.размер.основная.область")
    Integer getWidgetMainAreaSize();

    @DefaultInteger(29)
    @Property("виджеты.размер.значения")
    Integer getWidgetValueSize();

    @DefaultInteger(18)
    @Property("виджеты.размер.измерение")
    Integer getWidgetUnitSize();
}