package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface ControllerRGCConfig extends Config, DevFormConfig {

    @Default("P10D")
    @Property("mp.controller.rgc.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("NO_MEAS_POINT")
    @Property("mp.controller.rgc.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("rgc_alarm")
    @Property("mp.controller.rgc.defGroup")
    String getDevDefGroup();

    @Property("mp.controller.rgc.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("rgc_d4")
    List<String> getDevDefParams();

    @Property("mp.controller.rgc.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.CONTROLLER_RGC_CODE;
    }
}