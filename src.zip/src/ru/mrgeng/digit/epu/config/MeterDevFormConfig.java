package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface MeterDevFormConfig extends Config, DevFormConfig {

    @Default("P5D")
    @Property("mp.meter.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("")
    @Property("mp.meter.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("smart_arc_d")
    @Property("mp.meter.defGroup")
    String getDevDefGroup();

    @Property("mp.meter.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("v")
    List<String> getDevDefParams();

    @Property("mp.meter.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("smart_arc_d.vs")
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.SMART_CODE;
    }

    @Override
    default boolean isShowConnectedDev() {
        return false;
    }
}