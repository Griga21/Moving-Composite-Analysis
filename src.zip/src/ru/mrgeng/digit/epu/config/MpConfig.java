package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.defaults.DefaultBoolean;
import com.haulmont.cuba.core.config.defaults.DefaultInteger;
import com.haulmont.cuba.core.config.defaults.DefaultLong;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.configtype.StringSetStringify;
import ru.mrgeng.digit.epu.mp.configtype.StringSetTypeFactory;
import ru.mrgeng.digit.epu.service.DeviceEventService;

import java.util.List;
import java.util.Set;

@Source(type = SourceType.DATABASE)
public interface MpConfig extends Config {
    String FRIEND_OR_FOE_PARAM_CODE_NAME = "mp.friendOrFoeParamCode";
    String BTN_FOREIGN_PARAM_CODES_NAME = "mp.buttonForeignParamCodes";
    String DOOR_PARAM_CODES_NAME = "mp.doorParamCodes";

    // политика создания периода опроса устройства по умолчанию, у политики есть номер (сейчас существует только одна политика, под номером №1)
    // политика №1 - создается только 1 запрос для каждого устройства включайщий период с первой пропущенной даты - по последнюю
    @Default("1")
    @Property("mp.missedVal.defaultPeriodPolitic")
    Integer getMissedValDefaultPeriodPolitic();

    @Property("mp.DDK.updateRate")
    @Default("19999")
    Integer getDDKUpdateRate();

    @Property("mp.h2d.calcAvgParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("p|t|Kkorr")
    List<String> getH2DCalcAvgParams();

    // Запустить планировщик опроса данных для сервисов (перечисляются через запятую)
    @Deprecated
    @Default("")
    @Property("mp.runPollForServices")
    String getRunPollForServices();// после того как все на проде перейдут на новый способ конфигурирования опроса - удалить это свойство (предположительно после 30.09.2022)

    // ID СВУ по умолчанию для установки в формах
    @Default("1")
    @Property("mp.defaultDeviceService")
    Long getDefaultDeviceService();

    // Код группы приведенных параметров по умолчанию для установки в формах // todo: Удалить?
    @Default("arc_d")
    @Property("mp.defaultCalcParamGroup")
    String getDefaultCalcParamGroup();

    // Код группы исходных параметров по умолчанию для установки в формах
    @Default("line1.SS")
    @Property("mp.defaultRawParamGroup")
    String getDefaultRawParamGroup();

    // Кол-во попыток повтора отправки команды в СВУ
    @Default("3")
    @Property("mp.retryCmdAttempts")
    Integer getRetryCmdAttempts();

    // КТаймаут между повторной  отправкой команды в СВУ
    @Default("20000")
    @Property("mp.retryCmdToutMs")
    Integer getRetryCmdToutMs();

    // Маскимальное кол-во одновременно выполняемых команд по одному устройству в СВУ
    @Default("-1")
    @Property("mp.devMaxProcCmds")
    Integer getDevMaxProcCmds();

    // Таймаут выполнения команды в СВУ, отправленной оператором
    @Default("900000")
    @Property("mp.svdCmdTimeoutMs")
    Integer getSvdCmdTimeoutMs();

    @Default("true")
    @Property("mp.showDevDashboards")
    boolean isShowDevDashboards();

    // Период данных по умолчанию в форме "Данные по устройствам"
    @Default("P2D")
    @Property("mp.formDeviceDataPeriod")
    String getFormDeviceDataPeriod();

    // Порог периода в днях, при превышении которого выводится предупреждение для суточных архивов
    @DefaultInteger(90)
    @Property("mp.deviceData.dayArchiveWarningPeriodDays")
    Integer getDeviceDataDayArchiveWarningPeriodDays();

    // Порог периода в днях, при превышении которого выводится предупреждение для часовых архивов
    @DefaultInteger(5)
    @Property("mp.deviceData.hourArchiveWarningPeriodDays")
    Integer getDeviceDataHourArchiveWarningPeriodDays();

    // Коммерческий час в компании, это час в часовом поясе компании, соответсвующий 10 часам по Москве
    @Default("10")
    @Property("mp.commHours")
    Integer getCommHours();

    // Данные(группа) по умным счетчикам. Для публикации в API ИСУГ.
    @Default("smart_arc_d")
    @Property("mp.smartDataGroup")
    String getSmartDataGroup();

    // Коды сервисов смарт-счетчиков через запятую по умолчанию. Для публикации в API по Смарт-счертчикам.
    @Property("mp.smartServices")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("1")
    List<String> getSmartServices();

    @Property("mp.hourCountStatisticConfig")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("arc_h:v,vs,vr,Vbt,Vo->arc_d|chro_h->chro_d")
    List<String> getHourCountStatisticConfig();

    @Property("mp.dayStringCountStatisticJsonConfig")
    @Default("")
    String getDayStringCountStatisticJsonConfig();

    @Property("mp.alarmGroups")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("c_alarm|prg_events|ga")
    List<String> getAlarmGroups();

    @Property("mp.gpsDevTypesList")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("5")
    List<String> getGpsDevTypes();

    @Property("mp.groDevTypesList")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("2|skz|za")
    List<String> getGroDevTypes();

    @Property("mp.rgkDevTypesList")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("1|3|4|6")
    List<String> getRgkDevTypes();

    @Default("P10D")
    @Property("mp.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("CC.МАК-ПГПv2_КП1Sostoyanie_krana")
    @Property("mp.keyLastData.za")
    String getKeyLastDataZA();

    @Default("CC.ns=3;s=2:cks7i69xr0vmp19ptd7jkbj0g?QA_PREASS")
    @Property("mp.keyLastData.uorg")
    String getKeyLastDataUORG();

    @Default("CC.skz0000000001actualMeasured_ValuesCurrent")
    @Property("mp.keyLastData.skz")
    String getKeyLastDataSKZ();

    // Роль для мониторинга событий по устройствам
    @Default("event-monitoring-role")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Property("mp.deviceEventMonRole")
    List<String> getDeviceEventMonRole();

    //роль диспетчера
    @Default("disp-role|dispatcherGRO")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Property("mp.dispatcherRole")
    List<String> getDispatcherRole();

    //роль диспетчера РГК
    @Default("epu-rgk-disp")
    @Property("mp.dispatcherRgcRole")
    String getDispatcherRgcRole();

    @Default("1000")//
    @Property("mp.treeMapWidgetsTimer")
    Integer getTreeMapWidgetsTimerDelay();

    @Default("false")
    @Property("mp.statusLogger")
    boolean getStatusLogger();

    @Default("true")
    @Property("mp.useDispShiftWarning")
    boolean getUseDispShiftWarning();

    @Default("12")
    @Property("mp.dispShiftWarningHoursDelta")
    Long getDispShiftWarningHoursDelta();

    // Группировка исходных данных по paramTime
    @Default("false")
    @Property("mp.useRawDataGrouping")
    boolean getUseRawDataGrouping();

    @Default("Circle")
    @Property("mp.treeStatusIcons")
    String getTreeStatusIcons();

    @Default("za_alarm door 1 30 za_alarm svch 1")
    @Property("mp.unauthEventPattern")
    String getUnauthEventPattern();

    @DefaultLong(value = 120000)
    @Property("mp.device.timeOutMs")
    Long getDeviceTimeOutMs();// Таймаут ожидания поступления данных после истечения времени получения данных, по истечению которого формируется событие NO_DATA

    @DefaultBoolean(value = true)
    @Property("mp.enableNoDataEventMonitoring")
    boolean isEnableNoDataEventMonitoring(); // Включение/выключение отправки ивента NO_DATA

    @DefaultInteger(value = 1_000)
    @Property("mp.driver.transformCopyMax")
    Integer getDriverTransformCopyMax(); // ограничение максимального числа драйверов-потребителей, участвующих в массовом переносе трансформаций

    @DefaultInteger(value = 1_000)
    @Property("mp.driver.driverDownloadLimit")
    Integer getDriverDownloadLimit(); // ограничение максимального числа драйверов при массовом скачивании

    /**
     * Период ожидания между проверками, на наличие ожидающих актуализации Сервисов сбора данных,
     * отложен старт первой проверки на это-же время,
     * проверка происходит только для сервисов для которых была применена конфигурация
     */
    @DefaultLong(value = 20)
    @Property("mp.schedule.actualizeMeasPointPeriodSeconds")
    Long getScheduleMeasPointActualizePeriodSeconds();

    @Property("mp.reversDifParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("v|vs|Vbt")
    List<String> getReversDifParams();

    /**
     * Число дней, спустя которое событие считается устаревшим, и не кешируется при первой загрузке
     *
     * @return целое число
     */
    @DefaultInteger(value = DeviceEventService.DAY_LIMIT_DEFAULT)
    @Property("mp.event.deepLoadInDay")
    Integer getEventDeepLoadInDay();

    @Default("Дополнительные параметры")
    @Property("mp.categoryDynamicAttribute")
    String getCategotyDynamicAttribute();

    @Default("true")
    @Property("mp.showCompanyFilter")
    boolean isShowCompanyFilter();

    @Default("")
    @Property("mp.grafanaUrl")
    String getGrafanaUrl();

    @Default("10")
    @Property("mp.device.daysToSearchLastConnection")
    Integer getDaysToSearchLastConnection();

    // Интервал(по умолчанию) выхода на связь устройства относительно планового времени
    @Default("300")
    @Property("mp.device.intervalForPlanConnSec")
    Integer getIntervalForPlanConnSec();

    @Default("60000")
    @Property("control.screen.updatePeriod")
    Integer getControlScreenUpdatePeriod();

    @Default("30.195859")
    @Property("mp.map.centerX")
    Double getMapCenterX();

    @Default("59.974141")
    @Property("mp.map.centerY")
    Double getMapCenterY();

    @Default("administratorRGKRole|engineerMetrologistRGKRole|system-full-access")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Property("mp.typed.kp.roles")
    List<String> getKpControlButtonRoles();

    @Default("30000")
    @Property("chart.limit")
    Integer getChartLimit();

    //показывать ли кнопку  3reports в DeviceDataButtonFragment, делалось для Йошкар-Олы
    @Default("false")
    @Property("mp.show3reports")
    boolean getShow3Reports();

    @Default("2")
    @Property("hoursToAdd")
    String getHoursToAdd();

    @Default("1")
    @Property("yearsToAdd")
    String getYearsToAdd();

    @Default("48")
    @Property("mp.minusHours")
    Integer getMinusHours();

    @Default("0")
    @Property("mp.delayToUnscrewSecurityButton")
    long getDelayToUnscrewSecurityButton();

    @Default("gro_alarm.gro_svch")
    @Property(FRIEND_OR_FOE_PARAM_CODE_NAME)
    String getFriendOrFoeParamCode();

    @Default("gro_alarm.foreign|skzp_alarm.foreign_skzp")
    @Factory(factory = StringSetTypeFactory.class)
    @Stringify(stringify = StringSetStringify.class)
    @Property(BTN_FOREIGN_PARAM_CODES_NAME)
    Set<String> getBtnForeignParamCodes();

    @Default("za_alarm.door|gro_alarm.dr_boiler1|rgc_alarm.rgc_door_open|gro_alarm.dr_redux3|gro_alarm.dr_redux4|" +
            "za_alarm.door_pl_2|gro_alarm.dr_redux|gro_alarm.Door_skz|gro_alarm.door_open|gro_alarm.dr_kip|" +
            "za_alarm.door_pl_1|gro_alarm.dr_redux2|skzp_alarm.dr_skzp|gro_alarm.dr_tm|gro_alarm.dr_purg1")
    @Factory(factory = StringSetTypeFactory.class)
    @Stringify(stringify = StringSetStringify.class)
    @Property(DOOR_PARAM_CODES_NAME)
    Set<String> getDoorParamCodes();

    @DefaultInteger(10000)
    @Property("mp.event.update.period")
    Integer getEventUpdatePeriod();

    @Default("true")
    @Property("mp.buttonForeignFixed")
    boolean isFixedBtnForeign();

    @Default("true")
    @Property("mp.skzCheckZeroOrByPrev")
    boolean isSkzCheckZeroOrByPrev();

    @DefaultInteger(1440) //По умолчанию 60 дней
    @Property("mp.inactiveObjectReportPeriod")
    Integer getInactiveObjectReportPeriod();

    //нужно ли отправлять на почту письмо о новом событии
    @Default("false")
    @Property("mp.sendDeviceEventResponseMsg")
    boolean getSendDeviceEventResponseMsg();
}