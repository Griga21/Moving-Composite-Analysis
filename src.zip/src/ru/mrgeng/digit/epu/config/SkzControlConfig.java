package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;

@Source(type = SourceType.DATABASE)
public interface SkzControlConfig extends Config {

    @Default("skz_cur")
    @Property("skzControl.groupCode")
    String getSkzParamsGroupCode();

    @Default("Power_unit")
    @Property("skzControl.powerBlock")
    String getSkzPowerBlockCode();

    @Default("skz_alarm")
    @Property("skzControl.alarmGroupCode")
    String getSkzAlarmGroupCode();
}