package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.defaults.DefaultBoolean;

@Source(type = SourceType.APP)
public interface AppSettingsConfig extends Config {

    @Default("DeviceDataKeeperNG")
    @Property("mp.ddKeeper")
    String getDdKeeper();

    @DefaultBoolean(value = false)
    @Property("mp.isProcessQueuedEmails")
    boolean isProcessQueuedEmails();
}