package ru.mrgeng.digit.epu.config;

import java.util.List;

public interface DevFormConfig {

    String getFormScreenPeriod();

    String getDevDefMeasPoint();

    String getDevDefGroup();

    List<String> getDevDefParams();

    List<String> getDefParamsForScreen();

    /**
     * @return Параметр по умолчанию для расчета полноты поступления данных
     */
    default String getCompletnessParam() {
        return "v";
    }

    /**
     * @return Код типа устройства
     */
    String getDeviceType();

    /**
     * @return Есть ли линии измерения у устройства
     */
    default boolean isHasLines() {
        return false;
    }

    /**
      * @return Показывать устройства, к которым подключены эти устройства
     */
    default boolean isShowConnectedDev() {
        return true;
    }

}
