package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface ChroDevFormConfig extends Config, DevFormConfig {

    @Default("P10D")
    @Property("mp.chro.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("line1")
    @Property("mp.chro.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("chro_d")
    @Property("mp.chro.defGroup")
    String getDevDefGroup();

    @Property("mp.chro.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("m_metan")
    List<String> getDevDefParams();

    @Property("mp.chro.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.CHRO_CODE;
    }
}