package ru.mrgeng.digit.epu.config;

import com.haulmont.cuba.core.config.Config;
import com.haulmont.cuba.core.config.Property;
import com.haulmont.cuba.core.config.Source;
import com.haulmont.cuba.core.config.SourceType;
import com.haulmont.cuba.core.config.defaults.Default;
import com.haulmont.cuba.core.config.type.Factory;
import com.haulmont.cuba.core.config.type.StringListStringify;
import com.haulmont.cuba.core.config.type.StringListTypeFactory;
import com.haulmont.cuba.core.config.type.Stringify;
import ru.mrgeng.digit.epu.mp.DeviceType;

import java.util.List;

@Source(type = SourceType.DATABASE)
public interface AdDevFormConfig  extends Config, DevFormConfig  {

    @Default("P10D")
    @Property("mp.ad.formScreenPeriod")
    String getFormScreenPeriod();

    @Default("")
    @Property("mp.ad.defMeasPoint")
    String getDevDefMeasPoint();

    @Default("ad_c")
    @Property("mp.ad.defGroup")
    String getDevDefGroup();

    @Property("mp.ad.defParams")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    @Default("p|t")
    List<String> getDevDefParams();

    @Property("mp.ad.defParamsForScreen")
    @Factory(factory = StringListTypeFactory.class)
    @Stringify(stringify = StringListStringify.class)
    List<String> getDefParamsForScreen();

    @Override
    default String getDeviceType() {
        return DeviceType.AD_CODE;
    }
}