package ru.mrgeng.digit.epu.param;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

/**
 * Цвет параметра на графике
 */

public enum ParamColor implements EnumClass<String> {
    AQUA("AQUA"),
    AQUAMARINE("AQUAMARINE"),
    BLACK("BLACK"),
    BLUE("BLUE"),
    BLUEVIOLET("BLUEVIOLET"),
    BROWN("BROWN"),
    CADETBLUE("CADETBLUE"),
    CHARTREUSE("CHARTREUSE"),
    CHOCOLATE("CHOCOLATE"),
    CORAL("CORAL"),
    CORNFLOWERBLUE("CORNFLOWERBLUE"),
    CRIMSON("CRIMSON"),
    CYAN("CYAN"),
    DARKORCHID("DARKORCHID"),
    DARKBLUE("DARKBLUE"),
    DARKCYAN("DARKCYAN"),
    DARKGOLDENROD("DARKGOLDENROD"),
    DARKGREEN("DARKGREEN"),
    DARKMAGENTA("DARKMAGENTA"),
    DARKOLIVEGREEN("DARKOLIVEGREEN"),
    //DARKORANGE("DARKORANGE"), //порог
    DARKRED("DARKRED"),
    DARKVIOLET("DARKVIOLET"),
    DEEPSKYBLUE("DEEPSKYBLUE"),
    DARKSLATEBLUE("DARKSLATEBLUE"),
    DARKSLATEGRAY("DARKSLATEGRAY"),
    DODGERBLUE("DODGERBLUE"),
    FUCHSIA("FUCHSIA"),
    GOLD("GOLD"),
    GREEN("GREEN"),
    GREENYELLOW("GREENYELLOW"),
    HOTPINK("HOTPINK"),
    INDIGO("INDIGO"),
    LIME("LIME"),
    LIMEGREEN("LIMEGREEN"),
    ORANGE("ORANGE"),
    //RED("RED"), //порог
    TOMATO("TOMATO"),
    VIOLET("VIOLET"),
    YELLOW("YELLOW"),
    SEAGREEN("SEAGREEN"),
    POWDERBLUE("POWDERBLUE"),
    SADDLEBROWN("SADDLEBROWN"),
    STEELBLUE("STEELBLUE"),
    SIENNA("SIENNA"),
    TEAL("TEAL"),
    OLIVEDRAB("OLIVEDRAB"),
    NAVY("NAVY"),
    MIDNIGHTBLUE("MIDNIGHTBLUE"),
    MEDIUMVIOLETRED("MEDIUMVIOLETRED"),
    MEDIUMBLUE("MEDIUMBLUE"),
    MAROON("MAROON");

    private String id;

    ParamColor(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ParamColor fromId(String id) {
        for (ParamColor at : ParamColor.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}