package ru.mrgeng.digit.epu.param;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;
import java.io.Serializable;

/**
 * Уровни важности(серьезности) событий, сообщений
 */
public enum SeriousLevel implements EnumClass<Integer>, Serializable {

    NORMALIZE(0),// снятие события
    INFO(10),  // Для информации
    WARN(20),  // Предупреждение
    ALARM(30); // Тревога

    private Integer id;

    SeriousLevel(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static SeriousLevel fromId(Integer id) {
        for (SeriousLevel at : SeriousLevel.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}