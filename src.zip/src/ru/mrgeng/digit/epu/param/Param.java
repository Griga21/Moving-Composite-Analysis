package ru.mrgeng.digit.epu.param;

import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.mp.ParamDisplay;
import ru.mrgeng.digit.epu.mp.DiscreteAlarm;
import ru.mrgeng.digit.epu.mp.ParamGrouping;
import ru.mrgeng.digit.epu.service.CodeNameObj;


import java.util.Objects;

/*
    Параметр
 */
public class Param extends CodeNameObj {
    private static final long serialVersionUID = 1L;
    public String type; // Код типа параметра
    public Long internalId; // Внутренний id
    public String metricPrefix; // Множитель
    public String unit; // Ед. изм.
    public String designation; //условное обозначение
    public String groupCode; // Код группы параметров
    public DataFormat format; // Формат
    public ParamColor color;
    public DiscreteAlarm alarmSign;
    public ParamGrouping paramGrouping;
    public ParamDisplay paramDisplay;

    /**
     * @return Название параметра для отображения в интерфейсе
     */
    public String displayName() {
        if (designation != null)
            return designation;
        else
            return name != null ? name : groupAndParam();
    }

    public String getDisplayName() {
        return designation != null ? designation : name != null ? name : code;
    }
    
    public DataFormat getFormat() {
        return format;
    }
    
    /**
     * @return группа и код параметра
     */
    public String groupAndParam() {
        return groupCode + '.' + code;
    }

    /**
     * @param obj значение
     * @return вывод значения параметра в строку
     */
    public String toStr(Object obj) {
        if (obj == null)
            return "";
        if (format != null)
            return format.toStr(obj);
        else
            return obj.toString();
    }

    @Override
    public String toString() {
        return StrUtils.toStr("Param", "code", code, "name", name, "type", type, "prefix", metricPrefix, "unit", unit, "id", internalId);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Param param = (Param) o;
        return Objects.equals(type, param.type) &&
                Objects.equals(internalId, param.internalId) &&
                Objects.equals(metricPrefix, param.metricPrefix) &&
                Objects.equals(unit, param.unit) &&
                Objects.equals(designation, param.designation) &&
                Objects.equals(groupCode, param.groupCode) &&
                format == param.format &&
                color == param.color &&
                Objects.equals(alarmSign, param.alarmSign);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), type, internalId, metricPrefix, unit, designation, groupCode, format, color, alarmSign);
    }

    public Param(String code, String name) {
        super(code, name);
    }

    public Param() { super(); }
}
