package ru.mrgeng.digit.epu.param;

import com.haulmont.chile.core.datatypes.impl.EnumClass;
import org.slf4j.Logger;

import javax.annotation.Nullable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Формат данных
 */
public enum DataFormat implements EnumClass<String> {
    INT_DG(new NumFormat("###,###")),
    ONE_DG_AP(new NumFormat("###,###.#")),
    TWO_DG_AP(new NumFormat("###,###.##")),
    THREE_DG_AP(new NumFormat("###,###.###")),
    OPEN_STAT(new OpenFormat()),
    AXI_OPEN_STAT(new AxiOpenFormat()),
    OPEN_INV_STAT(new OpenInvFormat()),
    NO_YES_STAT(new NoYesFormat()),
    YES_NO_STAT(new YesNoFormat()),
    OPEN_UNDF(new OpenUndefinedFormat()),
    NORM_GAS(new NormGasFormat()),
    NORM_BREAK(new NormBreakFormat()),
    NORM_ACC(new NormAccFormat()),
    ACC_NORM(new AccNormFormat()),
    US_THEM(new UsThem()),
    THEM_US(new ThemUs()),
    SEC_SERV(new SecurityService()),
    SERV_SEC(new ServiceSecurity()),
    ON_OFF(new OnOff()),
    MAIN_OR_RESERV(new MainOrReserv()),
    OFF_ON(new OffOn()),
    DIST_LOCAL(new DistLocal()),
    LOCAL_DIST(new LocalDist()),
    SUM_POL(new SumPol()),
    POL_SUM(new PolSum()),
    FIRST_THRESHOLD(new FirstThreshold()),
    SECOND_THRESHOLD(new SecondThreshold()),
    OPEN_INV_STAT_1(new OpenInvFormat1()),
    OPEN_INV_STAT_2(new OpenInvFormat2()),
    NORM_OFF(new NormOff()),
    NORM_FIRE(new NormFire()),
    NORM_FAULT(new NormFault()),
    NORM_ACB(new NormACB()),
    NORM_FLOOD(new NormFlood()),
    READY_NOTREADY(new ReadyNotReady()),
    OPEN_INV_STAT_3(new OpenInvFormat3()),
    POLL_NO(new PollNo()),
    CHARGE_NO(new ChargeNo()),
    CLOSES_NO(new ClosesNo()),
    OPENS_NO(new OpensNo()),
    VALVE_ALL_STATES(new ValveAllStates()),
    FRIEND_OR_FOE(new FriendOrFoe());

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(DataFormat.class);

    public interface BaseFormat {
        /**
         * @param obj значение
         * @return отформатированное значение
         */
        String format(Object obj);
    }

    private final String id;

    private final BaseFormat format;

    DataFormat(BaseFormat format) {
        this.id = name();
        this.format = format;
    }

    public String getId() {
        return id;
    }

    public String toStr(Object obj) {
        if (obj == null)
            return "";
        try {
            return format.format(obj);
        } catch (Throwable t) {
            log.error("DataFormat " + this.getId() + " error: " + t.getMessage());
        }
        return obj.toString();
    }

    public boolean isNumFormat() {
        return format instanceof NumFormat;
    }

    public DecimalFormat getDecimalFormat() {
        if (!isNumFormat()) {
            return null;
        }
        return ((NumFormat) format).decFormat;
    }

    @Nullable
    public static DataFormat fromId(String id) {
        for (DataFormat at : DataFormat.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }

    static class NumFormat implements BaseFormat {
        private final DecimalFormat decFormat;
        private static final Locale RU_LOCALE = new Locale("ru");

        public NumFormat(String format) {
            DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(RU_LOCALE);
            symbols.setGroupingSeparator(' ');
            symbols.setDecimalSeparator(',');
            this.decFormat = new DecimalFormat(format, symbols);
            this.decFormat.setGroupingUsed(false);
        }

        @Override
        public String format(Object obj) {
            return decFormat.format(obj);
        }
    }

    static class NoYesFormat implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Да";
                case "1":
                    return "Нет";
                default:
                    return obj.toString();
            }
        }
    }

    static class YesNoFormat implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Нет";
                case "1":
                    return "Да";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpenFormat implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Закрыто";
                case "1":
                    return "Открыто";
                default:
                    return obj.toString();
            }
        }
    }

    static class AxiOpenFormat implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "1":
                    return "Закрыто";
                case "2":
                    return "Открыто";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpenInvFormat implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Открыто";
                case "1":
                    return "Закрыто";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpenUndefinedFormat implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Открыто";
                case "1":
                    return "Не определено";
                case "2":
                    return "Закрыто";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormGasFormat implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Газ";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormBreakFormat implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Разрыв цепи";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormAccFormat implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Авария";
                default:
                    return obj.toString();
            }
        }
    }

    static class AccNormFormat implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Авария";
                case "1":
                    return "Норма";
                default:
                    return obj.toString();
            }
        }
    }

    static class UsThem implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Свой";
                case "1":
                    return "Чужой";
                default:
                    return obj.toString();
            }
        }
    }

    static class ThemUs implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Чужой";
                case "1":
                    return "Свой";
                default:
                    return obj.toString();
            }
        }
    }

    static class SecurityService implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Охрана";
                case "1":
                    return "Сервис";
                default:
                    return obj.toString();
            }
        }
    }

    static class ServiceSecurity implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Сервис";
                case "1":
                    return "Охрана";
                default:
                    return obj.toString();
            }
        }
    }

    static class OnOff implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Вкл";
                case "1":
                    return "Выкл";
                default:
                    return obj.toString();
            }
        }
    }

    static class MainOrReserv implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Осн.(GPRS)";
                case "1":
                    return "Рез.(CSD)";
                default:
                    return obj.toString();
            }
        }
    }

    static class OffOn implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Выкл";
                case "1":
                    return "Вкл";
                default:
                    return obj.toString();
            }
        }
    }

    static class DistLocal implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Дист.";
                case "1":
                    return "Мест.";
                default:
                    return obj.toString();
            }
        }
    }

    static class LocalDist implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Мест.";
                case "1":
                    return "Дист.";
                default:
                    return obj.toString();
            }
        }
    }

    static class SumPol implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Сумм.";
                case "1":
                    return "Поляр.";
                default:
                    return obj.toString();
            }
        }
    }

    static class PolSum implements BaseFormat {
        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Поляр.";
                case "1":
                    return "Сумм.";
                default:
                    return obj.toString();
            }
        }
    }

    static class FirstThreshold implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "1 порог";
                default:
                    return obj.toString();
            }
        }
    }

    static class SecondThreshold implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "2 порог";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpenInvFormat1 implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Открыт";
                case "1":
                    return "Закрыт";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpenInvFormat2 implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Открыта";
                case "1":
                    return "Закрыта";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormOff implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Отключено";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormFire implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Пожар";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormFault implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Неиспр.";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormACB implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "АКБ";
                default:
                    return obj.toString();
            }
        }
    }

    static class NormFlood implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Норма";
                case "1":
                    return "Потоп";
                default:
                    return obj.toString();
            }
        }
    }

    static class ReadyNotReady implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Не готов";
                case "1":
                    return "Готов";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpenInvFormat3 implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Закрыт";
                case "1":
                    return "Открыт";
                default:
                    return obj.toString();
            }
        }
    }

    static class PollNo implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Нет";
                case "1":
                    return "Идет опрос";
                default:
                    return obj.toString();
            }
        }
    }

    static class ChargeNo implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Нет";
                case "1":
                    return "Идет заряд";
                default:
                    return obj.toString();
            }
        }
    }

    static class ClosesNo implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Нет";
                case "1":
                    return "Закрывается";
                default:
                    return obj.toString();
            }
        }
    }

    static class OpensNo implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Нет";
                case "1":
                    return "Открывается";
                default:
                    return obj.toString();
            }
        }
    }

    static class ValveAllStates implements BaseFormat {

        DecimalFormat bd = new DecimalFormat("#");

        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "Открыт";
                case "1":
                    return "Закрыт";
                case "2":
                    return "Промежуточное";
                case "3":
                    return "Авария";
                default:
                    return obj.toString();
            }
        }
    }
    
    static class FriendOrFoe implements BaseFormat {
        
        DecimalFormat bd = new DecimalFormat("#");
        
        @Override
        public String format(Object obj) {
            switch (bd.format(obj)) {
                case "0":
                    return "На охране";
                case "1":
                    return "Чужой";
                case "2":
                    return "Свой";
                case "3":
                    return "Не поставлен на охрану";
                default:
                    return obj.toString();
            }
        }
    }

}