package ru.mrgeng.digit.epu.transform;

/**
 * Неизвестное преобразование
 */
public class NotExistTransformException extends TransformException {
    public NotExistTransformException(String msg) {
        super(msg);
    }

}
