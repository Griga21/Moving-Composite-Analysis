package ru.mrgeng.digit.epu.transform;

import ru.mrgeng.digit.epu.util.ParamTypeHolder;

/**
 * Базовый класс для преобразований
 */
public abstract class TransformCtx {

    public static final Double TRUE_DOUBLE = 1.0;

    public static final Double FALSE_DOUBLE = 0.0;

    private final String transform;

    private final boolean acceptParams;

    private String params;

    final ParamTypeHolder.TypeInfo<?> fromType;

    final ParamTypeHolder.TypeInfo<?> toType;

    public static Double getDoubleForDouble(boolean val) {
        return val ? TRUE_DOUBLE : FALSE_DOUBLE;
    }

    public ParamTypeHolder.TypeInfo<?> getFromType() {
        return fromType;
    }

    public ParamTypeHolder.TypeInfo<?> getToType() {
        return toType;
    }

    public String getParams() {
        return params;
    }

    public String getTransform() {
        return transform;
    }

    public boolean isAcceptParams() {
        return acceptParams;
    }

    public TransformCtx(String transform, boolean acceptParams, ParamTypeHolder.TypeInfo<?> fromType, ParamTypeHolder.TypeInfo<?> toType) {
        this.transform = transform;
        this.acceptParams = acceptParams;
        this.fromType = fromType;
        this.toType = toType;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public abstract Object transform(Object value) throws TransformException;

    public Object reverseTransform(Object value) throws TransformException {
        return value;
    }

    public abstract TransformCtx createCtx(String params) throws TransformValidationException;

    protected double parseDouble(String params, String str) throws TransformValidationException {
        try {
            if (str.contains(","))
                return Double.parseDouble(str.replace(',', '.'));
            return Double.parseDouble(str);
        } catch (NumberFormatException ne) {
            throw new TransformValidationException(getTransform(), "Ошибка разбора числа " + str + " в настройках " + params);
        }

    }
}
