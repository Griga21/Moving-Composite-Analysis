package ru.mrgeng.digit.epu.transform;
import ru.mrgeng.digit.dgcore.service.util.StrUtils;
import ru.mrgeng.digit.epu.param.Param;

import java.io.Serializable;
import java.util.Objects;

/**
 * Описание приведенного параметра на месте измерения c преобразованиями
 */
public class TransParamDef implements Serializable {

    public String connDevCode; // Код подключенного устройства
    public String measPoint;
    public String paramGroup;
    public String paramCode;
    public String groupName;
    public String paramName;
    public String paramTypeCode;
    public String paramMetricPrefix;
    public String paramUnit;
    public String transformFunc;
    public String transformParams;

    public String addTransform;
    public String addTransformParams;

    public Param param;

    public String getDeviceResCode(String deviceCode) {
        final String devCode = connDevCode != null ? connDevCode : deviceCode;
        return measPoint != null ? devCode + '.' + measPoint : devCode;
    }

    @Override
    public String toString() {
        return StrUtils.toStr("Выч. параметр", "подключенное у-во", connDevCode, "место", measPoint, "группа", paramGroup, "код", paramCode, "тип", paramTypeCode, "приставка СИ", paramMetricPrefix, "ед.изм.", paramUnit, "преобр.", transformFunc, "параметр преобр.", transformParams, "Доп. преобр.", addTransform, "Параметры доп. преобр.", addTransformParams);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        TransParamDef that = (TransParamDef) o;
        return Objects.equals(paramGroup, that.paramGroup) && Objects.equals(paramCode, that.paramCode) && Objects.equals(groupName, that.groupName) && Objects.equals(paramName, that.paramName) && Objects.equals(paramTypeCode, that.paramTypeCode) && Objects.equals(paramMetricPrefix, that.paramMetricPrefix);
    }

    @Override
    public int hashCode() {
        return Objects.hash(paramGroup, paramCode, groupName, paramName, paramTypeCode, paramMetricPrefix);
    }
}
