package ru.mrgeng.digit.epu.transform;

/**
 * Ошибка преобразования
 */
public class TransformValidationException extends TransformException {
    public TransformValidationException(String transformFunc, String msg) {
        super(msg, null, transformFunc);
    }
}
