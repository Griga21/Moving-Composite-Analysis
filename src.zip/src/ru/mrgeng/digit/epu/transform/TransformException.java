package ru.mrgeng.digit.epu.transform;

/**
 * Ошибка при выполнении функции преобразования
 */
public class TransformException extends Throwable {
    Object rawValue;
    String transformFunction;
    public TransformException(String msg) {
        super(msg);
    }
    public TransformException(String msg, Object value, String transformFunc) {
        super(msg);
        this.rawValue = value;
        this.transformFunction = transformFunc;
    }
    public String getTransformFunction() {
        return transformFunction;
    }

    public Object getRawValue() {
        return rawValue;
    }
}
