package ru.mrgeng.digit.epu.transform;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Обработчик преобразований с хранением
 */
public class TransformProc {
    private static final TransformProc instance = new TransformProc();

    public static TransformProc getInstance() {
        return instance;
    }

    private final ConcurrentMap<String, TransformCtx> ctx = new ConcurrentHashMap<>();

    public Object transform(Transform transform, String params, Object value) throws TransformException {
        try {
            TransformCtx transformCtx = ctx.computeIfAbsent(transform.getId() + params, s -> {
                try {
                    return transform.getCtx().createCtx(params);
                } catch (TransformValidationException e) {
                    throw new IllegalArgumentException(e);
                }
            });
            return transformCtx.transform(value);

        } catch (IllegalArgumentException e) {
            if (e.getCause() instanceof TransformException) {
                throw (TransformException)e.getCause();
            }
            throw e;
        }
    }

}
