package ru.mrgeng.digit.epu.transform;

import com.haulmont.chile.core.datatypes.impl.EnumClass;
import ru.mrgeng.digit.epu.transform.impl.*;
import ru.mrgeng.digit.epu.util.ParamTypeHolder;
import ru.mrgeng.digit.epu.util.TransformFuncHolder;

import javax.annotation.Nullable;


/**
 * Преобразования, доступные в приложении
 */
public enum Transform implements EnumClass<String> {

    SUBST_VALUES_D_2_D("SubstValuesD2D", new SubstValuesCtx("SubstValuesD2D", ParamTypeHolder.getInstance().DOUBLE, ParamTypeHolder.getInstance().DOUBLE)),
    SUBST_VALUES_D_2_S("SubstValuesD2S", new SubstValuesCtx("SubstValuesD2S", ParamTypeHolder.getInstance().DOUBLE, ParamTypeHolder.getInstance().STRING)),
    SUBST_VALUES_S_2_D("SubstValuesS2D", new SubstValuesCtx("SubstValuesS2D", ParamTypeHolder.getInstance().STRING, ParamTypeHolder.getInstance().DOUBLE)),
    SUBST_VALUES_S_2_S("SubstValuesS2S", new SubstValuesCtx("SubstValuesS2S", ParamTypeHolder.getInstance().STRING, ParamTypeHolder.getInstance().STRING)),
    GET_EQUAL_DOUBLE(TransformFuncHolder.GET_EQUAL_VALUE, new GetEqualDoubleCtx(TransformFuncHolder.GET_EQUAL_VALUE, false)),
    GET_UN_EQUAL_DOUBLE(TransformFuncHolder.GET_UNEQUAL_VALUE, new GetEqualDoubleCtx(TransformFuncHolder.GET_UNEQUAL_VALUE, true)),
    RANGE_TO_RANGE_TRANSFORM(TransformFuncHolder.TRANSFORM_RANGE_TO_RANGE_TO_DOUBLE, new RangeToRangeCtx(TransformFuncHolder.TRANSFORM_RANGE_TO_RANGE_TO_DOUBLE)),
    INVERT_DOUBLE("InvertD", new InvertDoubleCtx("InvertD")),
    CHANGE_SIGN("ChangeSign", new SignChanger("ChangeSign"));

    private String id;

    private TransformCtx ctx;

    Transform(String value, TransformCtx handler) {
        this.id = value;
        this.ctx = handler;
    }

    public String getId() {
        return id;
    }

    public TransformCtx getCtx() {
        return ctx;
    }

    /**
     * @return true, если преобразование поддерживает параметры
     */
    public boolean acceptParams() {
        return getCtx().isAcceptParams();
    }

    /**
     * @param params параметры преобразования
     * @throws TransformValidationException если некорректные параметры преобразования
     */
    public void validateParams(String params) throws TransformValidationException {
        getCtx().createCtx(params);
    }

    /**
     *  Проверить преобразование
     * @param params параметры
     * @param data входные данные
     * @return выходные данные
     * @throws TransformException
     */
    public Object testTransformData(String params, Object data) throws TransformException {
        return getCtx().createCtx(params).transform(data);
    }

    @Nullable
    public static Transform fromId(String id) {
        for (Transform at : Transform.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}