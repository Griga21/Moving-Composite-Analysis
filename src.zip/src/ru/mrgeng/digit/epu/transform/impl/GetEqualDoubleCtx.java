package ru.mrgeng.digit.epu.transform.impl;

import ru.mrgeng.digit.epu.transform.TransformCtx;
import ru.mrgeng.digit.epu.transform.TransformException;
import ru.mrgeng.digit.epu.transform.TransformValidationException;
import ru.mrgeng.digit.epu.util.ParamTypeHolder;

public class GetEqualDoubleCtx extends TransformCtx {

    boolean invert;

    Double checkValue;

    public GetEqualDoubleCtx(String transform, boolean invert) {
        super(transform, true, ParamTypeHolder.getInstance().DOUBLE, ParamTypeHolder.getInstance().DOUBLE);
        this.invert = invert;
    }

    @Override
    public Object transform(Object value) throws TransformException {
        return getDoubleForDouble(invert != value.equals(checkValue));
    }

    @Override
    public TransformCtx createCtx(String params) throws TransformValidationException {
        GetEqualDoubleCtx ctx = new GetEqualDoubleCtx(getTransform(), invert);
        try {
            ctx.checkValue = Double.parseDouble(params);
        } catch (NumberFormatException e) {
            throw new TransformValidationException(getTransform(), "Параметр не является числом: " + params);
        }
        return ctx;
    }
}
