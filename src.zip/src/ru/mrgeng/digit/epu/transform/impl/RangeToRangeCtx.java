package ru.mrgeng.digit.epu.transform.impl;

import ru.mrgeng.digit.epu.transform.TransformCtx;
import ru.mrgeng.digit.epu.transform.TransformException;
import ru.mrgeng.digit.epu.transform.TransformValidationException;
import ru.mrgeng.digit.epu.util.ParamTypeHolder;

/**
 * Преобразование диапазоен в диапозон
 */
public class RangeToRangeCtx extends TransformCtx {
    class Bound {
        final double leftBound;
        final double rightBound;
        final double interval;

        public Bound(String range) throws TransformValidationException {
            String[] bounds = range.split(":");
            if (bounds.length != 2)
                throw new TransformValidationException(getTransform(), "В диапазоне " + range + " должен присутствовать 1 разделитель ':'");
            this.leftBound = parseDouble(range, bounds[0]);
            this.rightBound = parseDouble(range, bounds[1]);
            if (leftBound > rightBound)
                throw new TransformValidationException(getTransform(), "В диапазоне " + range + " левая часть больше правой");
            this.interval = this.rightBound - this.leftBound;
        }

        public String toString() {
            return "[ " +leftBound + " : " + rightBound + " ]";
        }
    }
    Bound inputRange;
    Bound outputRange;

    Bound noErrRange;

    Double convert(double income) throws TransformException {
        if (income < inputRange.leftBound) {
            if (noErrRange == null)
                throw new TransformException("Выход за границы: " + inputRange + " Значение: " + income, income, inputRange.toString());
            else
                if (income < (inputRange.leftBound - Math.abs(noErrRange.leftBound)))
                    throw new TransformException("Выход за границы: " + inputRange + " с учетом допуска " + noErrRange.leftBound +  " Значение: " + income, income, inputRange.toString());
                else
                    return outputRange.leftBound;
        }
        if (income > inputRange.rightBound) {
            if (noErrRange == null)
                throw new TransformException("Выход за границы: " + inputRange + " Значение: " + income, income, inputRange.toString());
            else
            if (income > (inputRange.rightBound + Math.abs(noErrRange.rightBound)))
                throw new TransformException("Выход за границы: " + inputRange + " с учетом допуска " + noErrRange.rightBound+  " Значение: " + income, income, inputRange.toString());
            else
                return outputRange.rightBound;
        }
        if (income == inputRange.leftBound)
            return outputRange.leftBound;
        else if (income == inputRange.rightBound)
            return outputRange.rightBound;
        double percent = (income - inputRange.leftBound) / inputRange.interval;
        return outputRange.leftBound + outputRange.interval * percent;
    }

    public RangeToRangeCtx(String transform) {
        super(transform, true, ParamTypeHolder.getInstance().DOUBLE, ParamTypeHolder.getInstance().DOUBLE);
    }

    public void setInputRange(String inputRng) throws TransformValidationException {
        inputRange = new Bound(inputRng);
    }

    public void setOutputRange(String outputRng) throws TransformValidationException {
        outputRange = new Bound(outputRng);
    }

    public void setNoErrRange(String noErrRng) throws TransformValidationException {
        noErrRange = new Bound(noErrRng);
    }

    @Override
    public Object transform(Object value) throws TransformException {
        return convert((Double) value);
    }

    @Override
    public TransformCtx createCtx(String params) throws TransformValidationException {
        String[] s = params.trim().replaceAll(" +", " ").split(" ");
        if (s.length < 2 || s.length > 3)
            throw new TransformValidationException(getTransform(), "Должно быть указано два или три диапазона");
        RangeToRangeCtx rangeCtx = new RangeToRangeCtx(getTransform());
        rangeCtx.setInputRange(s[0]);
        rangeCtx.setOutputRange(s[1]);
        if (s.length == 3)
            rangeCtx.setNoErrRange(s[2]);
        return rangeCtx;
    }
}
