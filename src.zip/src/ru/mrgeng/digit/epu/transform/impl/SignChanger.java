package ru.mrgeng.digit.epu.transform.impl;

import ru.mrgeng.digit.epu.transform.TransformCtx;
import ru.mrgeng.digit.epu.transform.TransformException;
import ru.mrgeng.digit.epu.transform.TransformValidationException;
import ru.mrgeng.digit.epu.util.ParamTypeHolder;

/**
 * Смена знака у значения -1 -> 1 или 1 -> -1
 */
public class SignChanger extends TransformCtx {

    public SignChanger(String transform) {
        super(transform, false, ParamTypeHolder.getInstance().DOUBLE, ParamTypeHolder.getInstance().DOUBLE);
    }

    @Override
    public Object transform(Object value) throws TransformException {
        if (value instanceof Double && (Double) value != 0.0) {
            return (Double) value * -1.0;
        }
        return value;
    }

    @Override
    public Object reverseTransform(Object value) throws TransformException {
        return transform(value);
    }

    @Override
    public TransformCtx createCtx(String params) throws TransformValidationException {
        return new SignChanger(getTransform());
    }
}
