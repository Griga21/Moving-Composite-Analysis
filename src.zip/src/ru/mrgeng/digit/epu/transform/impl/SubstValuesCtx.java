package ru.mrgeng.digit.epu.transform.impl;

import ru.mrgeng.digit.epu.transform.*;
import ru.mrgeng.digit.epu.util.ParamTypeHolder;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Преобразование подстановки(замены) одних значений другими по карте значений
 *
 * Возможны варианты замены: Число -> Строка, Число -> Число, Строка -> Число, Строка -> Строка
 *
 * Для загрузки справочника используется Java Properties, разделение значений через '\n'
 *
 * todo: Не поддерживается ключи в строк с пробелами
 */
public class SubstValuesCtx extends TransformCtx {

    Map<Object, Object> dict = new HashMap<>();

    public SubstValuesCtx(String transform, ParamTypeHolder.TypeInfo<?> fromType, ParamTypeHolder.TypeInfo<?> toType) {
        super(transform, true, fromType, toType);
    }

    private void init(String params) throws TransformValidationException {
        setParams(params);
        Properties dictProps = new Properties();
        try {
            dictProps.load(new StringReader(params));
        } catch (IOException e) {
            throw new TransformValidationException(getTransform(), e.getMessage());
        }
        try {
            for (String propName : dictProps.stringPropertyNames()) {
                if (propName != null)
                    propName = propName.trim();
                String propVal = dictProps.getProperty(propName);
                if (propVal != null)
                    propVal = propVal.trim();
                Object from = getTypedValueFromStr(getFromType(), propName);
                Object tp = getTypedValueFromStr(getToType(), propVal);
                dict.put(from, tp);
            }
        } catch (ParamTypeHolder.ParseError e) {
            throw new TransformValidationException(getTransform(), params + ": " + e.getMessage());
        }
    }


    @Override
    public TransformCtx createCtx(String params) throws TransformValidationException {
        SubstValuesCtx copy = new SubstValuesCtx(getTransform(), getFromType(), getToType());
        copy.init(params);
        return copy;
    }

    Object getTypedValueFromStr(ParamTypeHolder.TypeInfo<?> type, String value) throws ParamTypeHolder.ParseError {
        return type.parseFromStr(value);
    }

    public Object transform(Object value) throws TransformException {
        return dict.get(value);
    }

}
