package ru.mrgeng.digit.epu.transform.impl;

import ru.mrgeng.digit.epu.transform.TransformCtx;
import ru.mrgeng.digit.epu.transform.TransformException;
import ru.mrgeng.digit.epu.transform.TransformValidationException;
import ru.mrgeng.digit.epu.util.ParamTypeHolder;

/**
 * Инвертировать числовое значение 0 -> 1, >= 1 -> 0
 */
public class InvertDoubleCtx extends TransformCtx {

    public InvertDoubleCtx(String transform) {
        super(transform, false, ParamTypeHolder.getInstance().DOUBLE, ParamTypeHolder.getInstance().DOUBLE);
    }

    @Override
    public Object transform(Object value) throws TransformException {
        if (value instanceof Double) {
            Double d = (Double) value;
            if (d == 0.0)
                return TRUE_DOUBLE;
            if (d >= 1.0)
                return FALSE_DOUBLE;
            throw new TransformValidationException(getTransform(), "Значение не может быть инвертировано " + d);
        }
        return value;
    }

    @Override
    public TransformCtx createCtx(String params) throws TransformValidationException {
        return new InvertDoubleCtx(getTransform());
    }
}
