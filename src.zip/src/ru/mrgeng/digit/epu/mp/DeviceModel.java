package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;

/**
 * Модель устройства
 */
@Table(name = "MP_DEVICE_MODEL", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_MODEL_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_DeviceModel")
@NamePattern("%s|name")
public class DeviceModel extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_TYPE_ID")
    protected DeviceType deviceType;

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public String toString() {
        return name != null
                ? name
                : super.toString();
    }
}