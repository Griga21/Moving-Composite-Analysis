package ru.mrgeng.digit.epu.mp;



import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Table(name = "MP_GAS_QUALITY_PROTOCOL")
@Entity(name = "mp_GasQualityProtocol")
@NamePattern("%s|id")
public class GasQualityProtocol extends Obj {
    private static final long serialVersionUID = -6270684577091013288L;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    @OnDeleteInverse(value = DeletePolicy.CASCADE)
    private Device device;

    @Column(name = "GRS")
    private String grs;

    @Column(name = "SENT_TS")
    private LocalDateTime sentTs;

    @Column(name = "SENT_BY")
    private String sentBy;

    @Column(name = "FORMATION_DATE")
    private LocalDate formationDate;

    @Column(name = "PASSPORT_NUMBER")
    private String passportNumber;

    @Column(name = "START_DATE")
    private LocalDate startDate;

    @Column(name = "END_DATE")
    private LocalDate endDate;

    @Column(name = "PROTOCOL_STATUS")
    private Integer protocolStatus;

    @Column(name = "REQUEST_ID")
    private String requestId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GASQUALITYPASSPORT_ID")
    private GasQualityPassport gasQualityPassport;

    public void setGasQualityPassport(GasQualityPassport gasQualityPassport) {
        this.gasQualityPassport = gasQualityPassport;
    }

    public GasQualityPassport getGasQualityPassport() {
        return gasQualityPassport;
    }


    public void setProtocolStatus(GasQualityProtocolStatus protocolStatus) {
        this.protocolStatus = protocolStatus == null ? null : protocolStatus.getId();
    }
    public GasQualityProtocolStatus getProtocolStatus() {
        return protocolStatus == null ? null : GasQualityProtocolStatus.fromId(protocolStatus);
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setFormationDate(LocalDate formationDate) {
        this.formationDate = formationDate;
    }

    public LocalDate getFormationDate() {
        return formationDate;
    }

    public void setSentBy(String sentBy) {
        this.sentBy = sentBy;
    }

    public String getSentBy() {
        return sentBy;
    }

    public void setSentTs(LocalDateTime sentTs) {
        this.sentTs = sentTs;
    }

    public LocalDateTime getSentTs() {
        return sentTs;
    }

    public void setGrs(String grs) {
        this.grs = grs;
    }

    public String getGrs() {
        return grs;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
}