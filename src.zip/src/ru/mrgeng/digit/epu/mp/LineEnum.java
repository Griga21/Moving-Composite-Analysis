package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum LineEnum implements EnumClass<Integer> {

    LINE_1(1),
    LINE_2(2),
    LINE_3(3),
    LINE_4(4),
    LINE_5(5),
    LINE_6(6),
    LINE_7(7),
    LINE_8(8),
    LINE_9(9);

    private final Integer id;

    LineEnum(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static LineEnum fromId(Integer id) {
        for (LineEnum at : LineEnum.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }

    public String getCode() {
        return "line" + id;
    }

    public static String getCode(Integer id) {
        return "line" + id;
    }

}