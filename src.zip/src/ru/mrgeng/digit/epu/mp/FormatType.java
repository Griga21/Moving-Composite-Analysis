package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

public enum FormatType implements EnumClass<Integer> {

    FROM_PARAM(0), //формат из параметра
    ROUND(1), //округление до целого
    NO_FORMAT(2); //без форматирования

    private final Integer id;

    FormatType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

}
