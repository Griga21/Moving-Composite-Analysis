package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

/**
 * Тип параметра для отрисовки виджетов, например параметр с порогами, дверь(открыта, закрыта) и т.д
 */
public enum ParamDisplay implements EnumClass<Integer> {

    DOOR(1), //дверь
    WITH_THRESHOLD(2), //с порогами
    SIGNAL(3), //сигнал(например GPRS, WIFI)
    BATTERY(4), //заряд батареии
    CHARGE(5);

    private Integer id;

    ParamDisplay(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ParamDisplay fromId(Integer id) {
        for (ParamDisplay at : ParamDisplay.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}