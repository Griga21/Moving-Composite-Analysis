package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Listeners;

import javax.persistence.*;

@Table(name = "MP_DEVICE_POLLING")
@Entity(name = "mp_DevicePolling")
@NamePattern("%s - %s|deviceParamGroup,cron")
@Listeners("pros_MpConfListener")
public class DevicePolling extends Obj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_SERVICE_ID")
    private DeviceService deviceService;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PARAM_GROUP_ID")
    private DeviceParamGroup deviceParamGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_GROUP_ID")
    private DeviceGroup deviceGroup;

    @Column(name = "CRON")
    private String cron;

    @Column(name = "ENABLED")
    private Boolean enabled;

    @Column(name = "REQUEST_PERIOD")
    protected Integer requestPeriod;

    @Column(name = "ENABLE_MISSED_DATA_SEARCH")
    private Boolean enableMissedData = Boolean.FALSE;

    @Column(name = "ADDITIONAL_MISSED_DATA")
    private Boolean additionalMissedData = Boolean.FALSE;

    @Column(name = "ADDITIONAL")
    private Boolean additional = Boolean.FALSE;

    @Column(name = "WITH_COMM_HOUR_MISSED_DATA")
    private Boolean withCommHourMissedData = Boolean.FALSE;

    @Column(name = "WITH_COMM_HOUR")
    private Boolean withCommHour = Boolean.FALSE;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_ID")
    private Param param;

    @Column(name = "REQUEST_DEEP")
    private Integer requestDeep;

    @Column(name = "MISSED_DATA_CRON")
    private String missedDataCron;

    // Column(name = "PERIOD_CALC_POLITIC")
    // periodCalcPolitic;//  по умолчанию 1
    //arc_h:   paramGroups - нужна для выбора таблицы часов или суток CC - групппа параметров драйвера - вычисляемая

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_GROUP_ID")
    protected ParamGroup paramGroup;

    @Column(name = "DATA_PERIODICITY")
    protected Integer dataPeriodicity;

    public Boolean getWithCommHourMissedData() {
        return withCommHourMissedData;
    }

    public void setWithCommHourMissedData(Boolean withCommHourMissedData) {
        this.withCommHourMissedData = withCommHourMissedData;
    }

    public Boolean isWithCommHour() {
        return withCommHour == null ? Boolean.FALSE : withCommHour;
    }

    public Boolean isWithCommHourMissedData() {
        return withCommHourMissedData == null ? Boolean.FALSE : withCommHourMissedData;
    }

    public Boolean getWithCommHour() {
        return withCommHour;
    }

    public void setWithCommHour(Boolean withCommHour) {
        this.withCommHour = withCommHour;
    }

    public DataPeriodicity getDataPeriodicity() {
        return dataPeriodicity == null ? null : DataPeriodicity.fromId(dataPeriodicity);
    }

    public void setDataPeriodicity(DataPeriodicity dataPeriodicity) {
        this.dataPeriodicity = dataPeriodicity == null ? null : dataPeriodicity.getId();
    }

    public boolean isAdditionalMissedData() {
        return additionalMissedData != null && additionalMissedData;
    }

    public boolean isAdditional() {
        return additional != null && additional;
    }

    public Boolean getAdditionalMissedData() {
        return additionalMissedData;
    }

    public void setAdditionalMissedData(Boolean additionalMissedData) {
        this.additionalMissedData = additionalMissedData;
    }

    public Boolean getAdditional() {
        return additional;
    }

    public void setAdditional(Boolean additional) {
        this.additional = additional;
    }

    public ParamGroup getParamGroup() {
        return paramGroup;
    }

    public void setParamGroup(ParamGroup paramGroup) {
        this.paramGroup = paramGroup;
    }

    public DeviceGroup getDeviceGroup() {
        return deviceGroup;
    }

    public void setDeviceGroup(DeviceGroup deviceGroup) {
        this.deviceGroup = deviceGroup;
    }

    public Boolean getEnableMissedData() {
        return enableMissedData;
    }

    public void setEnableMissedData(Boolean enableMissedData) {
        this.enableMissedData = enableMissedData;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }

    public Integer getRequestDeep() {
        return requestDeep;
    }

    public void setRequestDeep(Integer requestDeep) {
        this.requestDeep = requestDeep;
    }

    public String getMissedDataCron() {
        return missedDataCron;
    }

    public void setMissedDataCron(String missedDataCron) {
        this.missedDataCron = missedDataCron;
    }

    public RequestPeriod getRequestPeriod() {
        return requestPeriod == null ? null : RequestPeriod.fromId(requestPeriod);
    }

    public void setRequestPeriod(RequestPeriod requestPeriod) {
        this.requestPeriod = requestPeriod == null ? null : requestPeriod.getId();
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getCron() {
        return cron;
    }

    public void setCron(String cron) {
        this.cron = cron;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public DeviceParamGroup getDeviceParamGroup() {
        return deviceParamGroup;
    }

    public void setDeviceParamGroup(DeviceParamGroup deviceParamGroup) {
        this.deviceParamGroup = deviceParamGroup;
    }

    public DeviceService getDeviceService() {
        return deviceService;
    }

    public void setDeviceService(DeviceService deviceService) {
        this.deviceService = deviceService;
    }
}