package ru.mrgeng.digit.epu.mp;

public interface SecondName {
     String getSecondName();
}
