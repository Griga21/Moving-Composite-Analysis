package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(name = "MP_DEVICE_PARAM_TYPE", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_PARAM_TYPE_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_DeviceParamType")
@NamePattern("%s(%s)|name,code")
public class DeviceParamType extends MpObj {
    private static final long serialVersionUID = 1L;
}