package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.dgcore.entity.Department;
import ru.mrgeng.digit.dgcore.entity.SysUser;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.UUID;

@Table(name = "MP_DISP_SHIFT_RESPONSIBLE")
@Entity(name = "mp_DispShiftResponsible")
@NamePattern("%s (%s)|responsible,department")
public class DispShiftResponsible extends Obj {
    private static final long serialVersionUID = -4575982567426090403L;

    @SystemLevel
    @Column(name = "DEPARTMENT_ID")
    private Long departmentId;

    @MetaProperty(related = "departmentId")
    @Transient
    private Department department;

    @SystemLevel
    @Column(name = "USER_ID")
    private UUID userId;

    @MetaProperty(related = "userId")
    @Transient
    private SysUser responsible;

    @Column(name = "COMMENT")
    private String comment;

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public SysUser getResponsible() {
        return responsible;
    }

    public void setResponsible(SysUser responsible) {
        this.responsible = responsible;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }
}