package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.global.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.mrgeng.digit.dgcore.service.ParamValue;
import ru.mrgeng.digit.epu.config.DeviceMapFragConfig;
import ru.mrgeng.digit.epu.param.Param;
import ru.mrgeng.digit.epu.param.SeriousLevel;
import ru.mrgeng.digit.epu.service.*;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Сервис перенесен из core в global модуль, так как используется в ReportCurrentlyInactiveObjectsServiceBean на middle слое и в
 * DashTreeHolder на web слое, следовательно будут подниматься два экзепляра, по одному на каждый слой приложения.
 * Если его оставить в core, то появляются задержки, пока все передается туда-обратно между middle и web слоями.
 */
@Service(CalculatePriorityTreeService.NAME)
public class CalculatePriorityTreeServiceBean implements CalculatePriorityTreeService {
    @Inject
    @Named("ddKeeper")
    private IDeviceDataKeeper deviceDataKeeper;
    private static final Logger log = LoggerFactory.getLogger(CalculatePriorityTreeServiceBean.class);
    @Inject
    private ParamInfoUtils paramInfoUtils;
    @Inject
    private Configuration configuration;
    private DeviceMapFragConfig fragConfig;
    @Inject
    private MpService mpService;

    @Override
    public Integer getPriorityFromTree(Device device, boolean statusLogger) {
        fragConfig = configuration.getConfig(DeviceMapFragConfig.class);
        MpService.SingleDeviceData singleDeviceData = deviceDataKeeper.getDeviceData(device);
        MpService.DeviceStat status = deviceDataKeeper.getDeviceData(device).deviceStat;
        if (statusLogger)
            log.info("Loaded status device {}, status {}", device.getName(), status);
        int priority = 30;
        if (status == null) {
            return priority;
        }
        if (status.lastDataAt != null) {
            long timeArrivalData = device.getTimeArrivalData() == null ? fragConfig.getDefNoDataMs() : device.getTimeArrivalData() * 1000L;
            if (System.currentTimeMillis() - status.lastDataAt.getTime() < timeArrivalData) {
                priority = 20;
            }
        }
        Map<String, Map<String, Date>> paramsIgnoresByDevice = paramInfoUtils.getParamsIgnoresByDevice(device);
        if (device.getType() != null) {
            DeviceParamService.ParamsInfo<Param> paramInfoByDeviceType = mpService.getDeviceCalcParams(device.getServiceCode(), device.getCode());
            Map<Long, Map<String, Map<Long, DeviceParamService.ParamsThresholdInfo>>> mp = paramInfoUtils.getThresholds(device.getDeviceService().getCode());
            if (mp != null) {
                Map<String, Map<Long, DeviceParamService.ParamsThresholdInfo>> paramByLineCode = mp.get(device.getId());
                if (paramByLineCode != null) {
                    for (Map.Entry<String, MpService.SingleDeviceMpData> entryLineLastData : singleDeviceData.points.entrySet()) {
                        MpService.SingleDeviceMpData singleDeviceMpData = entryLineLastData.getValue();
                        Map<Long, DeviceParamService.ParamsThresholdInfo> thresholdsByParamId = paramByLineCode.get(singleDeviceMpData.getMpCodeNotNull());
                        if (thresholdsByParamId != null) {
                            for (Map.Entry<Long, DeviceParamService.ParamsThresholdInfo> oneParamsThresholdInfoEntry : thresholdsByParamId.entrySet()) {
                                Long paramId = oneParamsThresholdInfoEntry.getKey();
                                Param paramInfo = paramInfoByDeviceType.params.get(paramId);
                                if (paramInfo != null) {
                                    if (ParamInfoUtils.isParamIgnored(paramsIgnoresByDevice, paramInfo)) continue;
                                    DeviceParamService.ParamsThresholdInfo thresholdInfo = oneParamsThresholdInfoEntry.getValue();
                                    if (singleDeviceMpData.mapParamWithLastData != null) {
                                        Map<String, ParamValue> lastData = singleDeviceMpData.mapParamWithLastData.get(paramInfo.groupCode);
                                        if (lastData != null) {
                                            ParamValue paramValue = lastData.get(paramInfo.code);
                                            if (paramValue != null) {
                                                Double value = paramValue.val;
                                                if (thresholdInfo != null) {
                                                    if (thresholdInfo.low1 != null && value <= thresholdInfo.low1) {
                                                        priority = Math.max(priority, 40);
                                                    }
                                                    if (thresholdInfo.high1 != null && value >= thresholdInfo.high1) {
                                                        priority = Math.max(priority, 40);
                                                    }
                                                    if (thresholdInfo.low2 != null && value <= thresholdInfo.low2) {
                                                        priority = 50;
                                                    }
                                                    if (thresholdInfo.high2 != null && value >= thresholdInfo.high2) {
                                                        priority = 50;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (Map.Entry<String, MpService.SingleDeviceMpData> entryLineLastData : singleDeviceData.points.entrySet()) {
                MpService.SingleDeviceMpData singleDeviceMpData = entryLineLastData.getValue();
                if (singleDeviceMpData.mapParamWithLastData != null) {
                    for (Map.Entry<String, Map<String, ParamValue>> mapParamWithLastDataEntry : singleDeviceMpData.mapParamWithLastData.entrySet()) {
                        String paramGroupCode = mapParamWithLastDataEntry.getKey();
                        Map<String, Param> paramInfoMap = paramInfoByDeviceType.strGroupParams.get(paramGroupCode);
                        Map<String, ParamValue> lastData = mapParamWithLastDataEntry.getValue();
                        if (lastData != null && paramInfoMap != null) {
                            for (Map.Entry<String, ParamValue> paramValueEntry : lastData.entrySet()) {
                                String paramCode = paramValueEntry.getKey();
                                ParamValue paramValue = paramValueEntry.getValue();
                                Param paramInfo = paramInfoMap.get(paramCode);
                                if (paramInfo != null) {
                                    if (ParamInfoUtils.isParamIgnored(paramsIgnoresByDevice, paramInfo)) continue;
                                    if (paramInfo.alarmSign != null) {
                                        SeriousLevel check = paramInfo.alarmSign.check(paramValue.val);
                                        if (check != null) {
                                            if (check.equals(SeriousLevel.ALARM))
                                                priority = 50;
                                            else if (check.equals(SeriousLevel.WARN))
                                                priority = Math.max(priority, 40);

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (status.isHaveTransformException()) {
            priority = 50;
        }
        return priority;
    }

    @Override
    public Integer getPriorityFromTree(List<Device> devices, boolean statusLogger) {
        Set<DeviceStatusType> deviceStatusTypes = devices.stream()
                .map(d -> d.getDeviceStatus() != null ? d.getDeviceStatus().getType() : null)
                .collect(Collectors.toSet());
        if (deviceStatusTypes.size() == 1) {
            DeviceStatusType type = deviceStatusTypes.iterator().next();
            if (DeviceStatusType.NOT_WORKING.equals(type)) {
                return 10;
            }
        }
        List<Integer> priorityList = new ArrayList<>();
        for (Device device : devices) {
            Integer priority = getPriorityFromTree(device, statusLogger);
            priorityList.add(priority);
        }
        return TreeItemService.getResultPriority(priorityList);
    }
}