package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;

@Table(name = "MP_DEVICE_CHANNEL", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_CHANNEL_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_DeviceChannel")
@NamePattern("%s|name")
public class DeviceChannel extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_SERVICE_ID")
    protected DeviceService deviceService;

    @Column(name = "JSON_SETTINGS", length = 2048)
    private String jsonSettings;

    public String getJsonSettings() {
        return jsonSettings;
    }

    public void setJsonSettings(String jsonSettings) {
        this.jsonSettings = jsonSettings;
    }

    public DeviceService getDeviceService() {
        return deviceService;
    }

    public void setDeviceService(DeviceService deviceService) {
        this.deviceService = deviceService;
    }
}