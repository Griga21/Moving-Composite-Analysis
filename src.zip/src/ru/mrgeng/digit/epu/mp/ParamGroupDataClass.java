package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ParamGroupDataClass implements EnumClass<Integer> {

    DATA(1),
    CONFIGURATION(2),
    TELECONTROL(3),
    ALARM_JOURNAL(4),
    INTERVENTION_JOURNAL(5),
    POLL_JOURNAL(6);

    private final Integer id;

    ParamGroupDataClass(Integer id) {
        this.id = id;
    }

    @Nullable
    public static ParamGroupDataClass fromId(Integer id) {
        for (ParamGroupDataClass at : ParamGroupDataClass.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public Integer getId() {
        return id;
    }
}