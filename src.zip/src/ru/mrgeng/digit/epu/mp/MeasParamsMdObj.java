package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.dgcore.entity.HasOrig;
import ru.mrgeng.digit.dgcore.entity.Source;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

@MappedSuperclass
@NamePattern("%s|name")
public class MeasParamsMdObj extends Obj implements HasOrig {
    private static final long serialVersionUID = 6111097903812656216L;

    @Column(name = "NAME", length = 512)
    private String name;

    @Column(name = "ORIG")
    private String orig;

    @Column(name = "SOURCE_ID")
    private Long sourceId;

    @MetaProperty(related = "sourceId")
    @Transient
    private Source source;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getOrig() {
        return orig;
    }

    @Override
    public void setOrig(String orig) {
        this.orig = orig;
    }

    public Source getSource() {
        return source;
    }

    public void setSource(Source source) {
        this.source = source;
        this.sourceId = source == null ? null : source.getId();
    }

    public Long getSourceId() {
        return sourceId;
    }

    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }
}
