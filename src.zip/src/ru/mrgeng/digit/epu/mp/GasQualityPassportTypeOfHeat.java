package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum GasQualityPassportTypeOfHeat implements EnumClass<Integer> {

    KCAL_BY_M3(10),
    WT_TIME_HOUR_BY_M3(20);

    private Integer id;

    GasQualityPassportTypeOfHeat(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static GasQualityPassportTypeOfHeat fromId(Integer id) {
        for (GasQualityPassportTypeOfHeat at : GasQualityPassportTypeOfHeat.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
