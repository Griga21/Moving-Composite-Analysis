package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(name = "MP_PARAM_UNIT_METRIC_PREFIX", uniqueConstraints = {
        @UniqueConstraint(name = "UC_PARAM_UNIT_METRIC_PREFIX_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_ParamUnitMetricPrefix")
@NamePattern("%s(%s)|name,abbr")
public class ParamUnitMetricPrefix extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "ABBR", length = 16)
    private String abbr;

    public String getAbbr() {
        return abbr;
    }

    public void setAbbr(String abbr) {
        this.abbr = abbr;
    }
}