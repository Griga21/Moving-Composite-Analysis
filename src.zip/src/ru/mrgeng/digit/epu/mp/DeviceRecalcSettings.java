package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;

import javax.persistence.*;

@Table(name = "MP_DEVICE_RECALC_SETTINGS")
@Entity(name = "mp_DeviceRecalcSettings")
@NamePattern("%s|device")
@PublishEntityChangedEvents
public class DeviceRecalcSettings extends Obj {
    private static final long serialVersionUID = 7166233421502548603L;

    public static final int DEFAULT_ACC_DAY_PRIORITY = 200;
    public static final int DEFAULT_HOUR_SUM_PRIORITY = 300;
    public static final int DEFAULT_ACC_HOUR_PRIORITY = 100;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    @Column(name = "ENABLED")
    private Boolean enabled;

    @Column(name = "ACC_DAY_PRIORITY")
    private Integer accDayPriority;

    @Column(name = "HOUR_SUM_PRIORITY")
    private Integer hourSumPriority;

    @Column(name = "ACC_HOUR_PRIORITY")
    private Integer accHourPriority;

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Integer getAccDayPriority() {
        return accDayPriority;
    }

    public void setAccDayPriority(Integer accDayPriority) {
        this.accDayPriority = accDayPriority;
    }

    public Integer getHourSumPriority() {
        return hourSumPriority;
    }

    public void setHourSumPriority(Integer hourSumPriority) {
        this.hourSumPriority = hourSumPriority;
    }

    public Integer getAccHourPriority() {
        return accHourPriority;
    }

    public void setAccHourPriority(Integer accHourPriority) {
        this.accHourPriority = accHourPriority;
    }

    public void fillDefaultPriorities() {
        if (accDayPriority == null)
            accDayPriority = DEFAULT_ACC_DAY_PRIORITY;
        if (hourSumPriority == null)
            hourSumPriority = DEFAULT_HOUR_SUM_PRIORITY;
        if (accHourPriority == null)
            accHourPriority = DEFAULT_ACC_HOUR_PRIORITY;
    }
}
