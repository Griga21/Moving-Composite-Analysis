package ru.mrgeng.digit.epu.mp;

import java.util.Date;

public class DatePeriod {
    private Date from;
    private Date to;

    public DatePeriod(Date from, Date to) {
        this.from = from;
        this.to = to;
    }

    public DatePeriod(Date date) {
        this.from = date;
        this.to = date;
    }

    public boolean shiftPeriod(Date date) {
        if (from.after(date)) {
            from = date;
            return true;
        }
        if (to.before(date)) {
            to = date;
            return true;
        }
        return false;
    }

    public Date getFrom() {
        return from;
    }

    public Date getTo() {
        return to;
    }

    @Override
    public String toString() {
        return "DatePeriod{" +
                "from=" + from +
                ", to=" + to +
                '}';
    }
}
