package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@PublishEntityChangedEvents
@Table(name = "MP_DEVICE_MP_IGNORE", uniqueConstraints = {
        @UniqueConstraint(name = "UK_DEVICE_MP_IGNORE", columnNames = {"DEVICE_ID", "PARAM_ID", "DEVICE_MP_ID"})
})
@Entity(name = "mp_DeviceMpIgnore")
@Listeners("pros_MpConfListener")
public class DeviceMpIgnore extends Obj {
    private static final long serialVersionUID = -2795838874815390604L;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID", nullable = false)
    private Device device;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MP_ID")
    private DeviceMeasPoint deviceMp;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_ID", nullable = false)
    private Param param;

    @NotNull
    @Column(name = "IGNORE_END_TS", nullable = false)
    private Date ignoreEndTs;

    @NotNull
    @Column(name = "COMMENT", length = 512, nullable = false)
    private String comment;

    public DeviceMeasPoint getDeviceMp() {
        return deviceMp;
    }

    public void setDeviceMp(DeviceMeasPoint deviceMp) {
        this.deviceMp = deviceMp;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getIgnoreEndTs() {
        return ignoreEndTs;
    }

    public void setIgnoreEndTs(Date ignoreEndTs) {
        this.ignoreEndTs = ignoreEndTs;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }
}