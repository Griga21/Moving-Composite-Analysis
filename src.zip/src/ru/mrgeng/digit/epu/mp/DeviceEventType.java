package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;
import ru.mrgeng.digit.epu.param.SeriousLevel;


import javax.annotation.Nullable;
import java.io.Serializable;

/**
 * Типы событий по устройствам
 */
public enum DeviceEventType implements EnumClass<Integer>, Serializable {

    UP_1(10), // Верхний предупредительный порог
    UP_2(20), // Верхний аварийный порог
    DOWN_1(30), // Нижний предупредительный порог
    DOWN_2(40), // Нижний аварийный порог
    DSIGN_WARN(50), // Предупреждение по значению дискрета
    DSIGN_ALARM(60),// Тревога по значению дискрета
    NSD(65), // Несанкционированный доступ
    TRANSFORM_EXCEPTION(70), // Ошибки преобразований данных
    NO_DATA(85), //Отсутствие данных
    NORMALIZE(100), // Возвращение последнего значения параметра в нормальное состояние
    IGNORE(105); //игнорирование создания событий по параметру

    private Integer id;

    private SeriousLevel level;

    static {
        UP_1.level = SeriousLevel.WARN;
        UP_2.level = SeriousLevel.ALARM;
        DOWN_1.level = SeriousLevel.WARN;
        DOWN_2.level = SeriousLevel.ALARM;
        DSIGN_WARN.level = SeriousLevel.WARN;
        DSIGN_ALARM.level = SeriousLevel.ALARM;
        NSD.level = SeriousLevel.ALARM;
        TRANSFORM_EXCEPTION.level = SeriousLevel.ALARM;
        NO_DATA.level = SeriousLevel.INFO;
        NORMALIZE.level = SeriousLevel.INFO;
        IGNORE.level = SeriousLevel.INFO;
    }

    DeviceEventType(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    public SeriousLevel getLevel() {
        return level;
    }

    @Nullable
    public static DeviceEventType fromId(Integer id) {
        for (DeviceEventType at : DeviceEventType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}