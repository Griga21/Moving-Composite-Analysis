package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.BaseLongIdEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "MP_TECH_INFO")
@Entity(name = "mp_TechInfo")
@NamePattern("%s|param")
public class TechInfo extends BaseLongIdEntity {
    private static final long serialVersionUID = 3291772918933777864L;

    @Column(name = "DEVICE_MODEL_CODE")
    private String deviceModelCode;

    @Column(name = "LEVEL_PARAM")
    private Integer levelParam;

    @Column(name = "LEVEL_NAME")
    private String levelName;

    @Column(name = "PARAM")
    private String param;

    @Column(name = "VALUE_")
    private String value;

    @Column(name = "DEVICE_CODE")
    private String deviceCode;

    public String getDeviceModelCode() {
        return deviceModelCode;
    }

    public void setDeviceModelCode(String deviceModelCode) {
        this.deviceModelCode = deviceModelCode;
    }

    public Integer getLevelParam() {
        return levelParam;
    }

    public void setLevelParam(Integer levelParam) {
        this.levelParam = levelParam;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getDeviceCode() {
        return deviceCode;
    }
}