package ru.mrgeng.digit.epu.mp.passport.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum TypeOfCommunicationChannelWithPU implements EnumClass<String> {
    CABLE("Кабельный"),
    GPRS("GPRS"),
    CSD("CSD"),
    SMS("SMS"),
    SATELLITE("Спутниковый"),
    RADIO_RELAY("Радиорелейный");

    private String type;

    TypeOfCommunicationChannelWithPU(String type) {
        this.type = type;
    }

    @Override
    public String getId() {
        return type;
    }
    @Nullable
    public static TypeOfCommunicationChannelWithPU fromType(String type) {
        for (TypeOfCommunicationChannelWithPU typeOfCommunicationChannelWithPU : TypeOfCommunicationChannelWithPU.values()) {
            if (typeOfCommunicationChannelWithPU.getId().equals(type)) {
                return typeOfCommunicationChannelWithPU;
            }
        }
        return null;
    }
}
