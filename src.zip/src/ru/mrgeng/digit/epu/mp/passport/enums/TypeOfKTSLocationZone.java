package ru.mrgeng.digit.epu.mp.passport.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum TypeOfKTSLocationZone implements EnumClass<String> {
    EXPLOSIVE("Взрывоопасная"),
    EXPLOSION_PROOF("Взрывобезопасная");

    private String type;

    TypeOfKTSLocationZone(String type) {
        this.type = type;
    }

    @Override
    public String getId() {
        return type;
    }
    @Nullable
    public static TypeOfKTSLocationZone fromType(String type) {
        for (TypeOfKTSLocationZone typeOfKTSLocationZone : TypeOfKTSLocationZone.values()) {
            if (typeOfKTSLocationZone.getId().equals(type)) {
                return typeOfKTSLocationZone;
            }
        }
        return null;
    }
}
