package ru.mrgeng.digit.epu.mp.passport;

import com.haulmont.cuba.core.entity.StandardEntity;

import javax.persistence.*;

@Table(name = "MP_TYPE_AND_QUANTITY_PORTS_KTS")
@Entity(name = "mp_TypeAndQuantityPortsKTS")
public class TypeAndQuantityPortsKTS extends StandardEntity {
    private static final long serialVersionUID = 520856237090622977L;

    @Column(name = "TYPEPORT")
    private String typePort;
    @Column(name = "QUANTITY")
    private Integer quantity;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PASSPORT_KAS_ID")
    private PassportKAS passportKAS;

    public String getTypePort() {
        return typePort;
    }

    public void setTypePort(String typePort) {
        this.typePort = typePort;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public PassportKAS getPassportKAS() {
        return passportKAS;
    }

    public void setPassportKAS(PassportKAS passportKAS) {
        this.passportKAS = passportKAS;
    }
}