package ru.mrgeng.digit.epu.mp.passport;


import com.haulmont.chile.core.annotations.Composition;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.epu.mp.Device;

import ru.mrgeng.digit.epu.mp.DeviceType;
import ru.mrgeng.digit.epu.mp.Obj;
import ru.mrgeng.digit.epu.mp.passport.enums.TypeOfCommunicationChannelWithPU;
import ru.mrgeng.digit.epu.mp.passport.enums.TypeOfExplosionProtectionKTS;
import ru.mrgeng.digit.epu.mp.passport.enums.TypeOfKTSLocationZone;
import ru.mrgeng.digit.epu.mp.passport.enums.TypeOfPowerSupply;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Table(name = "MP_PASSPORT_KAS")
@Entity(name = "mp_PassportKAS")
public class PassportKAS extends Obj {
    private static final long serialVersionUID = 3443999284854840989L;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    @OnDeleteInverse(value = DeletePolicy.CASCADE)
    private Device device;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_TYPE_ID")
    private DeviceType typeKP;
    @Column(name = "NUMBER_KP")
    private String numberKP;
    @Column(name = "NAME_AND_ADDRESS_KP")
    private String nameAndAddressKP;
    @Column(name = "OWNER_KP")
    private String ownerKP;
    @Column(name = "INVENTORY_NUMBER_KP")
    private String inventoryNumberKP;
    @Column(name = "OWNER_KAS")
    private String ownerKAS;
    @Column(name = "INVENTORY_NUMBER_KAS")
    private String inventoryNumberKAS;
    @Column(name = "PROJECT_CODE_KAS")
    private String projectCodeKAS;
    @Column(name = "MANUFACTURER_OF_KTS")
    private String manufacturerOfKTS;
    @Column(name = "BRAND_OR_MODEL_OF_KTS")
    private String brandORModelOfKTS;
    @Column(name = "DATE_OF_COMMISSIONING_KAS")
    private LocalDate dateOfCommissioningKAS;
    @Column(name = "DESIGNATED_SERVICE_LIFE_OF_KAS")
    private String designatedServiceLifeOfKAS;
    @Column(name = "TYPE_OF_POWER_SUPPLY")
    private String typeOfPowerSupply;
    @Column(name = "TYPE_COMMUNICATION_CHANEL_WITH_PU")
    private String typeOfCommunicationChannelWithPU;
    @Column(name = "TYPE_OF_KTS_LOCATION_ZONE")
    private String typeOfKTSLocationZone;
    @Column(name = "TYPE_OF_EXPLOSION_PROTECTION_KTS")
    private String typeOfExplosionProtectionKTS;
    @OneToMany(mappedBy = "passportKAS")
    @Composition
    private List<TypeAndQuantityPortsKTS> typeAndQuantityPortsKTS;

    public DeviceType getTypeKP() {
        return typeKP;
    }

    public void setTypeKP(DeviceType typeKP) {
        this.typeKP = typeKP;
    }

    public String getNumberKP() {
        return numberKP;
    }

    public void setNumberKP(String numberKP) {
        this.numberKP = numberKP;
    }

    public String getNameAndAddressKP() {
        return nameAndAddressKP;
    }

    public void setNameAndAddressKP(String nameAndAddressKP) {
        this.nameAndAddressKP = nameAndAddressKP;
    }

    public String getOwnerKP() {
        return ownerKP;
    }

    public void setOwnerKP(String ownerKP) {
        this.ownerKP = ownerKP;
    }

    public String getInventoryNumberKP() {
        return inventoryNumberKP;
    }

    public void setInventoryNumberKP(String inventoryNumberKP) {
        this.inventoryNumberKP = inventoryNumberKP;
    }

    public String getOwnerKAS() {
        return ownerKAS;
    }

    public void setOwnerKAS(String ownerKAS) {
        this.ownerKAS = ownerKAS;
    }

    public String getInventoryNumberKAS() {
        return inventoryNumberKAS;
    }

    public void setInventoryNumberKAS(String inventoryNumberKAS) {
        this.inventoryNumberKAS = inventoryNumberKAS;
    }

    public String getProjectCodeKAS() {
        return projectCodeKAS;
    }

    public void setProjectCodeKAS(String projectCodeKAS) {
        this.projectCodeKAS = projectCodeKAS;
    }

    public String getManufacturerOfKTS() {
        return manufacturerOfKTS;
    }

    public void setManufacturerOfKTS(String manufacturerOfKTS) {
        this.manufacturerOfKTS = manufacturerOfKTS;
    }

    public String getBrandORModelOfKTS() {
        return brandORModelOfKTS;
    }

    public void setBrandORModelOfKTS(String brandORModelOfKTS) {
        this.brandORModelOfKTS = brandORModelOfKTS;
    }

    public LocalDate getDateOfCommissioningKAS() {
        return dateOfCommissioningKAS;
    }

    public void setDateOfCommissioningKAS(LocalDate dateOfCommissioningKAS) {
        this.dateOfCommissioningKAS = dateOfCommissioningKAS;
    }

    public String getDesignatedServiceLifeOfKAS() {
        return designatedServiceLifeOfKAS;
    }

    public void setDesignatedServiceLifeOfKAS(String designatedServiceLifeOfKAS) {
        this.designatedServiceLifeOfKAS = designatedServiceLifeOfKAS;
    }

    public TypeOfPowerSupply getTypeOfPowerSupply() {
        return typeOfPowerSupply == null ? null : TypeOfPowerSupply.fromType(typeOfPowerSupply);
    }

    public void setTypeOfPowerSupply(TypeOfPowerSupply typeOfPowerSupply) {
        this.typeOfPowerSupply = typeOfPowerSupply == null ? null : typeOfPowerSupply.getId();
    }

    public TypeOfCommunicationChannelWithPU getTypeOfCommunicationChannelWithPU() {
        return typeOfCommunicationChannelWithPU == null ? null : TypeOfCommunicationChannelWithPU.fromType(typeOfCommunicationChannelWithPU);
    }

    public void setTypeOfCommunicationChannelWithPU(TypeOfCommunicationChannelWithPU typeOfCommunicationChannelWithPU) {
        this.typeOfCommunicationChannelWithPU = typeOfCommunicationChannelWithPU == null ? null : typeOfCommunicationChannelWithPU.getId();
    }

    public TypeOfKTSLocationZone getTypeOfKTSLocationZone() {
        return typeOfKTSLocationZone == null ? null : TypeOfKTSLocationZone.fromType(typeOfKTSLocationZone);
    }

    public void setTypeOfKTSLocationZone(TypeOfKTSLocationZone typeOfKTSLocationZone) {
        this.typeOfKTSLocationZone = typeOfKTSLocationZone == null ? null : typeOfKTSLocationZone.getId();
    }

    public TypeOfExplosionProtectionKTS getTypeOfExplosionProtectionKTS() {
        return typeOfExplosionProtectionKTS == null ? null : TypeOfExplosionProtectionKTS.fromType(typeOfExplosionProtectionKTS);
    }


    public void setTypeOfExplosionProtectionKTS(TypeOfExplosionProtectionKTS typeOfExplosionProtectionKTS) {
        this.typeOfExplosionProtectionKTS = typeOfExplosionProtectionKTS == null ? null : typeOfExplosionProtectionKTS.getId();
    }

    public List<TypeAndQuantityPortsKTS> getTypeAndQuantityPortsKTS() {
        return typeAndQuantityPortsKTS;
    }

    public void setTypeAndQuantityPortsKTS(List<TypeAndQuantityPortsKTS> typeAndQuantityPortsKTS) {
        this.typeAndQuantityPortsKTS = typeAndQuantityPortsKTS;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }
}