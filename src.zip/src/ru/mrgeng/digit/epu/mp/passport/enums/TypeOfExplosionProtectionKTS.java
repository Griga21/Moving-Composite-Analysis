package ru.mrgeng.digit.epu.mp.passport.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum TypeOfExplosionProtectionKTS implements EnumClass<String> {
    FLAMEPROOF_ENCLOSURE("Взрывонепроницаемая оболочка"),
    INTRINSICALLY_SAFE_CIRCUIT("Искробезопасная цепь");

    private String type;

    TypeOfExplosionProtectionKTS(String type) {
        this.type = type;
    }

    @Override
    public String getId() {
        return type;
    }
    @Nullable
    public static TypeOfExplosionProtectionKTS fromType(String type) {
        for (TypeOfExplosionProtectionKTS typeOfExplosionProtectionKTS : TypeOfExplosionProtectionKTS.values()) {
            if (typeOfExplosionProtectionKTS.getId().equals(type)) {
                return typeOfExplosionProtectionKTS;
            }
        }
        return null;
    }
}
