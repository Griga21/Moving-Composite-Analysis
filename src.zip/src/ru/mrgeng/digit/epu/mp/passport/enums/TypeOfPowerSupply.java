package ru.mrgeng.digit.epu.mp.passport.enums;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

/**
 * Тип электроснабжения
 */
public enum TypeOfPowerSupply implements EnumClass<String> {
    CENTRALIZED("Централизованное"),
    RECHARGEBLE_BATTERY("Перезаряжаемая батарея"),
    NON_RECHARGEBLE_BATTERY("Не перезаряжаемая батарея"),
    SOLAR_BATTERY("Солнечная батарея");
    private String type;

    TypeOfPowerSupply(String type) {
        this.type = type;
    }

    @Override
    public String getId() {
        return type;
    }
    @Nullable
    public static TypeOfPowerSupply fromType(String type) {
        for (TypeOfPowerSupply typeOfPowerSupply : TypeOfPowerSupply.values()) {
            if (typeOfPowerSupply.getId().equals(type)) {
                return typeOfPowerSupply;
            }
        }
        return null;
    }

}
