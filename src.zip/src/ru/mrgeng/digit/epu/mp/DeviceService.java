package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.dgcore.entity.Company;

import javax.persistence.*;

@Table(name = "MP_DEVICE_SERVICE", uniqueConstraints = {
        @UniqueConstraint(name = "MP_DEVICE_SERVICE_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_DeviceService")
@NamePattern("%s|name")
public class DeviceService extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "PROTO_ADDRESS")
    private String protoAddress;

    @Column(name = "LOGIN")
    private String login;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "LOG_DATA")
    private Boolean logData = false;

    @Column(name = "SKIP_CALC_DATA")
    private Boolean skipCalcData = false;

    @Column(name = "SEND_ALL_PARAM_CODES")
    private Boolean sendAllParamCodes = false;

    @Column(name = "POLL_AUTO_START")
    private Boolean pollAutoStart = false;

    @Column(name = "PERMITTED_SERVERS")
    protected String permittedServers;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEFAULT_DEVICE_SETTINGS_ID")
    private DefaultDeviceSettings defaultDeviceSettings;

    @Column(name = "COMPANY_ID")
    @SystemLevel
    private Long companyId;

    @MetaProperty(related = "companyId")
    @Transient
    private Company company;

    public String getProtoAddress() {
        return protoAddress;
    }

    public void setProtoAddress(String protoAddress) {
        this.protoAddress = protoAddress;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getSendAllParamCodes() {
        return sendAllParamCodes;
    }

    public Boolean isSendAllParamCodes() {
        return sendAllParamCodes != null && sendAllParamCodes;// если sendAllParamCodes==null, то вернет false
    }

    public void setSendAllParamCodes(Boolean sendAllParamCodes) {
        this.sendAllParamCodes = sendAllParamCodes;
    }

    public Boolean getPollAutoStart() {
        return pollAutoStart;
    }

    public Boolean isPollAutoStart() {
        return pollAutoStart != null && pollAutoStart;// если pollAutoStart==null, то вернет false
    }

    public void setPollAutoStart(Boolean pollAutoStart) {
        this.pollAutoStart = pollAutoStart;
    }

    public String getPermittedServers() {
        return permittedServers;
    }

    public void setPermittedServers(String permittedServers) {
        this.permittedServers = permittedServers;
    }

    public Boolean getLogData() {
        return logData;
    }

    public void setLogData(Boolean logData) {
        this.logData = logData;
    }

    public Boolean getSkipCalcData() {
        return skipCalcData;
    }

    public void setSkipCalcData(Boolean skipCalcData) {
        this.skipCalcData = skipCalcData;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public DefaultDeviceSettings getDefaultDeviceSettings() {
        return defaultDeviceSettings;
    }

    public void setDefaultDeviceSettings(DefaultDeviceSettings defaultDeviceSettings) {
        this.defaultDeviceSettings = defaultDeviceSettings;
    }
}