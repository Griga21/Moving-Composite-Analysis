package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum DeviceActualizationOption implements EnumClass<Integer> , SecondName {
    WITHOUT_MODEL(10, "Устройство без модели"),//продублировал сообщения из message.properties
    WITHOUT_TRANSFORM(20, "Устройство без преобразований (в примененной конфигурации)"),
    FINE(30, "Устройство с актуальными линиями"),
    TOTAL(100, "Всего устройств");

    private Integer id;
    private final String secondName;

    DeviceActualizationOption(Integer value, String secondName) {
        this.id = value;
        this.secondName = secondName;
    }

    public Integer getId() {
        return id;
    }

    @Override
    public String getSecondName() {
        return secondName;
    }

    @Nullable
    public static DeviceActualizationOption fromId(Integer id) {
        for (DeviceActualizationOption at : DeviceActualizationOption.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
