package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;
import org.apache.commons.lang3.builder.HashCodeBuilder;


import javax.persistence.*;
import java.util.Objects;

@Table(name = "MP_GAS_QUALITY_PASSPORT_ATTRIBUTE")
@Entity(name = "mp_GasQualityPassportAttribute")
@NamePattern("%s|paramName")
public class GasQualityPassportAttribute extends StandardEntity {
    private static final long serialVersionUID = 1195491722159396870L;

    public static final String PARAM_GROUP = "pkg";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PASSPORT")
    @OnDeleteInverse(DeletePolicy.CASCADE)
    private GasQualityPassport gasQualityPassport;

    @Column(name = "PARAM_NAME")
    private String paramName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM")
    private Param param;

    @Column(name = "VALUE")
    private Double value;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UNIT")
    private ParamUnit unit;

    @Column(name = "IS_ENTERED_MANUALLY")
    private Boolean isEnteredManually;

    public GasQualityPassport getGasQualityPassport() {
        return gasQualityPassport;
    }

    public void setGasQualityPassport(GasQualityPassport gasQualityPassport) {
        this.gasQualityPassport = gasQualityPassport;
    }

    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public ParamUnit getUnit() {
        return unit;
    }

    public void setUnit(ParamUnit unit) {
        this.unit = unit;
    }

    public Boolean isEnteredManually() {
        return isEnteredManually;
    }

    public void setEnteredManually(Boolean enteredManually) {
        isEnteredManually = enteredManually;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GasQualityPassportAttribute attribute = (GasQualityPassportAttribute) o;
        return Objects.equals(paramName, attribute.paramName);
    }

    @Override
    public int hashCode() {
        HashCodeBuilder builder = new HashCodeBuilder();
        builder.append(paramName);
        return builder.toHashCode();
    }
}