package ru.mrgeng.digit.epu.mp;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import com.haulmont.cuba.core.global.DataManager;
import com.haulmont.cuba.core.global.Events;
import com.haulmont.cuba.core.sys.AppContext;
import com.haulmont.cuba.core.sys.SecurityContext;
import com.haulmont.cuba.core.sys.SecurityContextAwareRunnable;
import com.haulmont.cuba.core.sys.events.AppContextInitializedEvent;
import com.haulmont.cuba.core.sys.serialization.SerializationException;
import com.haulmont.cuba.security.app.TrustedClientService;
import com.haulmont.cuba.security.global.UserSession;
import org.slf4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.mrgeng.digit.epu.config.MpConfig;
import ru.mrgeng.digit.epu.service.*;
import ru.mrgeng.digit.dgcore.event.ReloadConfigEvent;
import ru.mrgeng.digit.dgcore.service.ParamService;
import ru.mrgeng.digit.dgcore.service.ParamPeriodRequestPack;
import ru.mrgeng.digit.dgcore.service.ParamValue;
import ru.mrgeng.digit.dgcore.service.ParamInfo;

import javax.inject.Inject;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component(DeviceDataKeeper.NAME)
public class DeviceDataKeeper implements IDeviceDataKeeper, ApplicationListener<GlobalApplicationEvent> {

    public static final String NAME = "DeviceDataKeeper";

    private Map<String, Set<String>> deviceTypeParamGroup = new ConcurrentHashMap<>();
    private Map<Long, Set<String>> deviceModelLines = new ConcurrentHashMap<>();
    private final Map<String, Boolean> serviceExistMap = new ConcurrentHashMap<>();
    //          service      type      model      devices
    private final Map<String, Map<String, Map<Long, CodesAndObjIds>>> requestStruct = new ConcurrentHashMap<>();
    //       serviceCode ,<deviseCode
    private final Map<String, Map<String, MpService.SingleDeviceData>> resultStorage = new ConcurrentHashMap<>();

    private final AtomicBoolean cycleStarted = new AtomicBoolean();
    private volatile ExecutorService executorService = null;
    private long period = 20_000;
    private boolean immortal = true;

    @Inject
    private MpService mpService;
    @Inject
    private ParamService<String> paramService;
    @Inject
    private Logger log;
    @Inject
    private ParamInfoUtils paramInfoUtils;
    private Date lastUpdateDate;
    @Inject
    private DataManager dataManager;
    @Inject
    private TrustedClientService trustedClientService;
    @Inject
    private DeviceParamService deviceParamService;
    @Inject
    private MpConfig mpConfig;
    @Inject
    private DeviceEventService deviceEventService;
    @Inject
    private DeviceEventHolderService deviceEventHolder;

    @EventListener(AppContextInitializedEvent.class)
    @Order(Events.LOWEST_PLATFORM_PRECEDENCE + 100)
    public void init() {
        lastUpdateDate = new Date();
    }

    @Override
    public void onApplicationEvent(GlobalApplicationEvent event) {
        if (event instanceof ReloadConfigEvent) {
            long before = System.currentTimeMillis();
            AppContext.setSecurityContext(new SecurityContext(trustedClientService.getSystemSession(AppContext.getProperty("cuba.trustedClientPassword"))));
            reloadAllDeviceModel();
            reloadAllDeviceType();
            requestStruct.clear();
            resultStorage.clear();
            serviceExistMap.clear();
            log.info("ReloadConfigEvent processed by ms " + (System.currentTimeMillis() - before));
        } else if (event instanceof ReloadDDKEvent) {
            long before = System.currentTimeMillis();
            AppContext.setSecurityContext(new SecurityContext(trustedClientService.getSystemSession(AppContext.getProperty("cuba.trustedClientPassword"))));
            reloadAllDeviceModel();
            reloadAllDeviceType();
            serviceExistMap.clear();
            reloadAllDeviceByService(((ReloadDDKEvent) event).getServiceCode());
            log.info("ReloadDDKEvent processed by ms " + (System.currentTimeMillis() - before));
        }
    }

    public void logData(String serviceCode) {
        String prefix = "CQLServicePlain(" + serviceCode + ") ";
        log.info(prefix + "serviceExistMap: " + serviceExistMap);
        log.info(prefix + "deviceModelLines: " + deviceModelLines);
        log.info(prefix + "deviceTypeParamGroup: " + deviceTypeParamGroup);
        Map<String, Map<Long, CodesAndObjIds>> deviceByModelAndType = requestStruct.get(serviceCode);
        if (deviceByModelAndType == null) {
            log.info(prefix + "requestStruct is null");
            return;
        }
        log.info(prefix + "deviceByModelAndType: " + deviceByModelAndType);
        log.info(prefix + "requestStruct: " + getStringParamPeriodRequestPackMap(serviceCode, deviceByModelAndType));
    }

    private void reloadAllDeviceByService(String serviceCode) {
        if (serviceCode != null && resultStorage.containsKey(serviceCode)) {// resultStorage -т. к. в requestStruct не попадают 'проблемные' устройства
            Set<String> deviceCodesWithResult = resultStorage.get(serviceCode).keySet();
            Map<String, Map<Long, CodesAndObjIds>> serviceRequestStructNew = new ConcurrentHashMap<>();
            List<Object[]> deviceInfo = deviceParamService.getDeviceModelTypesParamForDDK(serviceCode, deviceCodesWithResult);
            fillRequestStructMap(deviceInfo, serviceRequestStructNew);
            tryFindError(serviceCode, deviceCodesWithResult, deviceInfo, serviceRequestStructNew);
            requestStruct.put(serviceCode, serviceRequestStructNew);
            log.info("Reloaded serviceCode=" + serviceCode + "; deviceInfoCount=" + deviceInfo.size() +
                    "; deviceCodesWithResult=" + deviceCodesWithResult.size());
        }
    }

    private void fillRequestStructMap(List<Object[]> deviceInfo, Map<String, Map<Long, CodesAndObjIds>> serviceRequestStructNew) {
        for (Object[] device : deviceInfo) {
            String deviceCode = (String) device[0];
            String deviceTypeCode = (String) device[1];
            Long deviceModelId = (Long) device[2];
            serviceRequestStructNew.computeIfAbsent(deviceTypeCode, e -> new ConcurrentHashMap<>())
                    .computeIfAbsent(deviceModelId, e -> new CodesAndObjIds())
                    .addDeviceCode(deviceCode);
        }
    }

    private void tryFindError(String serviceCode,
                              Set<String> deviceCodesWithResult, List<Object[]> deviceInfo,
                              Map<String, Map<Long, CodesAndObjIds>> serviceRequestStructNew) {
        if (deviceCodesWithResult.size() == deviceInfo.size())
            return;
        Set<String> deviceCodeFromDB = deviceInfo.stream()
                .map(e -> (String) e[0])
                .collect(Collectors.toSet());
        log.info(serviceCode + " есть расхождения меду кешем последних данных и структурой запроса.");
        log.info(serviceCode + " deviceInfo size=" + deviceInfo.size());
        log.info(serviceCode + " deviceCodesWithResult size=" + deviceCodesWithResult.size());
        log.info(serviceCode + " deviceCodesWithResult=" + deviceCodesWithResult);
        log.info(serviceCode + " deviceCodeFromDB size=" + deviceCodeFromDB.size());
        log.info(serviceCode + " deviceCodeFromDB=" + deviceCodeFromDB);

        Set<String> deviceCodeWithResultNotFoundedInDB = deviceCodesWithResult.stream()
                .filter(code -> !deviceCodeFromDB.contains(code))
                .collect(Collectors.toSet());

        if (!deviceCodeWithResultNotFoundedInDB.isEmpty()) {
            log.warn(serviceCode + " deviceCodeWithResultNotFoundedInDB size=" + deviceCodeWithResultNotFoundedInDB.size());
            log.warn(serviceCode + " deviceCodeWithResultNotFoundedInDB:" + deviceCodeWithResultNotFoundedInDB);
            // Попытка повторно запросить, если не найдены, то удалить из resultStorage отдельные устройства
            List<Object[]> deviceInfoSecondTry = deviceParamService.getDeviceModelTypesParamForDDK(serviceCode, deviceCodeWithResultNotFoundedInDB);
            if (!deviceInfoSecondTry.isEmpty()) {
                List<String> devicesSecondDBTry = deviceInfoSecondTry.stream()
                        .map(e -> (String) e[0])
                        .collect(Collectors.toList());
                log.info(serviceCode + " devicesSecondDBTry size=" + devicesSecondDBTry);
                log.info(serviceCode + " devicesSecondDBTry=" + devicesSecondDBTry);
                fillRequestStructMap(deviceInfoSecondTry, serviceRequestStructNew);

                Set<String> notFoundAgain = deviceCodeWithResultNotFoundedInDB.stream()
                        .filter(code -> !devicesSecondDBTry.contains(code))
                        .collect(Collectors.toSet());
                log.info(serviceCode + " notFoundAgain=" + notFoundAgain);
                if (!notFoundAgain.isEmpty())
                    removeFromResultStorage(serviceCode, notFoundAgain);
            } else {
                removeFromResultStorage(serviceCode, deviceCodeWithResultNotFoundedInDB);
            }
        } else {
            log.info(serviceCode + " все запрошенные устройства найдены в бд");
        }
    }

    private void removeFromResultStorage(String serviceCode, Set<String> deviceCodes) {
        log.info(serviceCode + " из resultStorage будут удалены устройства не найденные в бд");
        Map<String, MpService.SingleDeviceData> deviceServiceData = resultStorage.get(serviceCode);
        if (deviceServiceData == null) {
            log.info(serviceCode + " не найдены кешированные устройства в сервисе; Для устройств " + deviceCodes);
            return;
        }
        deviceCodes.forEach(deviceCode -> {
            MpService.SingleDeviceData deviceData = deviceServiceData.remove(deviceCode);
            if (deviceData != null) {
                log.info(serviceCode + " из resultStorage удален " + deviceCode);
            }
        });
    }

    /**
     * @return период обновления в миллисекундах
     */
    public long getPeriod() {
        return period;
    }

    /**
     * @param period период обновления данных в миллисекундах
     */
    public void setPeriod(long period) {
        this.period = period;
    }

    /**
     * @return дата последнего обновления данных
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }
    
    @Override
    public void fillResultStorage(List<Device> devices) {
    }
    
    public boolean isNotUpdated(Date from) {
        return lastUpdateDate == null || lastUpdateDate.equals(from);
    }

    String getDeviceTypeCode(Device device) {
        if (device.getDeviceModel() != null && device.getDeviceModel().getDeviceType() != null)
            return device.getDeviceModel().getDeviceType().getCode();
        return null;
    }

    /**
     * Получить последние данные по устройству
     *
     * @param device устройство с DeviceService и DeviceModel.DeviceType
     * @return данные по объекту
     */
    public MpService.SingleDeviceData getDeviceData(Device device) {
        String serviceCode = device.getDeviceService().getCode();
        String deviceCode = device.getCode();
        MpService.SingleDeviceData data = resultStorage.computeIfAbsent(serviceCode, e -> new ConcurrentHashMap<>())
                .computeIfAbsent(deviceCode, it -> {
                    MpService.SingleDeviceData singleDeviceData = new MpService.SingleDeviceData();
                    try {
                        String deviceTypeCode = getDeviceTypeCode(device);
                        if (deviceTypeCode == null) {
                            singleDeviceData.errorMessage = "У устройства не указана модель устройства с типом устройства";
                        } else {
                            Long modelId = device.getDeviceModel().getId();
                            Set<String> lines = getDeviceModelLines(modelId);
                            Set<String> paramGroupCodes = getParamGroups(deviceTypeCode);
                            putLines(deviceCode, lines, singleDeviceData);
                            if (!serviceExistMap.computeIfAbsent(serviceCode, this::isServiceExist)) {
                                singleDeviceData.errorMessage = "Не найден сервис: " + serviceCode;
                            } else {
                                Map<String, MpService.DeviceStat> statsMap = mpService.getDeviceStat(serviceCode, Collections.singletonList(deviceCode));
                                singleDeviceData.deviceStat = statsMap.get(deviceCode);
                            }
                            paramGroupCodes.forEach((groupCode) -> {
                                requestStruct.computeIfAbsent(serviceCode, e -> new ConcurrentHashMap<>())
                                        .computeIfAbsent(device.getDeviceModel().getDeviceType().getCode(), e -> new ConcurrentHashMap<>())
                                        .computeIfAbsent(device.getDeviceModel().getId(), e -> new CodesAndObjIds())
                                        .addDeviceCode(device);
                            });
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage() + " serviceCode=" + serviceCode + " deviceCode=" + deviceCode, e);
                    }
                    return singleDeviceData;
                });
        if (cycleStarted.compareAndSet(false, true)) {//только разовый вход
            executorService = Executors.newSingleThreadExecutor();
            String trusted = AppContext.getProperty("cuba.trustedClientPassword");
            UserSession systemSession = trustedClientService.getSystemSession(trusted);
            SecurityContext securityContext = new SecurityContext(systemSession);

            executorService.submit(new SecurityContextAwareRunnable(() -> {
                AppContext.setSecurityContext(securityContext);
                loadData();
            })); // метод будет запущен только 1 раз
        }
        fireNoDataEventIfNeeded(device, data);
        return data;
    }

    private Boolean isServiceExist(String code) {
        List<DeviceService> anyService = dataManager.load(DeviceService.class)
                .query("select e from mp_DeviceService e where e.code = :code")
                .viewProperties("id")
                .parameter("code", code)
                .list();
        return anyService.size() > 0;
    }

    private void loadData() {
        if (getLastUpdateDate() == null) {
            trySleep(period / 2);
        }
        log.info("loadData Started");
        while (immortal) {
            LocalDateTime beforeTime = LocalDateTime.now();
            try {
                reloadAllData();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            LocalDateTime after = LocalDateTime.now();
            lastUpdateDate = new Date();
            long millis = Duration.between(beforeTime, after).toMillis();
            int devCount = requestStruct.values().stream().flatMap(e -> e.values().stream().flatMap(e2 -> e2.values().stream())).mapToInt(e -> e.codesList.size()).sum();
            log.info("Запрос данных выполнен за (мс) " + millis + "; устройств=" + devCount);
            sleepIfNeed(millis);
        }
    }

    private void reloadAllData() {
        period = mpConfig.getDDKUpdateRate();
        requestStruct.entrySet().forEach(serviceEntry -> {// todo формировать packMap с сервисами
            String serviceCode = serviceEntry.getKey();
            Map<String, Map<String, Map<String, ParamValue>>> result;// группа код устройства код параметра значение
            RequestStruct requestStruct;
            try {
                requestStruct = getStringParamPeriodRequestPackMap(serviceEntry.getKey(), serviceEntry.getValue());
                result = paramService.getLastParamValueByPackForDDK(requestStruct.packMap);
            } catch (SerializationException serializationException) {
                log.warn("SerializationException happened, repeat getLastParamValueByPack");
                requestStruct = getStringParamPeriodRequestPackMap(serviceEntry.getKey(), serviceEntry.getValue());
                result = paramService.getLastParamValueByPackForDDK(requestStruct.packMap);//создаем новый объект, так как предыдущий не удалось десериализовать
            }
            Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode = requestStruct.objIdDataByDeviceCode;

            Map<String, MpService.SingleDeviceMpData> mpDataByObjId = objIdDataByDeviceCode.entrySet().stream()
                    .flatMap(e -> e.getValue().entrySet().stream())
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

            result.forEach((groupCode, objectsVal) -> objectsVal.forEach((objId, values) ->
                    mpDataByObjId.get(objId).mapParamWithLastData.computeIfAbsent(groupCode, e -> values)));
            Map<String, MpService.SingleDeviceData> dataByDeviceCode = resultStorage.get(serviceCode);
            objIdDataByDeviceCode.forEach((deviceCode, updatedData) -> {
                MpService.SingleDeviceData singleDeviceData = dataByDeviceCode.get(deviceCode);
                if (singleDeviceData != null)
                    singleDeviceData.points = updatedData;
            });

            if (serviceExistMap.computeIfAbsent(serviceCode, this::isServiceExist)) {
                List<String> devCodes = serviceEntry.getValue().values().stream()
                        .flatMap(e -> e.values().stream().flatMap(codesAndObjIds -> codesAndObjIds.codesList.stream()))
                        .collect(Collectors.toList());

                Map<String, MpService.DeviceStat> statsMap = mpService.getDeviceStat(serviceCode, devCodes);
                Map<String, MpService.SingleDeviceData> hashedMap = resultStorage.get(serviceCode);

                Map<String, Device> mapCodeDevice = getMapCodeDevice(statsMap.keySet(), serviceCode);

                statsMap.forEach((key, value) -> {
                            MpService.SingleDeviceData singleDeviceData = hashedMap.get(key);
                            if (singleDeviceData != null) {
                                singleDeviceData.deviceStat = value;
                                singleDeviceData.errorMessage = null;
                                Device device = mapCodeDevice.get(key);
                                fireNoDataEventIfNeeded(device, singleDeviceData);
                            }
                        }
                );
            }
        });
    }

    private void fireNoDataEventIfNeeded(Device device, MpService.SingleDeviceData data) {
        if (device == null)
            return;
        try {
            String deviceCode = device.getCode();
            String serviceCode = device.getCode();
            Integer timeArrivalData = device.getTimeArrivalData();
            if (!mpConfig.isEnableNoDataEventMonitoring() || data.deviceStat == null || data.deviceStat.lastDataAt == null || timeArrivalData == null) {
                return;
            }
            if (System.currentTimeMillis() - data.deviceStat.lastDataAt.getTime() > TimeUnit.SECONDS.toMillis(timeArrivalData) + mpConfig.getDeviceTimeOutMs() &&
                    !deviceEventHolder.checkNoDataEventByDeviceCode(deviceCode)) {
                DeviceEventService.EventInfo eventInfo = new DeviceEventService.EventInfo();
                eventInfo.type = DeviceEventType.NO_DATA;
                eventInfo.objId = device.getId();
                eventInfo.eventTs = LocalDateTime.now();
                eventInfo.dataTs = Instant.ofEpochMilli(data.deviceStat.lastDataAt.getTime())
                        .atZone(ZoneId.systemDefault())
                        .toLocalDateTime();
                eventInfo.msg = String.format("Нет данных по устройству %s, сервис взаимодействия %s", deviceCode, serviceCode);
                log.info(eventInfo.msg);
                deviceEventService.fireDeviceEvent(eventInfo);
            }
        } catch (Exception e) {
            log.info("Ошибка fireNoDataEventIfNeeded: device.id=" + device.getId(), e);
        }
    }

    private Map<String, Device> getMapCodeDevice(Set<String> codes, String serviceCode) {
        return dataManager.load(Device.class)
                .query("where e.code in :codes and e.deviceService.code = :serviceCode")
                .parameter("codes", new ArrayList<>(codes))
                .parameter("serviceCode", serviceCode)
                .list()
                .stream()
                .collect(Collectors.toMap(MpObj::getCode, Function.identity(), (device1, device2) -> {
                    log.info("Duplicate device by code {}, device service {}", device1.getCode(), serviceCode);
                    return device1;
                }));
    }

    private RequestStruct getStringParamPeriodRequestPackMap(String serviceCode, Map<String, Map<Long, CodesAndObjIds>> objInfo) {
        Map<String, ParamPeriodRequestPack> packMap = new HashMap<>();
        Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode = new HashMap<>();// код девайса

        objInfo.forEach((typeCode, deviceModelMap) -> {
            List<String> objIdList = deviceModelMap.entrySet().stream()
                    .flatMap(entry -> entry.getValue().calcObjIdStream(entry.getKey(), objIdDataByDeviceCode))
                    .collect(Collectors.toList());
            getParamGroups(typeCode).forEach(paramGroupCode -> {
                ParamInfo pi = new ParamInfo();
                pi.paramClass = MpService.PARAM_CLASS;
                pi.paramGroup = paramGroupCode;
                pi.sourceId = serviceCode;
                ParamPeriodRequestPack pack = new ParamPeriodRequestPack(pi, objIdList);
                packMap.put(paramGroupCode, pack);
            });
        });
        return new RequestStruct(objIdDataByDeviceCode, packMap);
    }

    class RequestStruct {
        Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode;
        Map<String, ParamPeriodRequestPack> packMap;

        public RequestStruct(Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode, Map<String, ParamPeriodRequestPack> packMap) {
            this.objIdDataByDeviceCode = objIdDataByDeviceCode;
            this.packMap = packMap;
        }

        @Override
        public String toString() {
            return "RequestStruct{" +
                    "packMap=" + packMap +
                    '}';
        }
    }

    private Set<String> getParamGroups(String deviceTypeCode) {
        return deviceTypeParamGroup.computeIfAbsent(deviceTypeCode, e -> paramInfoUtils.getCalcParamsInfo(deviceTypeCode).groups.keySet());
    }

    private Set<String> getDeviceModelLines(Long modelId) {
        return deviceModelLines.computeIfAbsent(modelId,
                e -> deviceParamService.getMeasPointsByDeviceModelId(modelId).stream()
                        .map(CodeNameObj::getCode)
                        .collect(Collectors.toSet()));
    }

    private void reloadAllDeviceType() {
        deviceTypeParamGroup = new ConcurrentHashMap<>(deviceParamService.getAllParamGroupCodeByDeviceTypeCode());
    }

    private void reloadAllDeviceModel() {
        deviceModelLines = new ConcurrentHashMap<>(deviceParamService.getAllMeasPointsByModelId());
    }

    class CodesAndObjIds {
        Set<String> codesList = new HashSet<>();

        public void addDeviceCode(Device device) {
            addDeviceCode(device.getCode());
        }

        public void addDeviceCode(String deviceCode) {
            codesList.add(deviceCode);// is thread safe?
        }

        public Stream<String> calcObjIdStream(Long modelId, Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode) {
            Set<String> lines = getDeviceModelLines(modelId);
            codesList.forEach(code -> objIdDataByDeviceCode.computeIfAbsent(code, e -> new HashMap<>())// если нет точек измерения, то только 1 objId
                    .put(code, new MpService.SingleDeviceMpData(null)));
            if (lines.isEmpty())
                return codesList.stream();
            return Stream.concat(codesList.stream(),
                    codesList.stream().flatMap(devCode -> lines.stream().map(line -> {
                        String objId = devCode + "." + line;
                        objIdDataByDeviceCode.computeIfAbsent(devCode, e -> new HashMap<>())
                                .put(objId, new MpService.SingleDeviceMpData(line));
                        return objId;
                    })));
        }

        @Override
        public String toString() {
            return "CodesAndObjIds{" +
                    "codesList=" + codesList +
                    '}';
        }
    }

    private void putLines(String deviceCode, Set<String> lines, MpService.SingleDeviceData singleDeviceData) {
        singleDeviceData.points.put(deviceCode, new MpService.SingleDeviceMpData(null));
        for (String lineCode : lines) {
            MpService.SingleDeviceMpData mpData = new MpService.SingleDeviceMpData(lineCode);
            singleDeviceData.points.put(deviceCode + "." + lineCode, mpData);
        }
    }

    private void trySleep(long period) {
        try {
            Thread.sleep(period);
        } catch (InterruptedException e) {
            log.info(e.getMessage());
        }
    }

    private void sleepIfNeed(long millis) {
        long sleepTime = period - millis;
        if (sleepTime > 0) {
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                log.error("sleep error for millis " + sleepTime, e);
            }
        }
    }
}