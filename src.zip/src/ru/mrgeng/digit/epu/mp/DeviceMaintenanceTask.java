package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.cuba.core.entity.BaseLongIdEntity;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.dgcore.entity.SysUser;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Table(name = "MP_DEVICE_MAINTENANCE_TASK")
@Entity(name = "mp_DeviceMaintenanceTask")
public class DeviceMaintenanceTask extends BaseLongIdEntity {

    private static final long serialVersionUID = -2553965343855712211L;

    @Column(name = "TECHNICIAN_NAME")
    private String technicianName;

    @Column(name = "SENDING_TEAM_TIME")
    private LocalDateTime sendingTeamTime;

    @Column(name = "SPECIFIED_CAUSE_INCIDENT")
    private String specifiedCauseIncident;

    @Column(name = "CREATE_TASK_TIME")
    private LocalDateTime createTaskTime;

    @Column(name = "CLOSE_TASK_TIME")
    private LocalDateTime closeTaskTime;

    @OneToMany(mappedBy = "deviceMaintenanceTask")
    private List<DeviceEvent> deviceEvents;

    @SystemLevel
    @Column(name = "EXPL_USER_ID")
    private UUID explUserId;

    @MetaProperty(related = "explUserId")
    @Transient
    private SysUser explUser;

    @Column(name = "NOTE")
    private String note;

    @Column(name = "TASK_STATUS")
    private Integer taskStatus;

    public String getTechnicianName() {
        return technicianName;
    }

    public void setTechnicianName(String technicianName) {
        this.technicianName = technicianName;
    }

    public LocalDateTime getSendingTeamTime() {
        return sendingTeamTime;
    }

    public void setSendingTeamTime(LocalDateTime sendingTeamTime) {
        this.sendingTeamTime = sendingTeamTime;
    }

    public String getSpecifiedCauseIncident() {
        return specifiedCauseIncident;
    }

    public void setSpecifiedCauseIncident(String specifiedCauseIncident) {
        this.specifiedCauseIncident = specifiedCauseIncident;
    }

    public LocalDateTime getCreateTaskTime() {
        return createTaskTime;
    }

    public void setCreateTaskTime(LocalDateTime createTaskTime) {
        this.createTaskTime = createTaskTime;
    }

    public LocalDateTime getCloseTaskTime() {
        return closeTaskTime;
    }

    public void setCloseTaskTime(LocalDateTime closeTaskTime) {
        this.closeTaskTime = closeTaskTime;
    }

    public List<DeviceEvent> getDeviceEvents() {
        return deviceEvents;
    }

    public void setDeviceEvents(List<DeviceEvent> deviceEvents) {
        this.deviceEvents = deviceEvents;
    }

    public UUID getExplUserId() {
        return explUserId;
    }

    public void setExplUserId(UUID explUserId) {
        this.explUserId = explUserId;
    }

    public SysUser getExplUser() {
        return explUser;
    }

    public void setExplUser(SysUser explUser) {
        this.explUser = explUser;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public DeviceTaskStatus getTaskStatus() {
        return taskStatus == null ? null : DeviceTaskStatus.fromId(taskStatus);
    }

    public void setTaskStatus(DeviceTaskStatus taskStatus) {
        this.taskStatus = taskStatus == null ? null : taskStatus.getId();
    }
}