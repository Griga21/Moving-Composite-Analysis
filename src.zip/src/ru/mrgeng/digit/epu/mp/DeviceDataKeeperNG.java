package ru.mrgeng.digit.epu.mp;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import com.haulmont.cuba.core.global.Events;
import com.haulmont.cuba.core.sys.AppContext;
import com.haulmont.cuba.core.sys.SecurityContext;
import com.haulmont.cuba.core.sys.SecurityContextAwareRunnable;
import com.haulmont.cuba.core.sys.events.AppContextInitializedEvent;
import com.haulmont.cuba.core.sys.serialization.SerializationException;
import com.haulmont.cuba.security.app.TrustedClientService;
import org.slf4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.mrgeng.digit.dgcore.event.ReloadConfigEvent;
import ru.mrgeng.digit.dgcore.service.ParamInfo;
import ru.mrgeng.digit.dgcore.service.ParamPeriodRequestPack;
import ru.mrgeng.digit.dgcore.service.ParamService;
import ru.mrgeng.digit.dgcore.service.ParamValue;
import ru.mrgeng.digit.epu.config.MpConfig;
import ru.mrgeng.digit.epu.service.CodeNameObj;
import ru.mrgeng.digit.epu.service.DeviceParamService;
import ru.mrgeng.digit.epu.service.MpService;

import javax.inject.Inject;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component(DeviceDataKeeperNG.NAME)
public class DeviceDataKeeperNG implements IDeviceDataKeeper, ApplicationListener<GlobalApplicationEvent> {

    public static final String NAME = "DeviceDataKeeperNG";

    private Map<String, Set<String>> deviceTypeParamGroup = new ConcurrentHashMap<>();
    private Map<Long, Set<String>> deviceModelLines = new ConcurrentHashMap<>();
    //          service      type      model      devices
    private final Map<String, Map<String, Map<Long, CodesAndObjIds>>> requestStruct = new ConcurrentHashMap<>();
    //       serviceCode ,<deviseCode
    private final Map<String, Map<String, MpService.SingleDeviceData>> resultStorage = new ConcurrentHashMap<>();

    private final AtomicBoolean cycleStarted = new AtomicBoolean();
    private volatile ExecutorService executorService = null;
    private final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    private long period = 20_000;
    private boolean immortal = true;
    private Date lastUpdateDate;
    
    @Inject
    private MpService mpService;
    @Inject
    private ParamService<String> paramService;
    @Inject
    private Logger log;
    @Inject
    private ParamInfoUtils paramInfoUtils;
    @Inject
    private TrustedClientService trustedClientService;
    @Inject
    private DeviceParamService deviceParamService;
    @Inject
    private MpConfig mpConfig;

    @EventListener(AppContextInitializedEvent.class)
    @Order(Events.LOWEST_PLATFORM_PRECEDENCE + 100)
    public void init() {
        log.info("DeviceDataKeeperNG started");
        lastUpdateDate = new Date();
    }

    @Override
    public void onApplicationEvent(GlobalApplicationEvent event) {
        if (event instanceof ReloadConfigEvent) {
            long before = System.currentTimeMillis();
            AppContext.setSecurityContext(securityContext());
            reloadAllDeviceModel();
            reloadAllDeviceType();
            requestStruct.clear();
            resultStorage.clear();
            log.info("ReloadConfigEvent processed by ms " + (System.currentTimeMillis() - before));
        } else if (event instanceof ReloadDDKEvent) {
            long before = System.currentTimeMillis();
            AppContext.setSecurityContext(securityContext());
            reloadAllDeviceModel();
            reloadAllDeviceType();
            reloadAllDeviceByService(((ReloadDDKEvent) event).getServiceCode());
            log.info("ReloadDDKEvent processed by ms " + (System.currentTimeMillis() - before));
        }
    }
    
    private SecurityContext securityContext() {
        return new SecurityContext(trustedClientService.getSystemSession(
            AppContext.getProperty("cuba.trustedClientPassword")
        ));
    }

    public void logData(String serviceCode) {
        String prefix = "CQLServicePlain(" + serviceCode + ") ";
        log.info(prefix + "deviceModelLines: " + deviceModelLines);
        log.info(prefix + "deviceTypeParamGroup: " + deviceTypeParamGroup);
        Map<String, Map<Long, CodesAndObjIds>> deviceByModelAndType = requestStruct.get(serviceCode);
        if (deviceByModelAndType == null) {
            log.info(prefix + "requestStruct is null");
            return;
        }
        log.info(prefix + "deviceByModelAndType: " + deviceByModelAndType);
        log.info(prefix + "requestStruct: " + getStringParamPeriodRequestPackMap(serviceCode, deviceByModelAndType));
    }

    private void reloadAllDeviceByService(String serviceCode) {
        if (serviceCode != null && resultStorage.containsKey(serviceCode)) {// resultStorage -т. к. в requestStruct не попадают 'проблемные' устройства
            Set<String> deviceCodesWithResult = resultStorage.get(serviceCode).keySet();
            Map<String, Map<Long, CodesAndObjIds>> serviceRequestStructNew = new ConcurrentHashMap<>();
            List<Object[]> deviceInfo = deviceParamService.getDeviceModelTypesParamForDDK(serviceCode, deviceCodesWithResult);
            fillRequestStructMap(deviceInfo, serviceRequestStructNew);
            tryFindError(serviceCode, deviceCodesWithResult, deviceInfo, serviceRequestStructNew);
            requestStruct.put(serviceCode, serviceRequestStructNew);
            log.info("Reloaded serviceCode=" + serviceCode + "; deviceInfoCount=" + deviceInfo.size() +
                    "; deviceCodesWithResult=" + deviceCodesWithResult.size());
        }
    }
    
    private void fillRequestStructMap(List<Object[]> deviceInfo, Map<String, Map<Long, CodesAndObjIds>> serviceRequestStructNew) {
        for (Object[] device : deviceInfo) {
            String deviceCode = (String) device[0];
            String deviceTypeCode = (String) device[1];
            Long deviceModelId = (Long) device[2];
            serviceRequestStructNew.computeIfAbsent(deviceTypeCode, e -> new ConcurrentHashMap<>())
                    .computeIfAbsent(deviceModelId, e -> new CodesAndObjIds())
                    .addDeviceCode(deviceCode);
        }
    }
    
    private void tryFindError(String serviceCode,
                              Set<String> deviceCodesWithResult, List<Object[]> deviceInfo,
                              Map<String, Map<Long, CodesAndObjIds>> serviceRequestStructNew) {
        if (deviceCodesWithResult.size() == deviceInfo.size())
            return;
        Set<String> deviceCodeFromDB = deviceInfo.stream()
                .map(e -> (String) e[0])
                .collect(Collectors.toSet());
        log.info(serviceCode + " есть расхождения меду кешем последних данных и структурой запроса.");
        log.info(serviceCode + " deviceInfo size=" + deviceInfo.size());
        log.info(serviceCode + " deviceCodesWithResult size=" + deviceCodesWithResult.size());
        log.info(serviceCode + " deviceCodesWithResult=" + deviceCodesWithResult);
        log.info(serviceCode + " deviceCodeFromDB size=" + deviceCodeFromDB.size());
        log.info(serviceCode + " deviceCodeFromDB=" + deviceCodeFromDB);

        Set<String> deviceCodeWithResultNotFoundedInDB = deviceCodesWithResult.stream()
                .filter(code -> !deviceCodeFromDB.contains(code))
                .collect(Collectors.toSet());

        if (!deviceCodeWithResultNotFoundedInDB.isEmpty()) {
            log.warn(serviceCode + " deviceCodeWithResultNotFoundedInDB size=" + deviceCodeWithResultNotFoundedInDB.size());
            log.warn(serviceCode + " deviceCodeWithResultNotFoundedInDB:" + deviceCodeWithResultNotFoundedInDB);
            // Попытка повторно запросить, если не найдены, то удалить из resultStorage отдельные устройства
            List<Object[]> deviceInfoSecondTry = deviceParamService.getDeviceModelTypesParamForDDK(serviceCode, deviceCodeWithResultNotFoundedInDB);
            if (!deviceInfoSecondTry.isEmpty()) {
                List<String> devicesSecondDBTry = deviceInfoSecondTry.stream()
                        .map(e -> (String) e[0])
                        .collect(Collectors.toList());
                log.info(serviceCode + " devicesSecondDBTry size=" + devicesSecondDBTry);
                log.info(serviceCode + " devicesSecondDBTry=" + devicesSecondDBTry);
                fillRequestStructMap(deviceInfoSecondTry, serviceRequestStructNew);

                Set<String> notFoundAgain = deviceCodeWithResultNotFoundedInDB.stream()
                        .filter(code -> !devicesSecondDBTry.contains(code))
                        .collect(Collectors.toSet());
                log.info(serviceCode + " notFoundAgain=" + notFoundAgain);
                if (!notFoundAgain.isEmpty())
                    removeFromResultStorage(serviceCode, notFoundAgain);
            } else {
                removeFromResultStorage(serviceCode, deviceCodeWithResultNotFoundedInDB);
            }
        } else {
            log.info(serviceCode + " все запрошенные устройства найдены в бд");
        }
    }
    
    private void removeFromResultStorage(String serviceCode, Set<String> deviceCodes) {
        log.info(serviceCode + " из resultStorage будут удалены устройства не найденные в бд");
        Map<String, MpService.SingleDeviceData> deviceServiceData = resultStorage.get(serviceCode);
        if (deviceServiceData == null) {
            log.info(serviceCode + " не найдены кешированные устройства в сервисе; Для устройств " + deviceCodes);
            return;
        }
        deviceCodes.forEach(deviceCode -> {
            MpService.SingleDeviceData deviceData = deviceServiceData.remove(deviceCode);
            if (deviceData != null) {
                log.info(serviceCode + " из resultStorage удален " + deviceCode);
            }
        });
    }

    /**
     * @return период обновления в миллисекундах
     */
    public long getPeriod() {
        return period;
    }

    /**
     * @param period период обновления данных в миллисекундах
     */
    public void setPeriod(long period) {
        this.period = period;
    }

    /**
     * @return дата последнего обновления данных
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }
    
    public boolean isNotUpdated(Date from) {
        return lastUpdateDate == null || lastUpdateDate.equals(from);
    }
    
    private String getDeviceTypeCode(Device device) {
        if (device.getDeviceModel() != null && device.getDeviceModel().getDeviceType() != null)
            return device.getDeviceModel().getDeviceType().getCode();
        return null;
    }
    
    @Override
    public void fillResultStorage(List<Device> devices) {
        long start = System.currentTimeMillis();
        Map<String, Set<String>> deviceServiceCodes = resultStorage.entrySet().stream().collect(
            Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().keySet())
        );
        Predicate<Device> deviceIsNotPresentInResultStoragePredicate = device -> {
            String deviceCode = device.getCode();
            String serviceCode = device.getServiceCode();
            return deviceCode != null
                && serviceCode != null
                && Optional.ofNullable(deviceServiceCodes.get(serviceCode)).map(set -> !set.contains(deviceCode)).orElse(true);
        };
        deviceParamService.getMeasPointsByDeviceModelIds(
            devices.stream().map(device -> device.getDeviceModel().getId()).collect(Collectors.toList())
        ).forEach((key, value) -> deviceModelLines.putIfAbsent(key, value));
        paramInfoUtils.getCalcParamsInfo(devices.stream().map(this::getDeviceTypeCode).collect(Collectors.toList()))
            .forEach((key, value) -> deviceTypeParamGroup.putIfAbsent(key, value));
        
        devices.stream().filter(deviceIsNotPresentInResultStoragePredicate).forEach(this::getDeviceDataOld);
        
        long getDeviceDataOldTs = System.currentTimeMillis();
        log.info("getDeviceDataOld took {} ms.", getDeviceDataOldTs - start);
        if (devices.stream().anyMatch(deviceIsNotPresentInResultStoragePredicate)) {
            reloadAllData();
        }
        log.info("reloadAllData took {} ms.", System.currentTimeMillis() - getDeviceDataOldTs);
        log.info("fillResultStorage took {} ms.", System.currentTimeMillis() - start);
    }
    
    private MpService.SingleDeviceData getDeviceDataOld(Device device) {
        String serviceCode = device.getServiceCode();
        String deviceCode = device.getCode();
        MpService.SingleDeviceData data = resultStorage.computeIfAbsent(serviceCode, e -> new ConcurrentHashMap<>())
            .computeIfAbsent(deviceCode, it -> {
                MpService.SingleDeviceData singleDeviceData = new MpService.SingleDeviceData();
                try {
                    String deviceTypeCode = getDeviceTypeCode(device);
                    if (deviceTypeCode == null) {
                        singleDeviceData.errorMessage = "У устройства не указана модель устройства с типом устройства";
                    } else {
                        Long modelId = device.getDeviceModel().getId();
                        Set<String> lines = getDeviceModelLines(modelId);
                        
                        Set<String> paramGroupCodes = getParamGroups(deviceTypeCode);
                        putLines(deviceCode, lines, singleDeviceData);
                        if (serviceCode == null) {
                            singleDeviceData.errorMessage = "Не найден сервис: " + serviceCode;
                        } else {
                            Map<String, MpService.DeviceStat> statsMap = mpService.getDeviceStat(serviceCode, Collections.singletonList(deviceCode));
                            singleDeviceData.deviceStat = statsMap.get(deviceCode);
                        }
                        paramGroupCodes.forEach((groupCode) -> requestStruct.computeIfAbsent(serviceCode, e -> new ConcurrentHashMap<>())
                            .computeIfAbsent(device.getDeviceModel().getDeviceType().getCode(), e -> new ConcurrentHashMap<>())
                            .computeIfAbsent(device.getDeviceModel().getId(), e -> new CodesAndObjIds())
                            .addDeviceCode(deviceCode));
                    }
                } catch (Exception e) {
                    log.error(e.getMessage() + " serviceCode=" + serviceCode + " deviceCode=" + deviceCode, e);
                }
                return singleDeviceData;
            });
        
        if (cycleStarted.compareAndSet(false, true)) {//только разовый вход
            executorService = Executors.newSingleThreadExecutor();
            executorService.submit(new SecurityContextAwareRunnable(() -> {
                AppContext.setSecurityContext(securityContext());
                loadData();
            })); // метод будет запущен только 1 раз
        }
        return data;
    }

    /**
     * Получить последние данные по устройству
     *
     * @param device устройство с DeviceService и DeviceModel.DeviceType
     * @return данные по объекту
     */
    @Override
    public MpService.SingleDeviceData getDeviceData(Device device) {
        String serviceCode = device.getServiceCode();
        String deviceCode = device.getCode();
        if (resultStorage.containsKey(serviceCode) && resultStorage.get(serviceCode).containsKey(deviceCode)) {
            return getDeviceDataOld(device);
        } else {
            MpService.SingleDeviceData data = getDeviceDataOld(device);
            if (data.errorMessage != null) {
                return data;
            }
            CodesAndObjIds objId = requestStruct.get(serviceCode).get(device.getDeviceModel().getDeviceType().getCode()).get(device.getDeviceModel().getId());
            Map<Long, CodesAndObjIds> m1 = Map.of(device.getDeviceModel().getId(), objId);
            Map<String, Map<Long, CodesAndObjIds>> m2 = Map.of(getDeviceTypeCode(device), m1);
            Map.Entry<String, Map<String, Map<Long, CodesAndObjIds>>> entry = Map.entry(serviceCode, m2);
            update(entry);
            return data;
        }
    }
    
    private void loadData() {
        if (getLastUpdateDate() == null) {
            trySleep(period / 2);
        }
        while (immortal) {
            LocalDateTime beforeTime = LocalDateTime.now();
            try {
                reloadAllData();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            LocalDateTime after = LocalDateTime.now();
            lastUpdateDate = new Date();
            long millis = Duration.between(beforeTime, after).toMillis();
            int devCount = requestStruct.values().stream().flatMap(e -> e.values().stream().flatMap(e2 -> e2.values().stream())).mapToInt(e -> e.codesList.size()).sum();
            if (millis > 1000)
                log.info("Запрос данных выполнен за (мс) " + millis + "; устройств=" + devCount);
            sleepIfNeed(millis);
        }
    }

    private void update(Map.Entry<String, Map<String, Map<Long, CodesAndObjIds>>> serviceEntry) {
        String serviceCode = serviceEntry.getKey();
        Map<String, Map<String, Map<String, ParamValue>>> result;// группа код устройства код параметра значение
        DeviceDataKeeperNG.RequestStruct requestStruct;
        try {
            requestStruct = getStringParamPeriodRequestPackMap(serviceEntry);
            result = paramService.getLastParamValueByPackForDDK(requestStruct.packMap);
        } catch (SerializationException serializationException) {
            log.warn("SerializationException happened, repeat getLastParamValueByPack");
            requestStruct = getStringParamPeriodRequestPackMap(serviceEntry);
            result = paramService.getLastParamValueByPackForDDK(requestStruct.packMap);//создаем новый объект, так как предыдущий не удалось десериализовать
        }
        Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode = requestStruct.objIdDataByDeviceCode;

        Map<String, MpService.SingleDeviceMpData> mpDataByObjId = objIdDataByDeviceCode.entrySet().stream()
                .flatMap(e -> e.getValue().entrySet().stream())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        result.forEach((groupCode, objectsVal) -> objectsVal.forEach((objId, values) ->
                mpDataByObjId.get(objId).mapParamWithLastData.computeIfAbsent(groupCode, e -> values)));
        Map<String, MpService.SingleDeviceData> dataByDeviceCode = resultStorage.get(serviceCode);
        objIdDataByDeviceCode.forEach((deviceCode, updatedData) -> {
            MpService.SingleDeviceData singleDeviceData = dataByDeviceCode.get(deviceCode);
            if (singleDeviceData != null)
                singleDeviceData.points = updatedData;
        });

        if (serviceCode != null) {
            List<String> devCodes = serviceEntry.getValue().values().stream()
                    .flatMap(e -> e.values().stream().flatMap(codesAndObjIds -> codesAndObjIds.codesList.stream()))
                    .collect(Collectors.toList());

            Map<String, MpService.DeviceStat> statsMap = mpService.getDeviceStat(serviceCode, devCodes);
            Map<String, MpService.SingleDeviceData> hashedMap = resultStorage.get(serviceCode);

            statsMap.forEach((key, value) -> {
                        MpService.SingleDeviceData singleDeviceData = hashedMap.get(key);
                        if (singleDeviceData != null) {
                            singleDeviceData.deviceStat = value;
                            singleDeviceData.errorMessage = null;
                        }
                    }
            );
        }
    }

    private void reloadAllData() {
        period = mpConfig.getDDKUpdateRate();
        
        CompletableFuture.allOf(requestStruct.entrySet().stream()
            .map(entry -> CompletableFuture.runAsync(() -> {
                AppContext.setSecurityContext(securityContext());
                update(entry);
            }, executor)).toArray(CompletableFuture[]::new)).join();
    }
    
    private Set<String> getDeviceModelLines(Long modelId) {
        return deviceModelLines.computeIfAbsent(modelId,
            e -> deviceParamService.getMeasPointsByDeviceModelId(modelId).stream()
                .map(CodeNameObj::getCode)
                .collect(Collectors.toSet()));
    }
    
    private RequestStruct getStringParamPeriodRequestPackMap(String serviceCode, Map<String, Map<Long, CodesAndObjIds>> objInfo) {
        Map<String, ParamPeriodRequestPack> packMap = new HashMap<>();
        Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode = new HashMap<>();// код девайса

        objInfo.forEach((typeCode, deviceModelMap) -> {
            List<String> objIdList = deviceModelMap.entrySet().stream()
                    .flatMap(entry -> entry.getValue().calcObjIdStream(entry.getKey(), objIdDataByDeviceCode))
                    .collect(Collectors.toList());
            getParamGroups(typeCode).forEach(paramGroupCode -> {
                ParamInfo pi = new ParamInfo();
                pi.paramClass = MpService.PARAM_CLASS;
                pi.paramGroup = paramGroupCode;
                pi.sourceId = serviceCode;
                ParamPeriodRequestPack pack = new ParamPeriodRequestPack(pi, objIdList);
                packMap.put(paramGroupCode, pack);
            });
        });
        return new RequestStruct(objIdDataByDeviceCode, packMap);
    }
    
    private RequestStruct getStringParamPeriodRequestPackMap(Map.Entry<String, Map<String, Map<Long, CodesAndObjIds>>> serviceEntry) {
        return getStringParamPeriodRequestPackMap(serviceEntry.getKey(), serviceEntry.getValue());
    }

    class RequestStruct {
        Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode;
        Map<String, ParamPeriodRequestPack> packMap;

        public RequestStruct(Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode, Map<String, ParamPeriodRequestPack> packMap) {
            this.objIdDataByDeviceCode = objIdDataByDeviceCode;
            this.packMap = packMap;
        }

        @Override
        public String toString() {
            return "RequestStruct{" +
                    "packMap=" + packMap +
                    '}';
        }
    }

    private Set<String> getParamGroups(String deviceTypeCode) {
        return deviceTypeParamGroup.computeIfAbsent(deviceTypeCode, e -> paramInfoUtils.getCalcParamsInfo(deviceTypeCode).groups.keySet());
    }

    private void reloadAllDeviceType() {
        deviceTypeParamGroup = new ConcurrentHashMap<>(deviceParamService.getAllParamGroupCodeByDeviceTypeCode());
    }

    private void reloadAllDeviceModel() {
        deviceModelLines = new ConcurrentHashMap<>(deviceParamService.getAllMeasPointsByModelId());
    }

    class CodesAndObjIds {
        Set<String> codesList = ConcurrentHashMap.newKeySet();
        
        public void addDeviceCode(String deviceCode) {
            codesList.add(deviceCode);
        }
        
        public Stream<String> calcObjIdStream(Long modelId, Map<String, Map<String, MpService.SingleDeviceMpData>> objIdDataByDeviceCode) {
            Set<String> lines = getDeviceModelLines(modelId);
            codesList.forEach(code -> objIdDataByDeviceCode.computeIfAbsent(code, e -> new HashMap<>())// если нет точек измерения, то только 1 objId
                    .put(code, new MpService.SingleDeviceMpData(null)));
            if (lines.isEmpty())
                return codesList.stream();
            return Stream.concat(codesList.stream(),
                    codesList.stream().flatMap(devCode -> lines.stream().map(line -> {
                        String objId = devCode + "." + line;
                        objIdDataByDeviceCode.computeIfAbsent(devCode, e -> new HashMap<>())
                                .put(objId, new MpService.SingleDeviceMpData(line));
                        return objId;
                    })));
        }

        @Override
        public String toString() {
            return "CodesAndObjIds{" +
                    "codesList=" + codesList +
                    '}';
        }
    }

    private void putLines(String deviceCode, Set<String> lines, MpService.SingleDeviceData singleDeviceData) {
        singleDeviceData.points.put(deviceCode, new MpService.SingleDeviceMpData(null));
        for (String lineCode : lines) {
            MpService.SingleDeviceMpData mpData = new MpService.SingleDeviceMpData(lineCode);
            singleDeviceData.points.put(deviceCode + "." + lineCode, mpData);
        }
    }

    private void trySleep(long period) {
        try {
            Thread.sleep(period);
        } catch (InterruptedException e) {
            log.info(e.getMessage());
        }
    }

    private void sleepIfNeed(long millis) {
        long sleepTime = period - millis;
        if (sleepTime > 0) {
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                log.error("sleep error for millis " + sleepTime, e);
            }
        }
    }
}