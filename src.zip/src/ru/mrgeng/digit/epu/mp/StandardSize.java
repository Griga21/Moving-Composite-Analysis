package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "MP_STANDARD_SIZE")
@Entity(name = "mp_StandardSize")
@NamePattern("%s|name")
public class StandardSize extends Obj {
    private static final long serialVersionUID = -5118026370061347470L;

    @Column(name = "NAME")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}