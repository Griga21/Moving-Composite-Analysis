package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Listeners;

import javax.persistence.*;

/**
 * Группа обработанных/приведенных параметров
 */
@NamePattern("%s|name")
@Table(name = "MP_PARAM_GROUP", uniqueConstraints = {
        @UniqueConstraint(name = "UC_PARAM_GROUP_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_ParamGroup")
@Listeners("mp_CalcParamsChangesListener")
public class ParamGroup extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_TYPE_ID")
    private DeviceType deviceType;

    @Column(name = "DATA_PERIODICITY")
    protected Integer dataPeriodicity;

    public DataPeriodicity getDataPeriodicity() {
        return dataPeriodicity == null ? null : DataPeriodicity.fromId(dataPeriodicity);
    }

    public void setDataPeriodicity(DataPeriodicity dataPeriodicity) {
        this.dataPeriodicity = dataPeriodicity == null ? null : dataPeriodicity.getId();
    }


    public DeviceType getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }
}