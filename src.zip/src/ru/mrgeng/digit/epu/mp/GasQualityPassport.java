package ru.mrgeng.digit.epu.mp;


import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.OnDelete;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Table(name = "MP_GAS_QUALITY_PASSPORT")
@Entity(name = "mp_GasQualityPassport")
@NamePattern("%s|passportNumber")
public class GasQualityPassport extends Obj {
    private static final long serialVersionUID = -6229357536344434601L;
    
    @Column(name = "SENT_TS")
    private LocalDateTime sentTs;

    @Column(name = "SENT_BY")
    private String sentBy;

    @Column(name = "FORMATION_DATE")
    private LocalDate formationDate;

    @Column(name = "PASSPORT_NUMBER")
    private String passportNumber;

    @Column(name = "START_DATE")
    private LocalDate startDate;

    @Column(name = "END_DATE")
    private LocalDate endDate;

    @Column(name = "PASSPORT_STATUS")
    private Integer passportStatus;

    @Column(name = "ABS_NUMBS_SUCCESS_REQUESTS")
    private Double absNumbsSuccessRequests;

    @Column(name = "REL_NUMBS_SUCCESS_REQUESTS")
    private Double relNumbsSuccessRequests;

    @OneToMany(mappedBy = "gasQualityPassport")
    @OnDelete(DeletePolicy.CASCADE)
    private List<GasQualityProtocol> protocols;

    @OneToMany(mappedBy = "gasQualityPassport")
    private List<GasQualityPassportAttribute> dynamicAttribute;

    @OneToMany(mappedBy = "passport")
    @OnDelete(DeletePolicy.CASCADE)
    private List<GasPassportGrsLink> grsLinks;

    public List<GasQualityPassportAttribute> getDynamicAttribute() {
        return dynamicAttribute;
    }

    public void setDynamicAttribute(List<GasQualityPassportAttribute> dynamicAttribute) {
        this.dynamicAttribute = dynamicAttribute;
    }

    public List<GasPassportGrsLink> getGrsLinks() {
        return grsLinks;
    }

    public void setGrsLinks(List<GasPassportGrsLink> grsLinks) {
        this.grsLinks = grsLinks;
    }

    public void setPassportStatus(GasQualityPassportStatus passportStatus) {
        this.passportStatus = passportStatus == null ? null : passportStatus.getId();
    }
    public GasQualityPassportStatus getPassportStatus() {
        return passportStatus == null ? null : GasQualityPassportStatus.fromId(passportStatus);
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setFormationDate(LocalDate formationDate) {
        this.formationDate = formationDate;
    }

    public LocalDate getFormationDate() {
        return formationDate;
    }

    public void setSentBy(String sentBy) {
        this.sentBy = sentBy;
    }

    public String getSentBy() {
        return sentBy;
    }

    public void setSentTs(LocalDateTime sentTs) {
        this.sentTs = sentTs;
    }

    public LocalDateTime getSentTs() {
        return sentTs;
    }

    public List<GasQualityProtocol> getProtocols() {
        return protocols;
    }

    public void setProtocols(List<GasQualityProtocol> protocols) {
        this.protocols = protocols;
    }

    public Double getRelNumbsSuccessRequests() {
        return relNumbsSuccessRequests;
    }

    public void setRelNumbsSuccessRequests(Double relNumbsSuccessRequests) {
        this.relNumbsSuccessRequests = relNumbsSuccessRequests;
    }

    public Double getAbsNumbsSuccessRequests() {
        return absNumbsSuccessRequests;
    }

    public void setAbsNumbsSuccessRequests(Double absNumbsSuccessRequests) {
        this.absNumbsSuccessRequests = absNumbsSuccessRequests;
    }
}
