package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.Lookup;
import com.haulmont.cuba.core.entity.annotation.LookupType;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.epu.util.BitMaskUtils;

import javax.persistence.*;

/**
 * В случае изменения сущности, модифицировать отчет driverExport
 */
@Table(name = "MP_DEVICE_PARAM", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_PARAM_CODE", columnNames = {"DEVICE_PARAM_GROUP_ID", "CODE"})
})
@Entity(name = "mp_DeviceParam")
@NamePattern("%s(%s)|name,code")
@Listeners("pros_MpConfListener")
public class DeviceParam extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PARAM_TYPE_ID")
    private DeviceParamType deviceParamType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "METRIC_PREFIX_ID")
    private ParamUnitMetricPrefix metricPrefix;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_UNIT_ID")
    @Lookup(type = LookupType.DROPDOWN, actions = {})
    private ParamUnit paramUnit;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PARAM_GROUP_ID")
    @OnDeleteInverse(value = DeletePolicy.CASCADE)
    private DeviceParamGroup deviceParamGroup;

    @Column(name = "PROTO_ADDRESS")
    private String protoAddress;

    @Column(name = "FLAG")
    private Integer flag;

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public boolean isRead() {
        return BitMaskUtils.isRead(flag);
    }

    public boolean isWrite() {
        return BitMaskUtils.isWrite(flag);
    }

    public ParamUnitMetricPrefix getMetricPrefix() {
        return metricPrefix;
    }

    public void setMetricPrefix(ParamUnitMetricPrefix metricPrefix) {
        this.metricPrefix = metricPrefix;
    }

    public ParamUnit getParamUnit() {
        return paramUnit;
    }

    public void setParamUnit(ParamUnit paramUnit) {
        this.paramUnit = paramUnit;
    }

    public DeviceParamGroup getDeviceParamGroup() {
        return deviceParamGroup;
    }

    public void setDeviceParamGroup(DeviceParamGroup deviceParamGroup) {
        this.deviceParamGroup = deviceParamGroup;
    }

    public DeviceParamType getDeviceParamType() {
        return deviceParamType;
    }

    public void setDeviceParamType(DeviceParamType deviceParamType) {
        this.deviceParamType = deviceParamType;
    }

    public String getProtoAddress() {
        return protoAddress;
    }

    public void setProtoAddress(String protoAddress) {
        this.protoAddress = protoAddress;
    }

    public String obtainParamType() {
        return getDeviceParamType() != null ? getDeviceParamType().getCode() : null;
    }
}