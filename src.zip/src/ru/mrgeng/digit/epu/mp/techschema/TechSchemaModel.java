package ru.mrgeng.digit.epu.mp.techschema;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;
import ru.mrgeng.digit.epu.mp.techschema.schemafile.TechSchema;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "MP_TECH_SCHEMA_MODEL")
@Entity(name = "mp_TechSchemaModel")
@NamePattern("%s|objId")
public class TechSchemaModel extends StandardEntity {
    private static final long serialVersionUID = 5174438467530434374L;

    @Column(name = "NAME")
    private String name;

    @NotNull
    @Column(name = "OBJ_ID", nullable = false, length = 100)
    private String objId;

    @Column(name = "JSON_DATA", length = 50000)
    private String jsonData;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TECH_SCHEMA_ID")
    private TechSchema schema;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public TechSchema getSchema() {
        return schema;
    }

    public void setSchema(TechSchema schema) {
        this.schema = schema;
    }

    public String getJsonData() {
        return jsonData;
    }

    public void setJsonData(String jsonData) {
        this.jsonData = jsonData;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}