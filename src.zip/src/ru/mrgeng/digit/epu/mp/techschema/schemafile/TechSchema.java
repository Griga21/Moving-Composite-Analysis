package ru.mrgeng.digit.epu.mp.techschema.schemafile;



import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;

import javax.persistence.*;
import java.util.UUID;

@Table(name = "MP_TECH_SCHEMA")
@Entity(name = "mp_TechSchema")
@NamePattern("%s|name")
public class TechSchema extends StandardEntity {
    private static final long serialVersionUID = 4808409490419111341L;

    @Column(name = "NAME")
    private String name;

    @Column(name = "SVG_ID")
    private String svgId;

    @Column(name = "FILE_ID")
    private UUID fileDescId;

    public UUID getFileDescId() {
        return fileDescId;
    }

    public void setFileDescId(UUID fileDescId) {
        this.fileDescId = fileDescId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSvgId() {
        return svgId;
    }

    public void setSvgId(String svgId) {
        this.svgId = svgId;
    }
}