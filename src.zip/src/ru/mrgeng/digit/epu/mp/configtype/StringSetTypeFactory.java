package ru.mrgeng.digit.epu.mp.configtype;

import com.haulmont.cuba.core.config.type.TypeFactory;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Преобразует строку из свойств приложения в иммутабельный Set (по разделителю "|").
 * Автоматически убирает null-значения и дубликаты.
 * Задается в {@link com.haulmont.cuba.core.config.type.Factory}
 */
public class StringSetTypeFactory extends TypeFactory {
    @Override
    public Set<String> build(String string) {
        return StringUtils.isBlank(string)
            ? Collections.emptySet()
            : Arrays.stream(string.split("\\|"))
            .map(String::trim)
            .filter(StringUtils::isNotEmpty).collect(Collectors.toUnmodifiableSet());
    }
}
