package ru.mrgeng.digit.epu.mp.configtype;

import com.haulmont.cuba.core.config.type.TypeStringify;

import java.util.Set;

public class StringSetStringify extends TypeStringify {
    @Override
    public String stringify(Object value) {
        return String.join("|", ((Set<String>) value));
    }
}
