package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Lookup;
import com.haulmont.cuba.core.entity.annotation.LookupType;

import javax.persistence.*;
/**
 * Описание модели параметров числовых значений
*/
@Table(name = "MP_PARAM_UNIT", uniqueConstraints = {
        @UniqueConstraint(name = "UC_PARAM_UNIT_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_ParamUnit")
@NamePattern("%s|abbr")
public class ParamUnit extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "ABBR", length = 16)
    private String abbr;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_UNIT_TYPE_ID")
    @Lookup(type = LookupType.DROPDOWN, actions = {})
    private ParamUnitType paramUnitType;

    public ParamUnitType getParamUnitType() {
        return paramUnitType;
    }

    public void setParamUnitType(ParamUnitType paramUnitType) {
        this.paramUnitType = paramUnitType;
    }

    public String getAbbr() {
        return abbr;
    }

    public void setAbbr(String abbr) {
        this.abbr = abbr;
    }
}