package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * Устройство и его линия, для выборочного поиска параметров (vs, p, t и т.д.)
 * Сущность предназначалась для проекта балансовых зон, и появилось лучшее решение, в виде MeasPoint.
 */
@Deprecated
@Table(name = "MP_DEVICE_LINE")
@Entity(name = "mp_DeviceLine")
@NamePattern("%s %s|device,line")
public class DeviceLine extends Obj {
    private static final long serialVersionUID = -1416458637847491425L;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    @Column(name = "LINE")
    protected Integer line;

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public LineEnum getLine() {
        return line == null ? null : LineEnum.fromId(line);
    }

    public void setLine(LineEnum line) {
        this.line = line == null ? null : line.getId();
    }

    public String toObjId() {
        return line == null ? device.getCode() : device.getCode() + '.' + LineEnum.getCode(line);
    }
}