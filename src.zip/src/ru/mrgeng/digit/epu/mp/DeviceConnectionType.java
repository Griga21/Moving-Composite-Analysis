package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

public enum DeviceConnectionType implements EnumClass<String> {

    SCHEDULE("schedule"),
    ALWAYS("always");

    private String id;

    DeviceConnectionType(String id) {
        this.id = id;
    }

    @Override
    public String getId() {
        return id;
    }

    public static DeviceConnectionType fromId(String id) {
        for (DeviceConnectionType deviceConnectionType : DeviceConnectionType.values())
            if (deviceConnectionType.getId().equals(id))
                return deviceConnectionType;
        return null;
    }
}
