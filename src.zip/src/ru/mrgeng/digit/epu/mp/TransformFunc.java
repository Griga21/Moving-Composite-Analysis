package ru.mrgeng.digit.epu.mp;

import javax.persistence.*;

@Table(name = "MP_TRANSFORM_FUNC", uniqueConstraints = {
        @UniqueConstraint(name = "UC_TRANSFORM_FUNC_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_TransformFunc")
public class TransformFunc extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IN_PARAM_TYPE_ID")
    private ParamType inParamType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "OUT_PARAM_TYPE_ID")
    private ParamType outParamType;

    public ParamType getInParamType() {
        return inParamType;
    }

    public void setInParamType(ParamType inParamType) {
        this.inParamType = inParamType;
    }

    public ParamType getOutParamType() {
        return outParamType;
    }

    public void setOutParamType(ParamType outParamType) {
        this.outParamType = outParamType;
    }
}