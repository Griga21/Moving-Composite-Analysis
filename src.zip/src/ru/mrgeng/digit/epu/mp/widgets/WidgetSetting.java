package ru.mrgeng.digit.epu.mp.widgets;

import ru.mrgeng.digit.dgcore.entity.Obj;

import javax.persistence.*;
import java.util.List;

@Table(name = "MP_WIDGET_SETTING", uniqueConstraints = {
        @UniqueConstraint(name = "DEVICE_SCREEN_ID", columnNames = {"DEVICE_ID", "SCREEN_ID"})})
@Entity(name = "mp_WidgetSetting")
public class WidgetSetting extends Obj {
    private static final long serialVersionUID = 1076448916932511519L;

    @Column(name = "DEVICE_ID")
    private Long deviceId;

    @Column(name = "SCREEN_ID")
    private String screenId;

    @Column(name = "TEMPLATE_NAME", unique = true)
    private String templateName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEMPLATE_ID")
    private WidgetSetting template;

    @Column(name = "USE_TEMPLATE")
    private Boolean useTemplate = false;

    @OneToMany(mappedBy = "widgetSetting")
    private List<Widget> widgets;

    @OneToMany(mappedBy = "widgetSetting")
    private List<WidgetText> texts;

    public Long getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Long deviceId) {
        this.deviceId = deviceId;
    }

    public List<Widget> getWidgets() {
        return widgets;
    }

    public void setWidgets(List<Widget> widgets) {
        this.widgets = widgets;
    }

    public List<WidgetText> getTexts() {
        return texts;
    }

    public void setTexts(List<WidgetText> texts) {
        this.texts = texts;
    }

    public String getScreenId() {
        return screenId;
    }

    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public WidgetSetting getTemplate() {
        return template;
    }

    public void setTemplate(WidgetSetting template) {
        this.template = template;
    }

    public Boolean getUseTemplate() {
        return useTemplate;
    }

    public void setUseTemplate(Boolean useTemplate) {
        this.useTemplate = useTemplate;
    }
}