package ru.mrgeng.digit.epu.mp.widgets;

import ru.mrgeng.digit.dgcore.entity.Obj;

import javax.persistence.*;

@Table(name = "MP_WIDGET_TEXT")
@Entity(name = "mp_WidgetText")
public class WidgetText extends Obj {
    private static final long serialVersionUID = 4690864167707375275L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "WIDGET_SETTING_ID")
    private WidgetSetting widgetSetting;

    @Column(name = "X")
    private Integer x;

    @Column(name = "Y")
    private Integer y;

    @Column(name = "VALUE")
    private String value;

    public WidgetSetting getWidgetSetting() {
        return widgetSetting;
    }

    public void setWidgetSetting(WidgetSetting widgetSetting) {
        this.widgetSetting = widgetSetting;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}