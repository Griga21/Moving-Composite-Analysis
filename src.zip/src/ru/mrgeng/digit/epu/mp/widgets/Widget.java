package ru.mrgeng.digit.epu.mp.widgets;

import ru.mrgeng.digit.dgcore.entity.Obj;

import javax.persistence.*;

@Table(name = "MP_WIDGET")
@Entity(name = "mp_Widget")
public class Widget extends Obj {
    private static final long serialVersionUID = -7973683304279495158L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "WIDGET_SETTING_ID")
    private WidgetSetting widgetSetting;

    @Column(name = "X")
    private Integer x;

    @Column(name = "Y")
    private Integer y;

    @Column(name = "PARAM_ID")
    private Long paramId;

    @Column(name = "LINE_CODE")
    private String lineCode;

    @Column(name = "WIDTH")
    private Integer width;

    @Column(name = "HEIGHT")
    private Integer height;

    public WidgetSetting getWidgetSetting() {
        return widgetSetting;
    }

    public void setWidgetSetting(WidgetSetting widgetSetting) {
        this.widgetSetting = widgetSetting;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Long getParamId() {
        return paramId;
    }

    public void setParamId(Long paramId) {
        this.paramId = paramId;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }
}