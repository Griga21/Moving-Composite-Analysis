package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;
import ru.mrgeng.digit.epu.param.SeriousLevel;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Map;

/**
 * Признак дискретного сигнала, задающий уровень тревоги и значение сигнала
 */
public enum DiscreteAlarm implements EnumClass<Integer>, Serializable {

    ALARM_ON_0(0), // Тревога по 0
    ALARM_ON_1(1), // Тревога по 1
    WARN_ON_0(2),  // Предупреждение по 0
    WARN_ON_1(3),  // Предупреждение по 1
    ALARM_ON_1_AND_3(4); // Тревога по 1 и 3

    private Integer id;

    private Map<Double, SeriousLevel> valueLevelMap;

    static {
        ALARM_ON_0.valueLevelMap = Map.of(0.0, SeriousLevel.ALARM);
        ALARM_ON_1.valueLevelMap = Map.of(1.0, SeriousLevel.ALARM);
        ALARM_ON_1_AND_3.valueLevelMap = Map.of(
            1.0, SeriousLevel.ALARM,
            3.0, SeriousLevel.ALARM
        );
        WARN_ON_0.valueLevelMap = Map.of(0.0, SeriousLevel.WARN);
        WARN_ON_1.valueLevelMap = Map.of(1.0, SeriousLevel.WARN);
    }

    DiscreteAlarm(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
    
    public SeriousLevel check(Double value) {
        if (value == null)
            return null;
        return valueLevelMap.getOrDefault(value, null);
    }

    @Nullable
    public static DiscreteAlarm fromId(Integer id) {
        for (DiscreteAlarm at : DiscreteAlarm.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}