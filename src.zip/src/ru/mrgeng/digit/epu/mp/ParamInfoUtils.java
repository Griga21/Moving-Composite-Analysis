package ru.mrgeng.digit.epu.mp;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import org.slf4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import ru.mrgeng.digit.dgcore.event.ReloadConfigEvent;
import ru.mrgeng.digit.epu.param.DataFormat;
import ru.mrgeng.digit.epu.param.Param;
import ru.mrgeng.digit.epu.service.*;

import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

@Component(ParamInfoUtils.NAME)
public class ParamInfoUtils implements ApplicationListener<GlobalApplicationEvent> {

    public static final String NAME = "ParamInfoUtils";

    @Inject
    private Logger log;
    @Inject
    private ParamDescrService paramDescrService;
    @Inject
    private DeviceParamService deviceParamService;
    @Inject
    private MpService mpService;

    private Map<String, String> unitMap;
    private Map<String, String> prefixMap;
    private Map<String, String> abbrMap;
    private Map<Long, ru.mrgeng.digit.epu.param.Param> parametersMap;
    private Map<String, Map<String, String>> aMap;

    Map<String, Map<Long, Map<String, Map<Long, DeviceParamService.ParamsThresholdInfo>>>> thresByService = new ConcurrentHashMap<>();
    Map<String, DeviceParamService.ParamsInfo<ru.mrgeng.digit.epu.param.Param>> calcParams = new ConcurrentHashMap<>();
    Map<Long, Set<Long>> serviceDeviceType = new ConcurrentHashMap<>();
    Map<String, Map<String, Map<String, Map<String, Date>>>> ignoresByService = new ConcurrentHashMap<>();

    public Map<Long, Set<Long>> getServiceDeviceTypes(List<Long> serviceIds) {
        Map<Long, Set<Long>> res = new HashMap<>();
        List<Long> request = null;
        for (Long serviceId : serviceIds) {
            Set<Long> longs = serviceDeviceType.get(serviceId);
            if (longs != null)
                res.putIfAbsent(serviceId, longs);
            else {
                if (request == null)
                    request = new ArrayList<>();
                request.add(serviceId);
            }
        }
        if (request == null)
            return res;
        Map<Long, Set<Long>> serviceDeviceTypes = deviceParamService.getServiceDeviceTypes(request);
        serviceDeviceType.putAll(serviceDeviceTypes);
        res.putAll(serviceDeviceTypes);
        return res;
    }

    public DeviceParamService.ParamsInfo<ru.mrgeng.digit.epu.param.Param> getCalcParamsInfo(String deviceType) {
        DeviceParamService.ParamsInfo<ru.mrgeng.digit.epu.param.Param> res = calcParams.get(deviceType);
        if (res != null)
            return res;
        return calcParams.computeIfAbsent(deviceType, it -> deviceParamService.getCalcParamsByDevType(deviceType));
    }

    public Map<String, Set<String>> getCalcParamsInfo(List<String> deviceTypeCodes) {
        Map<String, Set<String>> res = new HashMap<>();
        Set<String> absentCodes = deviceTypeCodes.stream().filter(code -> {
            if (calcParams.containsKey(code)) {
                if (calcParams.get(code) != null) {
                    res.put(code, calcParams.get(code).groups.keySet());
                }
                return false;
            }
            return true;
        }).collect(Collectors.toSet());
        deviceParamService.getCalcParamsByDevTypes(absentCodes).forEach((key, value) -> {
            calcParams.put(key, value);
            res.put(key, value.groups.keySet());
        });
        return res;
    }

    public Map<Long, Map<String, Map<Long, DeviceParamService.ParamsThresholdInfo>>> getThresholds(String service) {
        Map<Long, Map<String, Map<Long, DeviceParamService.ParamsThresholdInfo>>> res = thresByService.get(service);
        if (res != null)
            return res;
        return thresByService.computeIfAbsent(service, it -> deviceParamService.getCalcParamsThresholds(service));
    }

    public Map<String, Map<String, Map<String, Date>>> getParamsIgnoresByServiceCode(String service) {
        Map<String, Map<String, Map<String, Date>>> res = ignoresByService.get(service);
        if (res != null)
            return res;
        return ignoresByService.computeIfAbsent(service, it -> deviceParamService.getParamsIgnoresByCodes(service));
    }

    public Map<String, Map<String, Date>> getParamsIgnoresByDevice(Device device) {
        Map<String, Map<String, Map<String, Date>>> paramsIgnoresByServiceCode = getParamsIgnoresByServiceCode(device.getDeviceService().getCode());
        return paramsIgnoresByServiceCode.get(device.getCode());
    }

    public String getObjInfo(CodeNameObj obj) {
        if (obj == null)
            return "Не указана";
        return obj.name == null ? obj.code : obj.name;
    }

    public String getGroupInfo(MpService.GroupDef group) {
        if (group == null) {
            return "Не указана";
        }
        return group.code + " - " + group.name;
    }

    public String getParamInfo(ru.mrgeng.digit.epu.param.Param param, boolean withCode) {
        if (param == null) {
            return "Не указан";
        }
        if (unitMap == null)
            unitMap = paramDescrService.getUnitAbbrMap();
        if (prefixMap == null)
            prefixMap = paramDescrService.getPrefixAbbrMap();
        String name = param.designation != null ? param.designation : (param.name == null ? param.code : param.name);
        BiFunction<String, ru.mrgeng.digit.epu.param.Param, String> withCodeFunc = withCode ?
                (desc, deviceParam) -> desc + " (" + deviceParam.code + ")" :
                (desc, deviceParam) -> desc;
        String unit = unitMap.get(param.unit);
        String prefix = prefixMap.get(param.metricPrefix);
        if (unit != null) {
            if (prefix != null) {
                return withCodeFunc.apply(name + " - " + prefix + " " + unit, param);
            }
            return withCodeFunc.apply(name + " - " + unit, param);
        }
        return withCodeFunc.apply(name, param);
    }

    public String getParamInfoWithNewUnit(ru.mrgeng.digit.epu.param.Param param, String prefix, String unit, boolean withCode) {
        if (param == null) {
            return "Не указан";
        }
        if (unitMap == null)
            unitMap = paramDescrService.getUnitAbbrMap();
        if (prefixMap == null)
            prefixMap = paramDescrService.getPrefixAbbrMap();
        String name = param.getDisplayName();
        BiFunction<String, ru.mrgeng.digit.epu.param.Param, String> withCodeFunc = withCode ?
                (desc, deviceParam) -> desc + " (" + deviceParam.code + ")" :
                (desc, deviceParam) -> desc;
        if (unit != null) {
            if (prefix != null) {
                return withCodeFunc.apply(name + " - " + prefixMap.get(prefix) + " " + unitMap.get(unit), param);
            }
            return withCodeFunc.apply(name + " - " + unitMap.get(unit), param);
        }
        return withCodeFunc.apply(name, param);
    }

    public String getParamInfo(ru.mrgeng.digit.epu.param.Param param) {
        return getParamInfo(param, false);
    }

    public String getParamInfoForSchema(ru.mrgeng.digit.epu.param.Param param) {
        if (param == null)
            return "Не указан";
        if (unitMap == null)
            unitMap = paramDescrService.getUnitAbbrMap();
        if (prefixMap == null)
            prefixMap = paramDescrService.getPrefixAbbrMap();
        String unit = null;
        String prefix = null;

        if (unitMap.get(param.unit) != null)
            unit = unitMap.get(param.unit);
        if (prefixMap.get(param.metricPrefix) != null)
            prefix = prefixMap.get(param.metricPrefix);

        if (unitMap.get(param.unit) != null)
            if (prefixMap.get(param.metricPrefix) != null)
                return prefix + unit;

        return unit;
    }

    public Map<Long, ru.mrgeng.digit.epu.param.Param> getParamMap() {
        if (parametersMap != null)
            return parametersMap;
        parametersMap = deviceParamService.loadCalcParamMap();
        return parametersMap;
    }

    public Map<String, String> getParamAbbrMap() {
        if (abbrMap != null)
            return abbrMap;
        abbrMap = deviceParamService.loadParamAbbrMap();
        return abbrMap;
    }

    public Map<String, Map<String, String>> getAbbrMap() {
        if (aMap != null) {
            return aMap;
        }
        aMap = deviceParamService.loadAbbrMap();
        return aMap;
    }

    public Map<CodeNameObj, Map<String, Param>> getCalcParamsByGroup(Device device) {
        return getCalcParamsByGroup(device.getDeviceService().getCode(), device.getCode());
    }

    public Map<CodeNameObj, Map<String, Param>> getCalcParamsByGroup(String deviceServiceCode, String deviceCode) {
        DeviceParamService.ParamsInfo<Param> paramInfo = mpService.getDeviceCalcParams(deviceServiceCode, deviceCode);
        Map<CodeNameObj, Map<String, Param>> result = new HashMap<>();
        if (paramInfo == null || paramInfo.strGroupParams == null || paramInfo.groups == null) {
            log.warn("Не найдена полная информация о вычисляемых параметрах для сервиса '{}' и устройства '{}'",
                    deviceServiceCode, deviceCode);
            return result;
        }
        for (Map.Entry<String, Map<String, Param>> entry : paramInfo.strGroupParams.entrySet()) {
            result.put(paramInfo.groups.get(entry.getKey()), entry.getValue());
        }
        return result;
    }

    //todo очистить мапы
    @Override
    public void onApplicationEvent(GlobalApplicationEvent inEvent) {
        if (inEvent instanceof DeviceConfChangedEvent) {
            if (DeviceMpIgnore.class.getSimpleName().equals(((DeviceConfChangedEvent) inEvent).getDataName())) {
                ignoresByService.clear();
                log.info("Изменение в игнорировании, данные по игнорированию будут перегружены");
            }
        }
        if (inEvent instanceof ServiceDataChangedEvent) {
            ServiceDataChangedEvent event = (ServiceDataChangedEvent) inEvent;
            if (deviceParamService.THRESHOLDS_CHANGES.isOwnChange(event)) {
                log.info("Изменение в порогах, данные по порогам будут перегружены");
                thresByService.clear();
            } else if (deviceParamService.CALC_PARAMS_CHANGES.isOwnChange(event)) {
                log.info("Изменение в выч. параметрах, будут перегружены");
                calcParams.clear();
                parametersMap = null;
                abbrMap = null;
                aMap = null;
            }
        } else if (inEvent instanceof ReloadConfigEvent) {
            serviceDeviceType.clear();
            thresByService.clear();
            calcParams.clear();
            parametersMap = null;
            unitMap = null;
            prefixMap = null;
            abbrMap = null;
            aMap = null;
            log.info("Перегружены все данные");
        }
    }

    public List<DeviceType> getDeviceTypes(List<String> devTypes) {
        return deviceParamService.findByCodes("mp_DeviceType", devTypes);
    }

    public List<CodeNameObj> getMeasPoints(String devType) {
        return deviceParamService.getMeasPoints(devType);
    }

    public static String bringParamValue(Param param, Double value) {
        if (value == null) return null;
        String val = value.toString();
        if (param.format == null) return val;
        DataFormat format = param.format;
        val = format.toStr(value);
        return val;
    }

    public static boolean isParamIgnored(Map<String, Map<String, Date>> paramsIgnoresByDevice, Param paramInfo) {
        if (paramsIgnoresByDevice != null) {
            Map<String, Date> stringDateMap = paramsIgnoresByDevice.get(paramInfo.groupCode);
            if (stringDateMap != null) {
                Date date = stringDateMap.get(paramInfo.code);
                return date != null && date.after(new Date());
            }
        }
        return false;
    }
}
