package ru.mrgeng.digit.epu.mp;

import com.haulmont.addon.maps.gis.Geometry;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.Categorized;
import com.haulmont.cuba.core.entity.Category;
import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.dgcore.entity.Department;
import ru.mrgeng.digit.epu.pros.bz.Grs;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;
import java.util.List;
import java.util.UUID;

/**
 * Устройство для получения параметров
 */
@Table(name = "MP_DEVICE", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_SERVICE_CODE", columnNames = {"DEVICE_SERVICE_ID", "CODE"})
})
@Entity(name = "mp_Device")
@NamePattern("%s|name")
@PublishEntityChangedEvents
@Listeners({"pros_MpConfListener", "dgepu_DeviceChangedListener"})
public class Device extends MpObj implements Categorized, Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "SERIAL_NUM", length = 256)
    protected String serialNum;

    @Column(name = "TIME_ARRIVAL_DATA")
    private Integer timeArrivalData;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TECH_SUPPORT_ID")
    private TechSupport techSupport;

    @JoinColumn(name = "CONNECTED_TO")
    @ManyToOne(fetch = FetchType.LAZY)
    private Device connectedTo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SOURCE_ID")
    private Source source;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_STATUS_ID")
    private DeviceStatus deviceStatus;

    // @NotNull
    @Column(name = "DEVICE_ADDRESS")//, nullable = false)
    private String deviceAddress; //1.1.1.13 - Фактическое местоположение

    @Column(name = "DEVICE_OWNER_PERSON")
    private String deviceOwnerPerson; //1.1.1.8 - Данные собственника оборудования - Информация о собственнике оборудования

    @Column(name = "DEVICE_CARING_CONTACT")
    private String deviceCaringContact; //1.1.1.14 - Контактные данные ответственного за газовое хозяйство

    @Column(name = "INTERROGATION")
    private Boolean interrogation; //1.1.1.15 - Опрос - Признак включения опроса true-включен

    @Column(name = "COMM")
    private String comm; //Примечания - Поле для примечания

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MODEL_ID")
    protected DeviceModel deviceModel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PLACE_ID")
    private Place place;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_SERVICE_ID")
    protected DeviceService deviceService;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_CHANNEL_ID")
    private DeviceChannel deviceChannel;

    @Column(name = "CHANNEL_ADDRESS")
    private String channelAddress;

    @Column(name = "CHANNEL_SETTINGS_JSON", length = 2048)
    private String channelSettingsJson;

    @Column(name = "LOGIN")
    private String login;

    @Column(name = "PASSWORD")
    private String password;

    @Min(0)
    @Max(23)
    @Column(name = "COMM_HOUR")
    private Integer commHour;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PROTO_MODEL_ID")
    private DeviceProtoModel deviceProtoModel;

    @Column(name = "PROTO_ADDRESS")
    private String protoAddress;

    @Column(name = "STATUS_COMM")
    private String statusComm;

    @Column(name = "LOCATION")
    @Geometry
    @MetaProperty(datatype = "coord")
    @Convert(converter = MpPointWKTConverter.class)
    private Point location;

    @SystemLevel
    @Column(name = "DEPARTMENT_ID")
    private Long departmentId;

    @MetaProperty(related = "departmentId")
    @Transient
    private Department department;

    @Column(name = "LINES_JSON", length = 512)
    private String linesJson;

    @SystemLevel
    @Column(name = "CATEGORY_ID")
    private UUID categoryId;

    @Transient
    @MetaProperty(related = "categoryId")
    private Category category;

    @ManyToMany
    @JoinTable(name = "MP_DEVICE_GROUP_MP_DEVICE_LINK",
            joinColumns = @JoinColumn(name = "DEVICE_ID"),
            inverseJoinColumns = @JoinColumn(name = "DEVICE_GROUP_ID"))
    private List<DeviceGroup> groups;

    @Column(name = "ALTER_CODE")
    private String alterCode;

    @Column(name = "DEVICE_CONNECTION_TYPE")
    private String deviceConnectionType;

    @Column(name = "CRON")
    private String cron;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STANDARD_SIZE_ID")
    private StandardSize standardSize;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GRS_ID")
    private Grs grs;

    public Integer getTimeArrivalData() {
        return timeArrivalData;
    }

    public void setTimeArrivalData(Integer timeArrivalData) {
        this.timeArrivalData = timeArrivalData;
    }

    public Place getPlace() {
        return place;
    }

    public void setPlace(Place place) {
        this.place = place;
    }

    public Grs getGrs() {
        return grs;
    }

    public void setGrs(Grs grs) {
        this.grs = grs;
    }

    public String getLinesJson() {
        return linesJson;
    }

    public void setLinesJson(String linesJson) {
        this.linesJson = linesJson;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public List<DeviceGroup> getGroups() {
        return groups;
    }

    public void setGroups(List<DeviceGroup> groups) {
        this.groups = groups;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public UUID getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(UUID categoryId) {
        this.categoryId = categoryId;
    }

    public TechSupport getTechSupport() {
        return techSupport;
    }

    public void setTechSupport(TechSupport techSupport) {
        this.techSupport = techSupport;
    }

    public Device getConnectedTo() {
        return connectedTo;
    }

    public void setConnectedTo(Device connectedTo) {
        this.connectedTo = connectedTo;
    }

    public String getStatusComm() {
        return statusComm;
    }

    public void setStatusComm(String statusComm) {
        this.statusComm = statusComm;
    }

    public Source getSource() {
        return source;
    }

    public void setSource(Source source) {
        this.source = source;
    }

    @Deprecated
    public DeviceType getDeviceType() {
        return getType();
    }

    public DeviceStatus getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(DeviceStatus deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public String getDeviceAddress() {
        return deviceAddress;
    }

    public void setDeviceAddress(String deviceAddress) {
        this.deviceAddress = deviceAddress;
    }

    public String getDeviceOwnerPerson() {
        return deviceOwnerPerson;
    }

    public void setDeviceOwnerPerson(String deviceOwnerPerson) {
        this.deviceOwnerPerson = deviceOwnerPerson;
    }

    public String getDeviceCaringContact() {
        return deviceCaringContact;
    }

    public void setDeviceCaringContact(String deviceCaringContact) {
        this.deviceCaringContact = deviceCaringContact;
    }

    public Boolean getInterrogation() {
        return interrogation;
    }

    public void setInterrogation(Boolean interrogation) {
        this.interrogation = interrogation;
    }

    public String getComm() {
        return comm;
    }

    public void setComm(String comm) {
        this.comm = comm;
    }

    public DeviceChannel getDeviceChannel() {
        return deviceChannel;
    }

    public void setDeviceChannel(DeviceChannel deviceChannel) {
        this.deviceChannel = deviceChannel;
    }

    public String getChannelSettingsJson() {
        return channelSettingsJson;
    }

    public void setChannelSettingsJson(String channelSettingsJson) {
        this.channelSettingsJson = channelSettingsJson;
    }

    public String getChannelAddress() {
        return channelAddress;
    }

    public void setChannelAddress(String channelAddress) {
        this.channelAddress = channelAddress;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    public DeviceService getDeviceService() {
        return deviceService;
    }

    public void setDeviceService(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    public DeviceModel getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(DeviceModel deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getCommHour() {
        return commHour;
    }

    public void setCommHour(Integer commHour) {
        this.commHour = commHour;
    }

    public String getProtoAddress() {
        return protoAddress;
    }

    public void setProtoAddress(String protoAddress) {
        this.protoAddress = protoAddress;
    }

    public DeviceProtoModel getDeviceProtoModel() {
        return deviceProtoModel;
    }

    public void setDeviceProtoModel(DeviceProtoModel deviceProtoModel) {
        this.deviceProtoModel = deviceProtoModel;
    }

    @Override
    public String toString() {
        return "Device-" + id;
    }

    public DeviceType getType() {
        return deviceModel != null ? deviceModel.getDeviceType() : null;
    }

    public String getAlterCode() {
        return alterCode;
    }

    public void setAlterCode(String alterCode) {
        this.alterCode = alterCode;
    }

    public DeviceConnectionType getDeviceConnectionType() {
        return deviceConnectionType == null ? null : DeviceConnectionType.fromId(deviceConnectionType);
    }

    public void setDeviceConnectionType(DeviceConnectionType deviceConnectionType) {
        this.deviceConnectionType = deviceConnectionType == null ? null : deviceConnectionType.getId();
    }

    public String getCron() {
        return cron;
    }

    public void setCron(String cron) {
        this.cron = cron;
    }

    public String getServiceCode() {
        return deviceService != null ? deviceService.getCode() : null;
    }


    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public StandardSize getStandardSize() {
        return standardSize;
    }

    public void setStandardSize(StandardSize standardSize) {
        this.standardSize = standardSize;
    }
}