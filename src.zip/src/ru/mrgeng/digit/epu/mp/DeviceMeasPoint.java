package ru.mrgeng.digit.epu.mp;

import javax.persistence.*;

/**
 * Точка/Место группировки измерений, получаемых устройством
 */
@Table(name = "MP_DEVICE_MEAS_POINT", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_MEAS_POINT_CODE", columnNames = {"DEVICE_MODEL_ID", "CODE"})
})
@Entity(name = "mp_DeviceMeasPoint")
public class DeviceMeasPoint extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MODEL_ID")
    private DeviceModel deviceModel;

    public DeviceModel getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(DeviceModel deviceModel) {
        this.deviceModel = deviceModel;
    }
}