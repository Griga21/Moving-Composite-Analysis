package ru.mrgeng.digit.epu.mp;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(name = "MP_PARAM_TYPE", uniqueConstraints = {
        @UniqueConstraint(name = "UC_PARAM_TYPE_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_ParamType")
public class ParamType extends MpObj {
    private static final long serialVersionUID = 1L;

}