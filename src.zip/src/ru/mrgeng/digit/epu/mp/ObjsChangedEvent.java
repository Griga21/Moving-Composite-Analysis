package ru.mrgeng.digit.epu.mp;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;

/**
 * Событие об изменении объектов
 */
public class ObjsChangedEvent extends GlobalApplicationEvent {

    String dataName;

    public ObjsChangedEvent(Object source, String dataName) {
        super(source);
        this.dataName = dataName;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" +
                "dataName=" + dataName +
                ", changed=" + getTimestamp() +
                '}';
    }

    public String getDataName() {
        return dataName;
    }
}
