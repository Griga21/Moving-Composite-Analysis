package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Lookup;
import com.haulmont.cuba.core.entity.annotation.LookupType;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.epu.transform.Transform;

import javax.persistence.*;

@MappedSuperclass
@NamePattern("%s(%s) - %s|deviceParam,param,deviceMeasPoint")
public class DeviceParamTransform extends Obj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PARAM_ID")
    @OnDeleteInverse(DeletePolicy.CASCADE)
    private DeviceParam deviceParam;

    @Lookup(type = LookupType.SCREEN, actions = "lookup")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONNECTED_DEVICE_ID")
    private Device connectedDevice;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MEAS_POINT_ID")
    private DeviceMeasPoint deviceMeasPoint;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_ID")
    @OnDeleteInverse(DeletePolicy.CASCADE)
    private Param param;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TRANSFORM_FUNC_ID")
    private TransformFunc transformFunc;

    @Column(name = "TRANSFORM_PARAMS", length = 8192)
    private String transformParams;

    @Column(name = "ADD_TRANSFORM")
    private String addTransform;

    @Column(name = "ADD_TRANSFORM_PARAMS", length = 8192)
    private String addTransformParams;

    public String getAddTransformParams() {
        return addTransformParams;
    }

    public void setAddTransformParams(String addTransformParams) {
        this.addTransformParams = addTransformParams;
    }

    public Transform getAddTransform() {
        return addTransform == null ? null : Transform.fromId(addTransform);
    }

    public void setAddTransform(Transform addTransform) {
        this.addTransform = addTransform == null ? null : addTransform.getId();
    }

    public Device getConnectedDevice() {
        return connectedDevice;
    }

    public void setConnectedDevice(Device connectedDevice) {
        this.connectedDevice = connectedDevice;
    }

    public String getTransformParams() {
        return transformParams;
    }

    public void setTransformParams(String transformParams) {
        this.transformParams = transformParams;
    }

    public TransformFunc getTransformFunc() {
        return transformFunc;
    }

    public void setTransformFunc(TransformFunc transformFunc) {
        this.transformFunc = transformFunc;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }

    public DeviceMeasPoint getDeviceMeasPoint() {
        return deviceMeasPoint;
    }

    public void setDeviceMeasPoint(DeviceMeasPoint deviceMeasPoint) {
        this.deviceMeasPoint = deviceMeasPoint;
    }

    public DeviceParam getDeviceParam() {
        return deviceParam;
    }

    public void setDeviceParam(DeviceParam deviceParam) {
        this.deviceParam = deviceParam;
    }
}