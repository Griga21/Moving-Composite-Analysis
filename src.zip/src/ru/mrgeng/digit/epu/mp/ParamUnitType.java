package ru.mrgeng.digit.epu.mp;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(name = "MP_PARAM_UNIT_TYPE", uniqueConstraints = {
        @UniqueConstraint(name = "UC_PARAM_UNIT_TYPE_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_ParamUnitType")
public class ParamUnitType extends MpObj {
    private static final long serialVersionUID = 1L;

}