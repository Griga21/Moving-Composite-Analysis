package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.UUID;

import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.dgcore.entity.Obj;
import ru.mrgeng.digit.dgcore.entity.SysUser;
import ru.mrgeng.digit.dgcore.entity.Department;

@Table(name = "MP_DISP_SHIFT", uniqueConstraints = {
        @UniqueConstraint(name = "DS_UNQ", columnNames = {"DATE_FROM", "DEPARTMENT_ID"})
})
@Entity(name = "mp_DispShift")
@NamePattern("%s (%s)|dispatcher,dateFrom")
public class DispShift extends Obj {
    private static final long serialVersionUID = 2681811909523710074L;

    @NotNull
    @Column(name = "DATE_FROM", nullable = false)
    private LocalDateTime dateFrom = LocalDateTime.now();

    @SystemLevel
    @Column(name = "DEPARTMENT_ID")
    private Long departmentId;

    @MetaProperty(related = "departmentId")
    @Transient
    private Department department;

    @SystemLevel
    @Column(name = "DISPATCHER_ID")
    private UUID dispatcherId;

    @MetaProperty(related = "dispatcherId")
    @Transient
    private SysUser dispatcher;

    @Column(name = "COMMENT")
    private String comment;

    public LocalDateTime getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(LocalDateTime dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public SysUser getDispatcher() {
        return dispatcher;
    }

    public void setDispatcher(SysUser dispatcher) {
        this.dispatcher = dispatcher;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public UUID getDispatcherId() {
        return dispatcherId;
    }

    public void setDispatcherId(UUID dispatcherId) {
        this.dispatcherId = dispatcherId;
    }
}