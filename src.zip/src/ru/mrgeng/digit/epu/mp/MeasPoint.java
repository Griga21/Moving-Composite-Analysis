package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.epu.service.DeviceParamService;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * Чем отличается MeasPoint от DeviceMeasPoint? У DeviceMeasPoint Device в названии, а у MeasPoint Device внутри.
 */
@Table(name = "MP_MEAS_POINT", uniqueConstraints = {
        @UniqueConstraint(name = "UK_MP_MEAS_POINT", columnNames = {"DEVICE_ID", "DEVICE_MEAS_POINT_ID"})
})
@Entity(name = "mp_MeasPoint")
@NamePattern("#getCaption|device, deviceMeasPoint, name")
public class MeasPoint extends Obj {
    private static final long serialVersionUID = 2290014257300095588L;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_ID")
    @OnDeleteInverse(value = DeletePolicy.CASCADE)
    private Device device;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MEAS_POINT_ID")
    private DeviceMeasPoint deviceMeasPoint;

    @Column(name = "NAME", length = 64)
    private String name;

    @NotNull
    @Column(name = "ACTUALIZATION_MARK")
    protected Integer actualizationMark;

    public boolean isActual() {
        return ActualizationMark.isActual(actualizationMark);
    }

    public ActualizationMark getActualizationMark() {
        return actualizationMark == null ? null : ActualizationMark.fromId(actualizationMark);
    }

    public void setActualizationMark(ActualizationMark mark) {
        this.actualizationMark = mark == null ? null : mark.getId();
    }

    public String getCaption() {
        return device.getName() + (getName() == null ?
                (deviceMeasPoint == null ? null : " (" + deviceMeasPoint.getName() + ")") : " (" + getName() + ")");
    }

    public String getObjId() {
        return deviceMeasPoint == null ? device.getCode() : device.getCode() + "." + deviceMeasPoint.getCode();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public DeviceMeasPoint getDeviceMeasPoint() {
        return deviceMeasPoint;
    }

    public void setDeviceMeasPoint(DeviceMeasPoint deviceMeasPoint) {
        this.deviceMeasPoint = deviceMeasPoint;
    }

    public String getLineCode() {
        return deviceMeasPoint != null ? deviceMeasPoint.getCode() : DeviceParamService.NO_MEAS_POINT;
    }

    public String getLineCodeOrNull() {
        return deviceMeasPoint != null ? deviceMeasPoint.getCode() : null;
    }

    @Override
    public String toString() {
        return "MeasPoint{id=" + id +
                ", device=" + device +
                ", deviceMeasPoint=" + deviceMeasPoint +
                ", name='" + name + '\'' +
                ", actualizationMark=" + actualizationMark +
                '}';
    }
}