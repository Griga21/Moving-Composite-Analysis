package ru.mrgeng.digit.epu.mp.drivertree;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum DriverElementFilterOption implements EnumClass<Integer> {

    TRANSFORM_ONLY(10),
    PARAM_WITHOUT_TRANSFORM(20),
    PARAM_WRITE_ACCESS(30),
    PARAM_READ_ACCESS(40),
    PARAM_WITHOUT_PROTO_ADDRESS(50)
    ;

    private Integer id;

    DriverElementFilterOption(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static DriverElementFilterOption fromId(Integer id) {
        for (DriverElementFilterOption at : DriverElementFilterOption.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
