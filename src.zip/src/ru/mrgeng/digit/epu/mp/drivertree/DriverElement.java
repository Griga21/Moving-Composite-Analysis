package ru.mrgeng.digit.epu.mp.drivertree;

import com.haulmont.chile.core.annotations.MetaClass;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.BaseLongIdEntity;
import ru.mrgeng.digit.dgcore.service.DictObj;
import ru.mrgeng.digit.epu.mp.*;
import ru.mrgeng.digit.epu.service.MpService;
import ru.mrgeng.digit.epu.transform.Transform;
import ru.mrgeng.digit.epu.util.BitMaskUtils;


@NamePattern("%s; %s (%s)|type,name,code")
@MetaClass(name = "mp_DriverElement")
public class DriverElement extends BaseLongIdEntity implements DictObj {
    private static final long serialVersionUID = 1L;

    public static final String GROUP_ITEM = "Группа";
    public static final String PARAM_ITEM = "Параметр";
    public static final String TRANSFORM_ITEM = "Преобразование";

    @MetaProperty
    private Long origId;

    @MetaProperty
    private DriverElement parent;

    @MetaProperty
    private String type;

    @MetaProperty
    private ParamUnitMetricPrefix metricPrefix;

    @MetaProperty
    private ParamUnit paramUnit;

    @MetaProperty
    private TransformFunc transformFunc;

    @MetaProperty
    private DeviceMeasPoint deviceMeasPoint;// место измерения

    @MetaProperty
    private String measTsParam;// время из параметра

    @MetaProperty
    private String transformParams;

    @MetaProperty
    private Transform addTransform;

    @MetaProperty
    private String addTransformParams;

    @MetaProperty
    private TransformFunc dateTransformFunc;

    @MetaProperty
    private String protoAddress;

    @MetaProperty
    private String code;

    @MetaProperty
    private String name;

    @MetaProperty
    private Device connectedDevice;

    @MetaProperty
    private Integer flag;

    @MetaProperty
    private Integer dataClass;

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Device getConnectedDevice() {
        return connectedDevice;
    }

    public void setConnectedDevice(Device connectedDevice) {
        this.connectedDevice = connectedDevice;
    }

    @Override
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @MetaProperty
    private String dataType;

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getProtoAddress() {
        return protoAddress;
    }

    public void setProtoAddress(String protoAddress) {
        this.protoAddress = protoAddress;
    }

    public String getTransformParams() {
        return transformParams;
    }

    public void setTransformParams(String transformParams) {
        this.transformParams = transformParams;
    }

    public DeviceMeasPoint getDeviceMeasPoint() {
        return deviceMeasPoint;
    }

    public void setDeviceMeasPoint(DeviceMeasPoint deviceMeasPoint) {
        this.deviceMeasPoint = deviceMeasPoint;
    }

    public String getMeasTsParam() {
        return measTsParam;
    }

    public void setMeasTsParam(String measTsParam) {
        this.measTsParam = measTsParam;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public DriverElement getParent() {
        return parent;
    }

    public void setParent(DriverElement parent) {
        this.parent = parent;
    }

    public ParamUnitMetricPrefix getMetricPrefix() {
        return metricPrefix;
    }

    public void setMetricPrefix(ParamUnitMetricPrefix metricPrefix) {
        this.metricPrefix = metricPrefix;
    }

    public ParamUnit getParamUnit() {
        return paramUnit;
    }

    public void setParamUnit(ParamUnit paramUnit) {
        this.paramUnit = paramUnit;
    }

    public TransformFunc getDateTransformFunc() {
        return dateTransformFunc;
    }

    public void setDateTransformFunc(TransformFunc dateTransformFunc) {
        this.dateTransformFunc = dateTransformFunc;
    }

    public TransformFunc getTransformFunc() {
        return transformFunc;
    }

    public void setTransformFunc(TransformFunc transformFunc) {
        this.transformFunc = transformFunc;
    }

    public Long getOrigId() {
        return origId;
    }

    public void setOrigId(Long origId) {
        this.origId = origId;
    }


    public Transform getAddTransform() {
        return addTransform;
    }

    public void setAddTransform(Transform addTransform) {
        this.addTransform = addTransform;
    }

    public String getAddTransformParams() {
        return addTransformParams;
    }

    public void setAddTransformParams(String addTransformParams) {
        this.addTransformParams = addTransformParams;
    }

    public DriverElement init(DeviceParam deviceParam, DriverElement parent) {
        initMpObjParams(deviceParam);
        setParent(parent);
        setMetricPrefix(deviceParam.getMetricPrefix());
        setParamUnit(deviceParam.getParamUnit());
        setProtoAddress(deviceParam.getProtoAddress());
        setFlag(deviceParam.getFlag());
        if (deviceParam.getDeviceParamType() != null)
            setDataType(deviceParam.getDeviceParamType().getCode());
        setType(PARAM_ITEM);
        return this;
    }

    public DriverElement init(DeviceParamTransformGroupTs transform, DriverElement parent) {
        iniObjParams(transform);
        Param param = transform.getParam();
        if (param != null) {
            setCode(param.getCode());

            if (param.getParamGroup() != null) {
                setName(param.getName() + "\\" + param.getParamGroup().getName());
            } else {
                setName(param.getName());
            }

            if (param.getParamType() != null)
                setDataType(param.getParamType().getCode());
            setMetricPrefix(param.getMetricPrefix());
            setParamUnit(param.getParamUnit());
        }
        setTransformFunc(transform.getTransformFunc());
        setDateTransformFunc(transform.getDateTransformFunc());
        if (transform.getMeasTsParam() != null)
            setMeasTsParam(transform.getMeasTsParam().getCode());
        setDeviceMeasPoint(transform.getDeviceMeasPoint());
        setTransformParams(transform.getTransformParams());
        setConnectedDevice(transform.getConnectedDevice());
        setAddTransform(transform.getAddTransform());
        setAddTransformParams(transform.getAddTransformParams());
        setParent(parent);
        setType(TRANSFORM_ITEM);
        return this;
    }

    public DriverElement init(DeviceParamGroup deviceParamGroup) {
        initMpObjParams(deviceParamGroup);
        setProtoAddress(deviceParamGroup.getProtoAddress());
        setDataClass(deviceParamGroup.getDataClass());
        setType(GROUP_ITEM);
        return this;
    }

    private void initMpObjParams(MpObj mpObj) {
        iniObjParams(mpObj);
        setName(mpObj.getName());
        setCode(mpObj.getCode());
    }

    private void iniObjParams(Obj obj) {
        setOrigId(obj.getId());
    }

    public DriverElement init(DeviceParam deviceParam) {
        initMpObjParams(deviceParam);
        return this;
    }

    public boolean isGroup() {
        return GROUP_ITEM.equals(type);
    }

    public boolean isParam() {
        return PARAM_ITEM.equals(type);
    }

    public boolean isTransform() {
        return TRANSFORM_ITEM.equals(type);
    }

    public boolean isWriteParam() {
        if (isParam())
            return flag == null ? code.endsWith(MpService.paramSetEnd) : BitMaskUtils.isWrite(flag);
        return false;
    }

    public boolean isReadParam() {
        if (isParam())
            return flag == null ? !code.endsWith(MpService.paramSetEnd) : BitMaskUtils.isRead(flag);
        return false;
    }

    public Class<? extends Obj> getOriginClass() {
        if (PARAM_ITEM.equals(type)) {
            return DeviceParam.class;
        } else if (GROUP_ITEM.equals(type)) {
            return DeviceParamGroup.class;
        } else if (TRANSFORM_ITEM.equals(type)) {
            return DeviceParamTransformGroupTs.class;
        } else {
            return null;
        }
    }

    public ParamGroupDataClass getDataClass() {
        return dataClass == null ? null : ParamGroupDataClass.fromId(dataClass);
    }

    public void setDataClass(ParamGroupDataClass dataClass) {
        this.dataClass = dataClass == null ? null : dataClass.getId();
    }
}
