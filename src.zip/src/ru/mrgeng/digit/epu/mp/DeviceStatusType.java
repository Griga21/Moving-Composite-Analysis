package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum DeviceStatusType implements EnumClass<Integer>  {
    WORKING(1),
    NOT_WORKING(2);

    private final Integer id;

    DeviceStatusType(int id) {
        this.id = id;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Nullable
    public static DeviceStatusType fromId(Integer id) {
        for (DeviceStatusType at : DeviceStatusType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
