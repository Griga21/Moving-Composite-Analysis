package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import java.util.Calendar;
import java.util.Date;

public enum RequestPeriod implements EnumClass<Integer> {

    //  по миллисекундам от 100 до 199
    //  по секундам от 200 до 299
    //  по минутам от 300 до 399
    PREVIOUS_HOUR(400),//  по часам от 400 до 499
    THIS_HOUR(450),//  по часам от 400 до 499
    THIS_AND_PREVIOUS_HOUR(470),//  по часам от 400 до 499
    THIS_AND_PREVIOUS_12_HOUR(480),//  по часам от 400 до 499
    PREVIOUS_DAY(500),//  по дням от 500 до 599
    CURRENT_DAY(501),
    PREVIOUS_TWO_DAY(503),
    PREVIOUS_THREE_DAY(506),
    PREVIOUS_FOUR_DAY(510),
    PREVIOUS_FIVE_DAY(520),
    PREVIOUS_WEEK(530),
    PREVIOUS_EIGHT_DAY(540),
    PREVIOUS_TWO_WEEKS(550),
    PREVIOUS_THREE_WEEKS(560);
    // и т. д.

    private Integer id;

    RequestPeriod(Integer id) {
        this.id = id;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public static RequestPeriod fromId(Integer id) {
        for (RequestPeriod rp : RequestPeriod.values())
            if (rp.getId().equals(id))
                return rp;
        return null;
    }

    public static String getAllureName(RequestPeriod rp) {
        return rp == null ? "LAST" : rp.toString();
    }

    public static DatePeriod getDatePeriod(RequestPeriod requestPeriod, int commHour) {
        if (requestPeriod == null)
            return new DatePeriod(null);
        return getDatePeriod(getRounCalendar(), requestPeriod, commHour);
    }

    public static DatePeriod getDatePeriod(Calendar cal, RequestPeriod requestPeriod, int commHour) {
        int dayShift = cal.get(Calendar.HOUR_OF_DAY) <= commHour ? 1 : 0;
        return getDatePeriod(cal, requestPeriod, 1, dayShift, commHour, commHour);
    }

    public static DatePeriod getDatePeriod(RequestPeriod requestPeriod) {
        if (requestPeriod == null)
            return new DatePeriod(null);
        return getDatePeriod(getRounCalendar(), requestPeriod);
    }

    public static DatePeriod getDatePeriod(Calendar calendar, RequestPeriod requestPeriod) {
        return getDatePeriod(calendar, requestPeriod, 0, 1, 0, 0);
    }

    public static DatePeriod getDatePeriod(Calendar calendar,
                                           RequestPeriod requestPeriod,
                                           int increaseDayPeriod,
                                           int dayShift,
                                           int hourFrom,
                                           int hourTo) {
        switch (requestPeriod) {
            case PREVIOUS_HOUR:
                return toHourPeriod(calendar, 1, 0);
            case THIS_HOUR:
                return toHourPeriod(calendar, 0, 0);
            case THIS_AND_PREVIOUS_HOUR:
                return toHourPeriod(calendar, 0, 1);
            case THIS_AND_PREVIOUS_12_HOUR:
                return toHourPeriod(calendar, 0, 12);
            case CURRENT_DAY:
                return toDayPeriod(calendar, 0, increaseDayPeriod, hourFrom, hourTo);
            case PREVIOUS_DAY:
                return toDayPeriod(calendar, dayShift, increaseDayPeriod, hourFrom, hourTo);
            case PREVIOUS_TWO_DAY:
                return toDayPeriod(calendar, dayShift, 1, hourFrom, hourTo);
            case PREVIOUS_THREE_DAY:
                return toDayPeriod(calendar, dayShift, 2, hourFrom, hourTo);
            case PREVIOUS_FOUR_DAY:
                return toDayPeriod(calendar, dayShift, 3, hourFrom, hourTo);
            case PREVIOUS_FIVE_DAY:
                return toDayPeriod(calendar, dayShift, 4, hourFrom, hourTo);
            case PREVIOUS_WEEK:
                return toDayPeriod(calendar, dayShift, 6, hourFrom, hourTo);
            case PREVIOUS_EIGHT_DAY:
                return toDayPeriod(calendar, dayShift, 7, hourFrom, hourTo);
            case PREVIOUS_TWO_WEEKS:
                return toDayPeriod(calendar, dayShift, 13, hourFrom, hourTo);
            case PREVIOUS_THREE_WEEKS:
                return toDayPeriod(calendar, dayShift, 20, hourFrom, hourTo);
            default:
                throw new RuntimeException(requestPeriod + " - не предусмотрен обработчик");
        }
    }

    public static DatePeriod toHourPeriod(Calendar cal, int hourShift, int period) {
        cal.add(Calendar.HOUR_OF_DAY, -hourShift);
        Date to = cal.getTime();
        cal.add(Calendar.HOUR_OF_DAY, -period);
        Date from = cal.getTime();
        return new DatePeriod(from, to);
    }

    public static DatePeriod toDayPeriod(Calendar cal, int dayShift, int period, int commHourFrom, int commHourTo) {
        cal.set(Calendar.HOUR_OF_DAY, commHourTo);
        cal.add(Calendar.DAY_OF_MONTH, -dayShift);
        Date to = cal.getTime();
        cal.add(Calendar.DAY_OF_MONTH, -period);
        cal.set(Calendar.HOUR_OF_DAY, commHourFrom);
        Date from = cal.getTime();
        return new DatePeriod(from, to);
    }

    public static Calendar getRounCalendar() {
        return roundSeconds(Calendar.getInstance());
    }

    public static Calendar roundSeconds(Calendar calendar) {
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar;
    }
}