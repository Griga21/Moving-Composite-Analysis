package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.annotation.Listeners;

import javax.persistence.*;

@Table(name = "MP_DEVICE_PARAM_TRANSFORM_ANY")
@Entity(name = "mp_DeviceParamTransformAny")
@Listeners("pros_MpConfListener")
public class DeviceParamTransformAny extends DeviceParamTransform {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TRANSFORM_ANY_FUNC_ID")
    private TransformFunc transformFuncAny;

    public TransformFunc getTransformFuncAny() {
        return transformFuncAny;
    }

    public void setTransformFuncAny(TransformFunc transformFunc) {
        this.transformFuncAny = transformFunc;
    }


}
