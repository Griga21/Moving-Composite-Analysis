package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum GasQualityProtocolStatus implements EnumClass<Integer> {

    COMPLETED(10),
    NOT_COMPLETED(20),
    PASSWORD_REQUIRED(30),
    COMPLETED_MANUALLY(40),
    PASSWORD_ACCEPTED(50),
    SENT(60);

    private Integer id;

    GasQualityProtocolStatus(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static GasQualityProtocolStatus fromId(Integer id) {
        for (GasQualityProtocolStatus at : GasQualityProtocolStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}