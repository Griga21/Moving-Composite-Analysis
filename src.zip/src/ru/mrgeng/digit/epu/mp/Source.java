package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(name = "MP_SOURCE", uniqueConstraints = {
        @UniqueConstraint(name = "UC_SOURCE_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_Source")
@NamePattern("%s(%s)|name,code")
public class Source extends MpObj {
    private static final long serialVersionUID = 1L;
}