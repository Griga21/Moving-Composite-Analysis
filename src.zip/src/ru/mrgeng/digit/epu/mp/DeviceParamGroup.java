package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.*;

/**
 * В случае изменения сущности, модифицировать отчет driverExport
 */
@Table(name = "MP_DEVICE_PARAM_GROUP", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_PARAM_GROUP_CODE",
                columnNames = {"DEVICE_PROTO_MODEL_ID", "PARENT_ID", "CODE"})
})
@Entity(name = "mp_DeviceParamGroup")
@NamePattern("%s(%s)|name,code")
@Listeners("pros_MpConfListener")
public class DeviceParamGroup extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "PROTO_ADDRESS")
    private String protoAddress;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_ID")
    private DeviceParamGroup parent;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PROTO_MODEL_ID")
    @OnDeleteInverse(value = DeletePolicy.CASCADE)
    private DeviceProtoModel deviceProtoModel;

    @Column(name = "DATA_CLASS")
    private Integer dataClass;

    public DeviceProtoModel getDeviceProtoModel() {
        return deviceProtoModel;
    }

    public void setDeviceProtoModel(DeviceProtoModel deviceProtoModel) {
        this.deviceProtoModel = deviceProtoModel;
    }

    public DeviceParamGroup getParent() {
        return parent;
    }

    public void setParent(DeviceParamGroup parent) {
        this.parent = parent;
    }

    public String getProtoAddress() {
        return protoAddress;
    }

    public void setProtoAddress(String protoAddress) {
        this.protoAddress = protoAddress;
    }

    public ParamGroupDataClass getDataClass() {
        return dataClass == null ? null : ParamGroupDataClass.fromId(dataClass);
    }

    public void setDataClass(ParamGroupDataClass dataClass) {
        this.dataClass = dataClass == null ? null : dataClass.getId();
    }
}