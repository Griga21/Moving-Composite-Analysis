package ru.mrgeng.digit.epu.mp;

import org.locationtech.jts.geom.Point;
import ru.mrgeng.digit.epu.gis.BaseCoordConvertor;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * Конвертор для meas_params
 */
@Converter
public class MpPointWKTConverter extends BaseCoordConvertor implements AttributeConverter<Point, String> {
}