package ru.mrgeng.digit.epu.mp;

import org.slf4j.Logger;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import ru.mrgeng.digit.epu.config.AppSettingsConfig;

import javax.inject.Inject;
import java.util.Map;


@Component(AppConfiguration.NAME)
public class AppConfiguration {
    public static final String NAME = "dgepu_AppConfiguration";

    @Inject
    private Logger log;

    @Inject
    private AppSettingsConfig config;

    @Autowired
    private Map<String, IDeviceDataKeeper> dataKeepers;

    @Bean
    public IDeviceDataKeeper ddKeeper() {
        IDeviceDataKeeper ddk = dataKeepers.get(config.getDdKeeper());
        if (ddk == null)
            throw new BeanCreationException("Не найден компонент: " + config.getDdKeeper());
        log.info("Use ddk={}: {}", config.getDdKeeper(), ddk);
        return ddk;
    }


}