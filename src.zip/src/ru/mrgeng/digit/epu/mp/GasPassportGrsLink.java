package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.StandardEntity;
import ru.mrgeng.digit.epu.pros.bz.Grs;

import javax.persistence.*;

@Table(name = "MP_GAS_PASSPORT_GRS_LINK")
@Entity(name = "mp_GasPassportGrsLink")
public class GasPassportGrsLink extends StandardEntity {
    private static final long serialVersionUID = 5341536112033850296L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GRS_ID")
    private Grs grs;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "PASSPORT_ID", nullable = false)
    private GasQualityPassport passport;

    public void setPassport(GasQualityPassport passport) {
        this.passport = passport;
    }

    public GasQualityPassport getPassport() {
        return passport;
    }

    public Grs getGrs() {
        return grs;
    }

    public void setGrs(Grs grs) {
        this.grs = grs;
    }
}
