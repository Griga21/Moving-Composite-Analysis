package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Статус устройства
 */
@Table(name = "MP_DEVICE_STATUS", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_STATUS_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_DeviceStatus")
@NamePattern("%s|name")
public class DeviceStatus extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "COLOR")
    private String color;

    @Column(name = "TYPE")
    private Integer type;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public DeviceStatusType getType() {
        return type != null ? DeviceStatusType.fromId(type) : null;
    }

    public void setType(DeviceStatusType type) {
        this.type = type != null ? type.getId() : null;
    }
}