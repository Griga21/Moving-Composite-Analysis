package ru.mrgeng.digit.epu.mp;


import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;
import java.util.List;

@Table(name = "MP_DEVICE_GROUP")
@Entity(name = "mp_DeviceGroup")
@NamePattern("%s|name")
public class DeviceGroup extends Obj {
    private static final long serialVersionUID = -7003477469530927432L;

    @Column(name = "NAME", length = 256)
    private String name;

    @Column(name = "COMMENT", length = 512)
    private String comment;

    @ManyToMany
    @JoinTable(name = "MP_DEVICE_GROUP_MP_DEVICE_LINK",
            joinColumns = @JoinColumn(name = "DEVICE_GROUP_ID"),
            inverseJoinColumns = @JoinColumn(name = "DEVICE_ID"))
    private List<Device> devices;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public List<Device> getDevices() {
        return devices;
    }

    public void setDevices(List<Device> devices) {
        this.devices = devices;
    }
}