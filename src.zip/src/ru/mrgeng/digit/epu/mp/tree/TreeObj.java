package ru.mrgeng.digit.epu.mp.tree;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.*;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;
import ru.mrgeng.digit.epu.mp.Device;

import javax.persistence.*;
import javax.persistence.Entity;
import java.util.Date;

/*
 * Объекты в дерева (устройства)
 * */
@Table(name = "MP_TREE_OBJ")
@Entity(name = "mp_TreeObj")
@NamePattern("%s|code")
public class TreeObj extends BaseUuidEntity implements Creatable, Updatable, SoftDelete, Versioned {
    private static final long serialVersionUID = -562422233397497660L;
    @Column(name = "NAME") //ID Группы в SVG
    public String code;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    @OnDeleteInverse(DeletePolicy.CASCADE)
    public Device device;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TREE_GROUP_ID")
    @OnDeleteInverse(DeletePolicy.CASCADE)
    public TreeGroup group;

    @Column(name = "CREATE_TS")
    private Date createTs;

    @Column(name = "CREATED_BY", length = 50)
    private String createdBy;

    @Column(name = "UPDATE_TS")
    private Date updateTs;

    @Column(name = "UPDATED_BY", length = 50)
    private String updatedBy;

    @Column(name = "DELETE_TS")
    private Date deleteTs;

    @Column(name = "DELETED_BY", length = 50)
    private String deletedBy;

    @Version
    @Column(name = "VERSION", nullable = false)
    private Integer version;

    @Override
    public Date getCreateTs() {
        return createTs;
    }

    @Override
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    @Override
    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public Date getUpdateTs() {
        return updateTs;
    }

    @Override
    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }

    @Override
    public String getUpdatedBy() {
        return updatedBy;
    }

    @Override
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public Boolean isDeleted() {
        return deleteTs != null;
    }

    @Override
    public Date getDeleteTs() {
        return deleteTs;
    }

    @Override
    public void setDeleteTs(Date deleteTs) {
        this.deleteTs = deleteTs;
    }

    @Override
    public String getDeletedBy() {
        return deletedBy;
    }

    @Override
    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    @Override
    public Integer getVersion() {
        return version;
    }

    @Override
    public void setVersion(Integer version) {
        this.version = version;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Device getDevice() {
        return device;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setGroup(TreeGroup group) {
        this.group = group;
    }

    public TreeGroup getGroup() {
        return group;
    }
}