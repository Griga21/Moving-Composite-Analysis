package ru.mrgeng.digit.epu.mp.tree;

import com.haulmont.chile.core.annotations.MetaClass;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.BaseUuidEntity;
import ru.mrgeng.digit.epu.mp.Device;

import java.util.List;
import java.util.Objects;

/**
 * Дерево объектов
 */
@NamePattern("%s|name")
@MetaClass(name = "mp_TreeItem")
public class TreeItem extends BaseUuidEntity {
    private static final long serialVersionUID = 2841282139364285356L;

    @MetaProperty
    protected String name;

    @MetaProperty
    private List<Device> allDevices;

    @MetaProperty
    protected TreeItem parent;

    @MetaProperty
    protected TreeGroup group;

    @MetaProperty
    protected TreeObj itemObj;

    protected Integer priority = 0;

    public List<Device> getAllDevices() {
        return allDevices;
    }

    public void setAllDevices(List<Device> allDevices) {
        this.allDevices = allDevices;
    }

    // красный=50; оранжевый=40; серый=30; зеленый=20; дефолный= 0 (отсутствие статуса);
    // устанавливается сымый высокий приоритет от группы устройств
    public Integer getPriority() {
        return priority;
    }

    @Override
    public synchronized void removePropertyChangeListener(PropertyChangeListener listener) {
        super.removePropertyChangeListener(listener);
    }

    public synchronized boolean calcPriority(TreeItem other) {
        if (other.priority > this.priority) {
            this.priority = other.priority;
            return true;
        }
        return false;
    }

    public synchronized void setPriority(Integer priority) {
        this.priority = priority;
    }

    public TreeObj getItemObj() {
        return itemObj;
    }

    public void setItemObj(TreeObj itemObj) {
        this.itemObj = itemObj;
    }

    public TreeItem getParent() {
        return parent;
    }

    public void setParent(TreeItem parent) {
        this.parent = parent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TreeGroup getGroup() {
        return group;
    }

    public void setGroup(TreeGroup group) {
        this.group = group;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TreeItem)) return false;
        if (!super.equals(o)) return false;
        TreeItem item = (TreeItem) o;
        return Objects.equals(getId(), item.getId()) &&
                Objects.equals(getName(), item.getName()) &&
                Objects.equals(getParent(), item.getParent()) &&
                Objects.equals(getGroup(), item.getGroup()) &&
                Objects.equals(getItemObj(), item.getItemObj());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getId(), getName(), getParent(), getGroup(), getItemObj());
    }
}