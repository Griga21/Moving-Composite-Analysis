package ru.mrgeng.digit.epu.mp.tree;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.*;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.epu.mp.techschema.schemafile.TechSchema;


import javax.persistence.*;
import javax.persistence.Entity;
import java.util.Date;
import java.util.UUID;

/**
 * Группа в дереве
 */

@Table(name = "MP_TREE_GROUP")
@Entity(name = "mp_TreeGroup")
@NamePattern("%s|name")
public class TreeGroup extends BaseUuidEntity implements Creatable, Updatable, SoftDelete, Versioned {
    private static final long serialVersionUID = 7991461560245450649L;

    @Column(name = "NAME")
    protected String name;

    @Column(name = "GRO")
    protected Integer gro;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_ID")
    protected TreeGroup parent;

    @Column(name = "TechSchemaModel_ID")
    private UUID techSchemaModelId;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TECH_SCHEMA_ID")
    private TechSchema techSchema;
    @Column(name = "CREATE_TS")
    private Date createTs;

    @Column(name = "CREATED_BY", length = 50)
    private String createdBy;

    @Column(name = "UPDATE_TS")
    private Date updateTs;

    @Column(name = "UPDATED_BY", length = 50)
    private String updatedBy;

    @Column(name = "DELETE_TS")
    private Date deleteTs;

    @Column(name = "DELETED_BY", length = 50)
    private String deletedBy;

    @Version
    @Column(name = "VERSION", nullable = false)
    private Integer version;

    @Override
    public Date getCreateTs() {
        return createTs;
    }

    @Override
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    @Override
    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public Date getUpdateTs() {
        return updateTs;
    }

    @Override
    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }

    @Override
    public String getUpdatedBy() {
        return updatedBy;
    }

    @Override
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public Boolean isDeleted() {
        return deleteTs != null;
    }

    @Override
    public Date getDeleteTs() {
        return deleteTs;
    }

    @Override
    public void setDeleteTs(Date deleteTs) {
        this.deleteTs = deleteTs;
    }

    @Override
    public String getDeletedBy() {
        return deletedBy;
    }

    @Override
    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    @Override
    public Integer getVersion() {
        return version;
    }

    @Override
    public void setVersion(Integer version) {
        this.version = version;
    }

    public TechSchema getTechSchema() {
        return techSchema;
    }

    public void setTechSchema(TechSchema techSchema) {
        this.techSchema = techSchema;
    }


    public UUID getTechSchemaModelId() {
        return techSchemaModelId;
    }

    public void setTechSchemaModelId(UUID techSchemaModelId) {
        this.techSchemaModelId = techSchemaModelId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TreeGroup getParent() {
        return parent;
    }

    public void setParent(TreeGroup parent) {
        this.parent = parent;
    }

    public Integer getGro() {
        return gro;
    }

    public void setGro(Integer gro) {
        this.gro = gro;
    }
}