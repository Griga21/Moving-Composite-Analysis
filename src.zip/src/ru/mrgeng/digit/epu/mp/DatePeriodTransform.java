package ru.mrgeng.digit.epu.mp;

import org.apache.commons.lang3.time.DateUtils;

import java.util.Calendar;

public class DatePeriodTransform {
    public static DatePeriod toCommDayPeriod(DatePeriod period, int commHour) {
        Calendar to = Calendar.getInstance();
        to.setTime(period.getTo());
        to.add(Calendar.DAY_OF_MONTH, 1);
        to.set(Calendar.HOUR_OF_DAY, commHour);
        return new DatePeriod(
                DateUtils.setHours(period.getFrom(), commHour),
                to.getTime());
    }

    public static DatePeriod toCommDayPeriodHourOffset(DatePeriod period, int commHour, int requestDeep) {
        int offset = requestDeep >= 24 ? requestDeep % 24 : requestDeep - 23;
        Calendar to = Calendar.getInstance();
        to.setTime(period.getTo());
        to.add(Calendar.DAY_OF_MONTH, 1);
        to.set(Calendar.HOUR_OF_DAY, commHour);
        return new DatePeriod(
                DateUtils.addHours(period.getFrom(), commHour + 1 - offset),
                to.getTime());
    }
}
