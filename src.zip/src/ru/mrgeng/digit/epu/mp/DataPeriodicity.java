package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import java.util.Calendar;

public enum DataPeriodicity implements EnumClass<Integer> {

    MILLISECOND(150, "cur", Calendar.MILLISECOND), //  по миллисекундам от 100 до 199
    //  по секундам от 200 до 299
    //  по минутам от 300 до 399
    HOUR(450, "h", Calendar.HOUR_OF_DAY),// по часам от 400 до 499
    DAY(550, "d", Calendar.DAY_OF_MONTH);// по дням от 500 до 599
    // по неделям от 600 до 699

    private final Integer id;

    private final String code;

    private final Integer calendar;

    DataPeriodicity(Integer id, String code, Integer calendar) {
        this.id = id;
        this.code = code;
        this.calendar = calendar;
    }

    public String getCode() {
        return code;
    }

    public Integer getCalendar() {
        return calendar;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public static DataPeriodicity fromId(Integer id) {
        for (DataPeriodicity rp : DataPeriodicity.values())
            if (rp.getId().equals(id))
                return rp;
        return null;
    }

    public static DataPeriodicity ofParamGroupCode(String paramGroupCode) {
        if (paramGroupCode != null) {
            if (paramGroupCode.endsWith(DAY.code))
                return DataPeriodicity.DAY;
            if (paramGroupCode.endsWith(HOUR.code))
                return DataPeriodicity.HOUR;
        }
        return DataPeriodicity.MILLISECOND;
    }
}
