package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum GasQualityPassportStatus implements EnumClass<Integer> {

    SENT(10),
    EDITING(20);

    private Integer id;

    GasQualityPassportStatus(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static GasQualityPassportStatus fromId(Integer id) {
        for (GasQualityPassportStatus at : GasQualityPassportStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}