package ru.mrgeng.digit.epu.mp;

import ru.mrgeng.digit.dgcore.entity.Obj;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Table(name = "MP_DISP_SHIFT_MESSAGE")
@Entity(name = "mp_DispShiftMessage")
public class DispShiftMessage  extends Obj {
    private static final long serialVersionUID = -4277107237713049625L;

    @NotNull
    @JoinColumn(name = "DISP_SHIFT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    private DispShift shift;

    @Column(name = "MESSAGE", length = 4096)
    private String message;

    @Column(name = "COMMENT")
    private String comment;

    public DispShift getShift() {
        return shift;
    }

    public void setShift(DispShift shift) {
        this.shift = shift;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}