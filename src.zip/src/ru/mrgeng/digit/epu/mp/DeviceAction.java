package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "MP_DEVICE_ACTION", uniqueConstraints = {
        @UniqueConstraint(name = "MODEL_TYPE", columnNames = {"DEVICE_PROTO_MODEL_ID", "ACTION_TYPE"})
})
@Entity(name = "mp_DeviceAction")
public class DeviceAction extends Obj {
    private static final long serialVersionUID = 6217057616980735051L;

    @NotNull
    @Column(name = "ACTION_TYPE")
    private Integer actionType;

    @Column(name = "VALUE")
    private String value;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PROTO_MODEL_ID", nullable = false)
    @OnDeleteInverse(DeletePolicy.CASCADE)
    private DeviceProtoModel deviceProtoModel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PARAM_ID", nullable = false)
    @OnDeleteInverse(DeletePolicy.CASCADE)
    private DeviceParam deviceParam;

    public DeviceActionType getActionType() {
        return DeviceActionType.fromId(actionType);
    }

    public void setActionType(DeviceActionType actionType) {
        this.actionType = actionType.getId();
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public DeviceProtoModel getDeviceProtoModel() {
        return deviceProtoModel;
    }

    public void setDeviceProtoModel(DeviceProtoModel deviceProtoModel) {
        this.deviceProtoModel = deviceProtoModel;
    }

    public DeviceParam getDeviceParam() {
        return deviceParam;
    }

    public void setDeviceParam(DeviceParam deviceParam) {
        this.deviceParam = deviceParam;
    }
}