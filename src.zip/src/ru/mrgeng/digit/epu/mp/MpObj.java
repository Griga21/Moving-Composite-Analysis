package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import ru.mrgeng.digit.dgcore.service.DictObj;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
@NamePattern("%s(%s)|name,code")
public class MpObj extends Obj implements DictObj {

    private static final long serialVersionUID = 1L;

    @Column(name = "CODE", length = 256, nullable = false)
    protected String code;

    @Column(name = "NAME", length = 256)
    protected String name;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
