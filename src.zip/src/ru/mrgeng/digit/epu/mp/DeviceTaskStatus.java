package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum DeviceTaskStatus implements EnumClass<Integer> {

    ADS_ASSIGNED(10),
    TO_EP_PASSED(20),
    ACCEPTED_BY_EP(30),
    CLOSED(40);

    private Integer id;

    DeviceTaskStatus(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static DeviceTaskStatus fromId(Integer id) {
        for (DeviceTaskStatus at : DeviceTaskStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}