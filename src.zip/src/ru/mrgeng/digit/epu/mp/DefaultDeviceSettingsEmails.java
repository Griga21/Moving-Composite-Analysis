package ru.mrgeng.digit.epu.mp;


import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.*;

@Table(name = "MP_DEFAULT_DEVICE_SETTINGS_EMAILS")
@Entity(name = "mp_DefaultDeviceSettingsEmails")
@NamePattern("%s|name")
public class DefaultDeviceSettingsEmails extends Obj {

    private static final long serialVersionUID = 2658630013541809911L;

    @Column(name = "NAME")
    private String name;

    @Column(name = "EMAIL")
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}