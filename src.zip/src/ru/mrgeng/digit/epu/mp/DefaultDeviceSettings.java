package ru.mrgeng.digit.epu.mp;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.List;

@Table(name = "MP_DEFAULT_DEVICE_SETTINGS")
@Entity(name = "mp_DefaultDeviceSettings")
public class DefaultDeviceSettings extends MpObj {
    private static final long serialVersionUID = 6375205963318413118L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MODEL_ID")
    private DeviceModel deviceModel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PROTO_MODEL_ID")
    private DeviceProtoModel deviceProtoModel;

    @Column(name = "CHANNEL_SETTINGS_JSON", length = 2048)
    private String channelSettingsJson;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_SERVICE_ID")
    private DeviceService deviceService;

    @Column(name = "EMAILER_ACTIVATED")
    private Boolean emailerActivated;

    @Column(name = "RECALC_ENABLED")
    private Boolean recalcEnabled;

    @Column(name = "RECALC_ACC_DAY_PRIORITY")
    private Integer recalcAccDayPriority;

    @Column(name = "RECALC_HOUR_SUM_PRIORITY")
    private Integer recalcHourSumPriority;

    @Column(name = "RECALC_ACC_HOUR_PRIORITY")
    private Integer recalcAccHourPriority;

    @Min(0)
    @Max(23)
    @Column(name = "COMM_HOUR")
    private Integer commHour;

    @JoinTable(name = "MP_DEFAULT_DEVICE_SETTING_EMAILS_LINK",
            joinColumns = @JoinColumn(name = "DEFAULT_DEVICE_SETTING_EMAILS_ID"),
            inverseJoinColumns = @JoinColumn(name = "DEFAULT_DEVICE_SETTING_ID"))
    @ManyToMany
    private List<DefaultDeviceSettingsEmails> defaultDeviceSettingsEmails;

    public DeviceModel getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(DeviceModel deviceModel) {
        this.deviceModel = deviceModel;
    }

    public DeviceProtoModel getDeviceProtoModel() {
        return deviceProtoModel;
    }

    public void setDeviceProtoModel(DeviceProtoModel deviceProtoModel) {
        this.deviceProtoModel = deviceProtoModel;
    }

    public String getChannelSettingsJson() {
        return channelSettingsJson;
    }

    public void setChannelSettingsJson(String channelSettingsJson) {
        this.channelSettingsJson = channelSettingsJson;
    }

    public DeviceService getDeviceService() {
        return deviceService;
    }

    public void setDeviceService(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    public Boolean getEmailerActivated() {
        return emailerActivated;
    }

    public void setEmailerActivated(Boolean emailerActivated) {
        this.emailerActivated = emailerActivated;
    }

    public Boolean getRecalcEnabled() {
        return recalcEnabled;
    }

    public void setRecalcEnabled(Boolean recalcEnabled) {
        this.recalcEnabled = recalcEnabled;
    }

    public Integer getRecalcAccDayPriority() {
        return recalcAccDayPriority;
    }

    public void setRecalcAccDayPriority(Integer recalcAccDayPriority) {
        this.recalcAccDayPriority = recalcAccDayPriority;
    }

    public Integer getRecalcHourSumPriority() {
        return recalcHourSumPriority;
    }

    public void setRecalcHourSumPriority(Integer recalcHourSumPriority) {
        this.recalcHourSumPriority = recalcHourSumPriority;
    }

    public Integer getRecalcAccHourPriority() {
        return recalcAccHourPriority;
    }

    public void setRecalcAccHourPriority(Integer recalcAccHourPriority) {
        this.recalcAccHourPriority = recalcAccHourPriority;
    }

    public List<DefaultDeviceSettingsEmails> getDefaultDeviceSettingsEmails() {
        return defaultDeviceSettingsEmails;
    }

    public void setDefaultDeviceSettingsEmails(List<DefaultDeviceSettingsEmails> defaultDeviceSettingsEmails) {
        this.defaultDeviceSettingsEmails = defaultDeviceSettingsEmails;
    }

    public Integer getCommHour() {
        return commHour;
    }

    public void setCommHour(Integer commHour) {
        this.commHour = commHour;
    }

    public void fromDevice(Device device) {
        this.deviceService = device.getDeviceService();
        this.deviceModel = device.getDeviceModel();
        this.deviceProtoModel = device.getDeviceProtoModel();
        this.channelSettingsJson = device.getChannelSettingsJson();
        //this.commHour = device.getCommHour(); //Возможный перенос атрибута в класс Device commHour из динамических атрибутов
        this.setCode(device.getDeviceModel() != null ? device.getDeviceModel().getCode() : device.getCode());
    }
}
