package ru.mrgeng.digit.epu.mp;


import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import ru.mrgeng.digit.dgcore.service.util.StrUtils;

public class ReloadDDKEvent extends GlobalApplicationEvent {
    private static final long serialVersionUID = 1L;

    String serviceCode;

    public ReloadDDKEvent(Object source, String serviceCode) {
        super(source);
        this.serviceCode = serviceCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    @Override
    public String toString() {
        return StrUtils.toStr("ServiceConfChange", "serviceCode", serviceCode);
    }
}
