package ru.mrgeng.digit.epu.mp;

import ru.mrgeng.digit.epu.service.MpService;

import java.util.Date;
import java.util.List;

/**
 * Получение последних данных по устройству
 */
public interface IDeviceDataKeeper {
    MpService.SingleDeviceData getDeviceData(Device device);

    /**
     * @return Дата последних обновлений данных
     */
    Date getLastUpdateDate();
    
    void fillResultStorage(List<Device> devices);

    boolean isNotUpdated(Date from);

    void logData(String service);
}
