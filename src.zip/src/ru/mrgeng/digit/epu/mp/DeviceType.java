package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Тип устройства
 */
@Table(name = "MP_DEVICE_TYPE", uniqueConstraints = {
        @UniqueConstraint(name = "UC_DEVICE_TYPE_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_DeviceType")
@NamePattern("%s|name")
public class DeviceType extends MpObj {
    private static final long serialVersionUID = 1L;

    public static final String CORR_CODE  = "1";
    public static final String CORR_NAME  = "Корректор";
    public static final String PRG_CODE   = "2";
    public static final String PRG_NAME   = "Контроллер ПРГ";

    public static final String CHRO_CODE  = "3";
    public static final String CHRO_NAME  = "Хроматограф";

    public static final String SKZ_CODE  = "skz";
    public static final String SKZ_NAME  = "Контроллер СКЗ";

    public static final String SMART_CODE  = "4";
    public static final String SMART_NAME  = "Счетчик";

    public static final String CONTROLLER_RGC_CODE = "6";
    public static final String CONTROLLER_RGC_NAME  = "Контроллер СТМ";

    public static final String ZA_CODE = "za";
    public static final String ZA_NAME = "Запорная арматура";

    public static final String UORG_CODE = "uorg";
    public static final String UORG_NAME = "УОРГ";

    public static final String AD_CODE = "ad";
    public static final String AD_NAME = "Автономный датчик";

}