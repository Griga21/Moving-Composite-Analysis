package ru.mrgeng.digit.epu.mp;

import com.haulmont.addon.globalevents.GlobalApplicationEvent;
import com.haulmont.addon.globalevents.GlobalUiEvent;

public class UiDeviceChangeEvent extends GlobalApplicationEvent implements GlobalUiEvent {

    private final Device device;

    public UiDeviceChangeEvent(Object source, Device device) {
        super(source);
        this.device = device;
    }

    public Device getDevice() {
        return device;
    }
}
