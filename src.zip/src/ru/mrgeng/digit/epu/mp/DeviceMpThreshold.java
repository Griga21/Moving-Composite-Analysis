package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;

import javax.persistence.*;

@PublishEntityChangedEvents
@Table(name = "MP_DEVICE_MP_THRESHOLD")
@Entity(name = "mp_DeviceMpThreshold")
@Listeners("mp_ThresholdsChangesListener")
public class DeviceMpThreshold extends Obj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MP_ID")
    private DeviceMeasPoint deviceMp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_ID")
    private Param param;

    @Column(name = "LOW1")
    private Double low1;

    @Column(name = "LOW2")
    private Double low2;

    @Column(name = "HIGH1")
    private Double high1;

    @Column(name = "HIGH2")
    private Double high2;

    @Column(name = "DESIGN_VALUE")
    private Double designValue;

    public Double getHigh2() {
        return high2;
    }

    public void setHigh2(Double high2) {
        this.high2 = high2;
    }

    public Double getHigh1() {
        return high1;
    }

    public void setHigh1(Double high1) {
        this.high1 = high1;
    }

    public Double getLow2() {
        return low2;
    }

    public void setLow2(Double low2) {
        this.low2 = low2;
    }

    public Double getLow1() {
        return low1;
    }

    public void setLow1(Double low1) {
        this.low1 = low1;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }

    public DeviceMeasPoint getDeviceMp() {
        return deviceMp;
    }

    public void setDeviceMp(DeviceMeasPoint deviceMp) {
        this.deviceMp = deviceMp;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Double getDesignValue() {
        return designValue;
    }

    public void setDesignValue(Double designValue) {
        this.designValue = designValue;
    }
}