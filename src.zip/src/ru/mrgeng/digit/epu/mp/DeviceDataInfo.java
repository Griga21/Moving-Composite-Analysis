package ru.mrgeng.digit.epu.mp;

/**
 * Информация о кодах групп и параметров устройств
 */
public interface DeviceDataInfo {

    /**
     * Группа для хранения журнала аварий
     */
    String CORR_GA_GROUP = "ga";

    /**
     * Параметр с сообщением об аварии в группе
     */
    String CORR_GA_MSG = "ga";

    /**
     * Группа для хранения журнала вмешательств
     */
    String CORR_GV_GROUP = "gv";

    /**
     * Параметр с сообщением об вмешательстве в группе
     */
    String CORR_GV_MSG = "gv";

    // Название группы параметров суточных данных по умным счетчикам
    String METER_DAY_DATA_GROUP = "smart_arc_d";

    // Обычное название суммарного(накопительного) объема
    String DEV_COMMON_SUM_V = "vs";

}
