package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.BaseLongIdEntity;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;
import ru.mrgeng.digit.epu.param.SeriousLevel;

import javax.persistence.*;
import java.time.LocalDateTime;

@PublishEntityChangedEvents
@Table(name = "MP_DEVICE_EVENT")
@Entity(name = "mp_DeviceEvent")
public class DeviceEvent extends BaseLongIdEntity {
    private static final long serialVersionUID = 1L;

    @Column(name = "LEVEL")
    private Integer level;

    @Column(name = "TYPE")
    private Integer type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    @Column(name = "EVENT_TS")
    private LocalDateTime eventTs;

    @Column(name = "EVENT_REPEAT_TS")
    private LocalDateTime eventRepeatTs;

    @Column(name = "DATA_TS")
    private LocalDateTime dataTs;

    @Column(name = "DATA_INFO", length = 1000)
    private String dataInfo;

    @Column(name = "MSG", length = 1000)
    private String msg;

    @Column(name = "NORMALIZE_MSG", length = 128)
    private String normalizeMsg;

    @Column(name = "ACK_TS")
    private LocalDateTime ackTs;

    @Column(name = "NORMALIZE_TS")
    private LocalDateTime normalizeTs;

    @Column(name = "ACK_USER")
    private String ackUser;

    @Column(name = "ACK_NAME")
    private String ackName;

    @Column(name = "ACK_COMM")
    private String ackComm;

    @Column(name = "MEAS_POINT_CODE", length = 32)
    private String measPointCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_ID")
    private Param param;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MAINTENANCE_TASK_ID")
    private DeviceMaintenanceTask deviceMaintenanceTask;

    public String getNormalizeMsg() {
        return normalizeMsg;
    }

    public void setNormalizeMsg(String normalizeMsg) {
        this.normalizeMsg = normalizeMsg;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }

    public String getMeasPointCode() {
        return measPointCode;
    }

    public void setMeasPointCode(String measPointCode) {
        this.measPointCode = measPointCode;
    }

    public LocalDateTime getNormalizeTs() {
        return normalizeTs;
    }

    public void setNormalizeTs(LocalDateTime normalizeTs) {
        this.normalizeTs = normalizeTs;
    }

    public DeviceEventType getType() {
        return type == null ? null : DeviceEventType.fromId(type);
    }

    public void setType(DeviceEventType type) {
        this.type = type == null ? null : type.getId();
    }

    public void setEventRepeatTs(LocalDateTime eventRepeatTs) {
        this.eventRepeatTs = eventRepeatTs;
    }

    public LocalDateTime getEventRepeatTs() {
        return eventRepeatTs;
    }

    public void setEventTs(LocalDateTime eventTs) {
        this.eventTs = eventTs;
    }

    public LocalDateTime getEventTs() {
        return eventTs;
    }

    public void setDataTs(LocalDateTime dataTs) {
        this.dataTs = dataTs;
    }

    public LocalDateTime getDataTs() {
        return dataTs;
    }

    public void setAckTs(LocalDateTime ackTs) {
        this.ackTs = ackTs;
    }

    public LocalDateTime getAckTs() {
        return ackTs;
    }

    public SeriousLevel getLevel() {
        return level == null ? null : SeriousLevel.fromId(level);
    }

    public void setLevel(SeriousLevel level) {
        this.level = level == null ? null : level.getId();
    }

    public String getDataInfo() {
        return dataInfo;
    }

    public void setDataInfo(String dataInfo) {
        this.dataInfo = dataInfo;
    }

    public String getAckComm() {
        return ackComm;
    }

    public void setAckComm(String ackComm) {
        this.ackComm = ackComm;
    }


    public String getAckName() {
        return ackName;
    }

    public void setAckName(String ackName) {
        this.ackName = ackName;
    }

    public String getAckUser() {
        return ackUser;
    }

    public void setAckUser(String ackUser) {
        this.ackUser = ackUser;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public DeviceMaintenanceTask getDeviceMaintenanceTask() {
        return deviceMaintenanceTask;
    }

    public void setDeviceMaintenanceTask(DeviceMaintenanceTask deviceMaintenanceTask) {
        this.deviceMaintenanceTask = deviceMaintenanceTask;
    }
}
