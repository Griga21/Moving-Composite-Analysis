package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.dgcore.entity.SysUser;

import javax.persistence.*;
import java.util.UUID;

@Table(name = "MP_DEVICE_COMMENT")
@Entity(name = "mp_DeviceComment")
@NamePattern("%s|text")
public class DeviceComment extends Obj {

    private static final long serialVersionUID = 1L;

    @Column(name = "TEXT", length = 1024)
    private String text;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    @SystemLevel
    @Column(name = "USER_ID")
    private UUID userId;

    @MetaProperty(related = "userId")
    @Transient
    private SysUser author;

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public SysUser getAuthor() {
        return author;
    }

    public void setAuthor(SysUser author) {
        this.author = author;
    }
}