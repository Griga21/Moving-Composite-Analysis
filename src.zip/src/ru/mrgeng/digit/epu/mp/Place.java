package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.Categorized;
import com.haulmont.cuba.core.entity.Category;
import com.haulmont.cuba.core.entity.annotation.SystemLevel;
import ru.mrgeng.digit.dgcore.entity.Company;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.UUID;

@Table(name = "MP_PLACE")
@Entity(name = "mp_Place")
@NamePattern("%s|name")
public class Place extends MpObj implements Categorized {
    private static final long serialVersionUID = -7780599146106102753L;

    @Column(name = "ADDRESS")
    private String address;

    @SystemLevel
    @Column(name = "CATEGORY_ID")
    private UUID categoryId;

    @Column(name = "COMPANY_ID")
    @SystemLevel
    private Long companyId;

    @MetaProperty(related = "companyId")
    @Transient
    private Company company;

    @Transient
    @MetaProperty(related = "categoryId")
    private Category category;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public Category getCategory() {
        return category;
    }

    @Override
    public void setCategory(Category category) {
        this.category = category;
    }

    public UUID getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(UUID categoryId) {
        this.categoryId = categoryId;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }
}