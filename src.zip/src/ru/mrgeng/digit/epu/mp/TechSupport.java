package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(name = "MP_TECH_SUPPORT", uniqueConstraints = {
        @UniqueConstraint(name = "UC_TECH_SUPPORT_CODE", columnNames = {"CODE"})
})
@Entity(name = "mp_TechSupport")
@NamePattern("%s|name")
public class TechSupport extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "INFO")
    private String info;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}