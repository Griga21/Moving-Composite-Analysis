package ru.mrgeng.digit.epu.mp;

import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.OnDeleteInverse;
import com.haulmont.cuba.core.entity.annotation.PublishEntityChangedEvents;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.*;

@Table(name = "MP_DEVICE_PARAM_TRANSFORM_GROUP_TS")
@Entity(name = "mp_DeviceParamTransformGroupTs")
@Listeners("pros_MpConfListener")
@PublishEntityChangedEvents
public class DeviceParamTransformGroupTs extends DeviceParamTransform {

    @JoinColumn(name = "MEAS_TS_PARAM_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    @OnDeleteInverse(value = DeletePolicy.CASCADE)
    private DeviceParam measTsParam;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DATE_TRANSFORM_FUNC_ID")
    private TransformFunc dateTransformFunc;

    public TransformFunc getDateTransformFunc() {
        return dateTransformFunc;
    }

    public void setDateTransformFunc(TransformFunc dateTransformFunc) {
        this.dateTransformFunc = dateTransformFunc;
    }

    public DeviceParam getMeasTsParam() {
        return measTsParam;
    }

    public void setMeasTsParam(DeviceParam measTsParam) {
        this.measTsParam = measTsParam;
    }


}