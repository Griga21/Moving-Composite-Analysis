package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Listeners;
import com.haulmont.cuba.core.entity.annotation.Lookup;
import com.haulmont.cuba.core.entity.annotation.LookupType;

import javax.persistence.*;

/**
 * Модель данных драйвера (МДД)
 * Описание модели параметров устройства
 * (Драйвер)
 * В случае изменения сущности, модифицировать отчет driverExport
 */
@Table(name = "MP_DEVICE_PROTO_MODEL", uniqueConstraints = {
        @UniqueConstraint(name = "UK_DEVICE_PROTO_MODEL_CODE", columnNames = {"CODE", "DEVICE_SERVICE_ID"})
})
@Entity(name = "mp_DeviceProtoModel")
@NamePattern("%s(%s)|name,code")
@Listeners("pros_MpConfListener")
public class DeviceProtoModel extends MpObj {
    private static final long serialVersionUID = 1L;

    @Column(name = "DEV_VERSION")
    private String devVersion;

    @Lookup(type = LookupType.DROPDOWN, actions = {})
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_TYPE_ID")
    private DeviceType deviceType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_SERVICE_ID")
    private DeviceService deviceService;

    @Lookup(type = LookupType.SCREEN, actions = {})
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_MODEL_ID")
    private DeviceModel deviceModel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DEVICE_PROTO_ID")
    private DeviceProto deviceProto;

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    public DeviceService getDeviceService() {
        return deviceService;
    }

    public void setDeviceService(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    public DeviceModel getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(DeviceModel deviceModel) {
        this.deviceModel = deviceModel;
    }

    public DeviceProto getDeviceProto() {
        return deviceProto;
    }

    public void setDeviceProto(DeviceProto deviceProto) {
        this.deviceProto = deviceProto;
    }

    public String getDevVersion() {
        return devVersion;
    }

    public void setDevVersion(String devVersion) {
        this.devVersion = devVersion;
    }

}