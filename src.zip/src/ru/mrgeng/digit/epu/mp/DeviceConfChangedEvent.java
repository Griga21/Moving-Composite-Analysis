package ru.mrgeng.digit.epu.mp;

public class DeviceConfChangedEvent extends ObjsChangedEvent {

    public DeviceConfChangedEvent(Object source, String dataName) {
        super(source, dataName);
    }
}
