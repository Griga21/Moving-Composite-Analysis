package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.annotation.Listeners;
import ru.mrgeng.digit.epu.param.DataFormat;
import ru.mrgeng.digit.epu.param.ParamColor;

import javax.persistence.*;

/**
 * Параметр устройства
 */
@Table(name = "MP_PARAM", uniqueConstraints = {
        @UniqueConstraint(name = "UC_PARAM_CODE", columnNames = {"PARAM_GROUP_ID", "CODE"})
})
@Entity(name = "mp_Param")
@NamePattern("%s(%s)|name,code")
@Listeners("mp_CalcParamsChangesListener")
public class Param extends MpObj {
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "PARAM_GROUP_ID")
    protected ParamGroup paramGroup;

    @Column(name = "PARAM_GROUPING")
    private Integer paramGrouping;

    @Column(name = "DESIGNATION", length = 20)
    private String designation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_TYPE_ID")
    private ParamType paramType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "METRIC_PREFIX_ID")
    private ParamUnitMetricPrefix metricPrefix;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARAM_UNIT_ID")
    private ParamUnit paramUnit;

    @Column(name = "DEF_FORMAT")
    private String defFormat;

    @Column(name = "COLOR")
    protected String color;

    @Column(name = "alarmSign")
    private Integer alarmSign;

    @Column(name = "PARAM_DISPLAY")
    private Integer paramDisplay;

    public ParamGrouping getParamGrouping() {
        return paramGrouping == null ? null : ParamGrouping.fromId(paramGrouping);
    }

    public void setParamGrouping(ParamGrouping paramGrouping) {
        this.paramGrouping = paramGrouping == null ? null : paramGrouping.getId();
    }

    public void setAlarmSign(DiscreteAlarm alarmSign) {
        this.alarmSign = alarmSign == null ? null : alarmSign.getId();
    }

    public DiscreteAlarm getAlarmSign() {
        return alarmSign == null ? null : DiscreteAlarm.fromId(alarmSign);
    }

    public DiscreteAlarm getDiscreteAlarm() {
        return alarmSign == null ? null : DiscreteAlarm.fromId(alarmSign);
    }

    public void setDiscreteAlarm(DiscreteAlarm alarmSign) {
        this.alarmSign = alarmSign == null ? null : alarmSign.getId();
    }

    public DataFormat getDefFormat() {
        return defFormat == null ? null : DataFormat.fromId(defFormat);
    }

    public void setDefFormat(DataFormat defFormat) {
        this.defFormat = defFormat == null ? null : defFormat.getId();
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public ParamType getParamType() {
        return paramType;
    }

    public void setParamType(ParamType paramType) {
        this.paramType = paramType;
    }

    public ParamUnitMetricPrefix getMetricPrefix() {
        return metricPrefix;
    }

    public void setMetricPrefix(ParamUnitMetricPrefix metricPrefix) {
        this.metricPrefix = metricPrefix;
    }

    public ParamUnit getParamUnit() {
        return paramUnit;
    }

    public void setParamUnit(ParamUnit paramUnit) {
        this.paramUnit = paramUnit;
    }

    public ParamGroup getParamGroup() {
        return paramGroup;
    }

    public void setParamGroup(ParamGroup paramGroup) {
        this.paramGroup = paramGroup;
    }

    public String paramInfo() {
        return getCode() + ":" + getName();
    }

    public ParamColor getColor() {
        return color == null ? null : ParamColor.fromId(color);
    }

    public void setColor(ParamColor color) {
        this.color = color == null ? null : color.getId();
    }

    public ParamDisplay getParamDisplay() {
        return this.paramDisplay == null ? null : ParamDisplay.fromId(paramDisplay);
    }

    public void setParamDisplay(ParamDisplay paramDisplay) {
        this.paramDisplay = paramDisplay == null ? null : paramDisplay.getId();
    }

    public String obtainParamType() {
        return getParamType() != null ? getParamType().getCode() : null;
    }

    public String getParamTitle() {
        return designation != null ? designation : name != null ? name : code;
    }

    public String getParamTitleWithUnit() {
        String title = getParamTitle();
        String prefix = metricPrefix != null ? metricPrefix.getAbbr() != null ? metricPrefix.getAbbr() : metricPrefix.getName() : "";
        String unit = paramUnit != null ? paramUnit.getAbbr() != null ? paramUnit.getAbbr() : paramUnit.getName() : "";
        return title + " " + prefix + unit;
    }
}