package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum DeviceActionType implements EnumClass<Integer> {

    OPEN(1),
    CLOSE(2),
    CANCEL(3),
    BREAKDOWN(4), //срыв
    HOLD_CONNECTION(5), //удерживать связь
    AUTHORIZATION(6),
    WAKE(7), //разбудить
    DIAGNOSTIC(8),
    POLL(9); // Запросить текущие данные

    private final Integer id;

    DeviceActionType(Integer id) {
        this.id = id;
    }

    @Nullable
    public static DeviceActionType fromId(Integer id) {
        for (DeviceActionType at : DeviceActionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public Integer getId() {
        return id;
    }
}
