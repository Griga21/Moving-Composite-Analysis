package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;

public enum ActualizationMark implements EnumClass<Integer> {

    // <100 - не актуальные
    // >0 && 10< - неактуальные от пользователя
    USER_IGNORE_HARD(5),// эта актуализация автоматически не снимается, только пользователем
    USER_IGNORE_SOFT(6),
    WITHOUT_TRANSFORM(20),
    DEVICE_NOT_EXIST(50),
    DEVICE_WITHOUT_MODEL(51),
    MODEL_LINE_NOT_EXIST(52),
    // >100 - актуальные
    WITH_TRANSFORM(120),
    // >150 - актуальные от пользователя
    USER_ACTUALIZATION_SOFT(206),
    USER_ACTUALIZATION_HARD(215),// эта актуализация автоматически не снимается, только пользователем
    ;


    public static boolean isHardMark(ActualizationMark mark) {
        return USER_ACTUALIZATION_HARD.equals(mark) || USER_IGNORE_HARD.equals(mark);
    }

    public static final int median = 100;

    private Integer id;

    ActualizationMark(Integer value) {
        this.id = value;
    }

    public static boolean isActual(Integer actualizationMark) {
        return actualizationMark != null && actualizationMark > median;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ActualizationMark fromId(Integer id) {
        for (ActualizationMark at : ActualizationMark.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}
