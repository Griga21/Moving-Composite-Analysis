package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.MetaClass;
import com.haulmont.chile.core.annotations.MetaProperty;
import com.haulmont.cuba.core.entity.BaseUuidEntity;
import com.haulmont.cuba.security.entity.User;

import java.util.Date;

@MetaClass(name = "dgepu_EntityChangeItem")
public class EntityChangeItem extends BaseUuidEntity {
    private static final long serialVersionUID = -2017468485890036351L;

    @MetaProperty
    private Date changeDate;

    @MetaProperty
    private User user;

    @MetaProperty
    private String attribute;

    @MetaProperty
    private String oldValue;

    @MetaProperty
    private String newValue;

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getOldValue() {
        return oldValue;
    }

    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

}