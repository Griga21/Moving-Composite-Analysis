package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum ParamGrouping implements EnumClass<Integer> {

    SUM(10),
    AVG(20),
    MAX(30),
    DIF(40);

    private Integer id;

    ParamGrouping(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ParamGrouping fromId(Integer id) {
        for (ParamGrouping at : ParamGrouping.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}