package ru.mrgeng.digit.epu.mp;

import com.haulmont.chile.core.annotations.NamePattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "MP_DOCUMENT")
@Entity(name = "mp_Document")
@NamePattern("%s|name")
public class Document extends Obj {
    private static final long serialVersionUID = 791506486395088686L;

    @Column(name = "NAME")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
